package tn.delice.delijob.entity;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalTime;

@Entity
@Table(name = "entretien")
public class Entretien {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String candidat;

    @Column(nullable = false)
    private String poste;

    @Column(name = "email_candidat")
    private String emailCandidat;

    @Column(nullable = false)
    private LocalDate date;

    @Column(nullable = false)
    private LocalTime heure;

    private String statut;

    private Integer duree;

    private String type;

    private String interviewer;

    // ── Constructeurs ─────────────────────────────────────────────────────

    public Entretien() {}

    public Entretien(String candidat, String poste, String emailCandidat,
                     LocalDate date, LocalTime heure,
                     String statut, Integer duree, String type, String interviewer) {
        this.candidat      = candidat;
        this.poste         = poste;
        this.emailCandidat = emailCandidat;
        this.date          = date;
        this.heure         = heure;
        this.statut        = statut;
        this.duree         = duree;
        this.type          = type;
        this.interviewer   = interviewer;
    }

    // ── Getters & Setters ─────────────────────────────────────────────────

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getCandidat() { return candidat; }
    public void setCandidat(String candidat) { this.candidat = candidat; }

    public String getPoste() { return poste; }
    public void setPoste(String poste) { this.poste = poste; }

    public String getEmailCandidat() { return emailCandidat; }
    public void setEmailCandidat(String emailCandidat) { this.emailCandidat = emailCandidat; }

    public LocalDate getDate() { return date; }
    public void setDate(LocalDate date) { this.date = date; }

    public LocalTime getHeure() { return heure; }
    public void setHeure(LocalTime heure) { this.heure = heure; }

    public String getStatut() { return statut; }
    public void setStatut(String statut) { this.statut = statut; }

    public Integer getDuree() { return duree; }
    public void setDuree(Integer duree) { this.duree = duree; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public String getInterviewer() { return interviewer; }
    public void setInterviewer(String interviewer) { this.interviewer = interviewer; }
}