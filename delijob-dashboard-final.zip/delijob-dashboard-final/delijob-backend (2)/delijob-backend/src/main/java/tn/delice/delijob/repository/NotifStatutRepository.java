package tn.delice.delijob.repository;

import tn.delice.delijob.entity.NotifStatut;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface NotifStatutRepository extends JpaRepository<NotifStatut, Long> {

    /** Toutes les notifs non lues d'un utilisateur, du plus récent au plus ancien */
    List<NotifStatut> findByUserIdAndLuFalseOrderByCreatedAtDesc(Long userId);

    /** Toutes les notifs d'un utilisateur (lues + non lues) */
    List<NotifStatut> findByUserIdOrderByCreatedAtDesc(Long userId);

    /** Compte les non lues */
    long countByUserIdAndLuFalse(Long userId);

    /** Marquer toutes les notifs d'un user comme lues */
    @Modifying
    @Transactional
    @Query("UPDATE NotifStatut n SET n.lu = true WHERE n.userId = :userId AND n.lu = false")
    int markAllAsRead(Long userId);

    /** Marquer une notif spécifique comme lue */
    @Modifying
    @Transactional
    @Query("UPDATE NotifStatut n SET n.lu = true WHERE n.id = :id AND n.userId = :userId")
    int markAsRead(Long id, Long userId);
}