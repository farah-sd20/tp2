package tn.delice.delijob.entity;

import jakarta.persistence.*;
import tn.delice.delijob.converter.RoleConverter;
import java.time.LocalDateTime;

@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String prenom;

    @Column(nullable = false)
    private String nom;

    @Column(unique = true, nullable = false)
    private String email;

    @Column(nullable = false)
    private String password;

    @Column(nullable = false)
    private String departement;

    // ✅ ONLY this declaration — removed the duplicate @Enumerated one
    @Convert(converter = RoleConverter.class)
    @Column(nullable = false)
    private Role role = Role.RECRUTEUR;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Status status = Status.PENDING;

    @Column(nullable = true)
    private String photo;

    @Column(updatable = false)
    private LocalDateTime createdAt;

    private LocalDateTime updatedAt;

    @PrePersist
    public void onCreate() { this.createdAt = this.updatedAt = LocalDateTime.now(); }

    @PreUpdate
    public void onUpdate() { this.updatedAt = LocalDateTime.now(); }

    public enum Role   { ADMIN, RECRUTEUR,CANDIDAT ;


    }
    public enum Status { PENDING, APPROVED, REJECTED, ACTIVE, INACTIVE }

    public User() {}

    public User(String prenom, String nom, String email, String password,
                String departement, Role role, Status status) {
        this.prenom      = prenom;
        this.nom         = nom;
        this.email       = email;
        this.password    = password;
        this.departement = departement;
        this.role        = role;
        this.status      = status;
    }

    public Long   getId()                  { return id; }

    public String getPrenom()              { return prenom; }
    public void   setPrenom(String v)      { this.prenom = v; }

    public String getNom()                 { return nom; }
    public void   setNom(String v)         { this.nom = v; }

    public String getEmail()               { return email; }
    public void   setEmail(String v)       { this.email = v; }

    public String getPassword()            { return password; }
    public void   setPassword(String v)    { this.password = v; }

    public String getDepartement()         { return departement; }
    public void   setDepartement(String v) { this.departement = v; }

    public Role   getRole()                { return role; }
    public void   setRole(Role v)          { this.role = v; }

    public Status getStatus()              { return status; }
    public void   setStatus(Status v)      { this.status = v; }

    public String getPhoto()               { return photo; }
    public void   setPhoto(String v)       { this.photo = v; }

    public LocalDateTime getCreatedAt()    { return createdAt; }
    public LocalDateTime getUpdatedAt()    { return updatedAt; }
}