package tn.delice.delijob.dto;

public class RecruteurProfilDTO {
    private Long id;
    private String prenom;
    private String nom;
    private String email;
    private String telephone;
    private String poste;
    private String departement;
    private String photoUrl;
    private String role;

    public RecruteurProfilDTO() {}

    public RecruteurProfilDTO(Long id, String prenom, String nom, String email,
                              String telephone, String poste, String departement,
                              String photoUrl, String role) {
        this.id = id; this.prenom = prenom; this.nom = nom;
        this.email = email; this.telephone = telephone;
        this.poste = poste; this.departement = departement;
        this.photoUrl = photoUrl; this.role = role;
    }

    // Getters
    public Long getId() { return id; }
    public String getPrenom() { return prenom; }
    public String getNom() { return nom; }
    public String getEmail() { return email; }
    public String getTelephone() { return telephone; }
    public String getPoste() { return poste; }
    public String getDepartement() { return departement; }
    public String getPhotoUrl() { return photoUrl; }
    public String getRole() { return role; }
}