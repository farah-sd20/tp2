package tn.delice.delijob.dto;

import tn.delice.delijob.entity.User;
import java.time.LocalDateTime;

public class UserDTO {
    private Long id;
    private String prenom, nom, email, departement, role, status;
    private LocalDateTime createdAt;

    public static UserDTO from(User u) {
        UserDTO d = new UserDTO();
        d.id = u.getId(); d.prenom = u.getPrenom(); d.nom = u.getNom();
        d.email = u.getEmail(); d.departement = u.getDepartement();
        d.role = u.getRole().name(); d.status = u.getStatus().name();
        d.createdAt = u.getCreatedAt();
        return d;
    }

    public Long getId()                { return id; }
    public String getPrenom()          { return prenom; }
    public String getNom()             { return nom; }
    public String getEmail()           { return email; }
    public String getDepartement()     { return departement; }
    public String getRole()            { return role; }
    public String getStatus()          { return status; }
    public LocalDateTime getCreatedAt(){ return createdAt; }
}
