package tn.delice.delijob.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import tn.delice.delijob.entity.Entretien;
import java.time.LocalDate;
import java.util.List;

@Repository
public interface Entretienrepository extends JpaRepository<Entretien, Long> {

    List<Entretien> findByCandidatContainingIgnoreCaseOrPosteContainingIgnoreCaseOrInterviewerContainingIgnoreCase(
            String candidat, String poste, String interviewer);

    List<Entretien> findByDateBetweenOrderByDateAscHeureAsc(LocalDate startDate, LocalDate endDate);

    List<Entretien> findByDate(LocalDate date);
}