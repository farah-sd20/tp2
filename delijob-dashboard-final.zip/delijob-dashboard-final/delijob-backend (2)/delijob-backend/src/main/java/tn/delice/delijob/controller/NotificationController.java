package tn.delice.delijob.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.*;

/**
 * Résout les 405 sur :
 *   GET  /api/notifications/recent
 *   POST /api/notifications
 *   GET  /api/notifications
 *   DELETE /api/notifications/{id}
 */
@RestController
@RequestMapping("/api/notifications")
public class NotificationController {

    // Stockage en mémoire (pas de table SQL nécessaire pour les notifs UI)
    private final List<Map<String, Object>> store = Collections.synchronizedList(new ArrayList<>());

    // ----------------------------------------------------------------
    // GET /api/notifications/recent  ← route manquante qui causait le 405
    // ----------------------------------------------------------------
    @GetMapping("/recent")
    public ResponseEntity<?> getRecentNotifications(Authentication auth) {
        if (auth == null) {
            return ResponseEntity.status(401)
                    .body(Map.of("error", "Non authentifié"));
        }
        String email = auth.getName();

        List<Map<String, Object>> result = store.stream()
                .filter(n -> email.equals(n.get("userEmail")))
                .sorted((a, b) -> Long.compare(
                        (long) b.getOrDefault("timestamp", 0L),
                        (long) a.getOrDefault("timestamp", 0L)))
                .limit(10)
                .toList();

        return ResponseEntity.ok(result);
    }

    // ----------------------------------------------------------------
    // POST /api/notifications — créer une notification (appelé par React)
    // ----------------------------------------------------------------
    @PostMapping
    public ResponseEntity<?> createNotification(
            @RequestBody Map<String, Object> body,
            Authentication auth) {
        try {
            Map<String, Object> notif = new HashMap<>();
            notif.put("id",        UUID.randomUUID().toString());
            notif.put("type",      body.getOrDefault("type",    "info"));
            notif.put("titre",     body.getOrDefault("titre",   "Notification"));
            notif.put("message",   body.getOrDefault("message", ""));
            notif.put("avatar",    body.getOrDefault("avatar",  ""));
            notif.put("avatarBg",  body.getOrDefault("avatarBg","#6366f1"));
            notif.put("timestamp", System.currentTimeMillis());
            notif.put("lu",        false);

            if (auth != null) {
                notif.put("userEmail", auth.getName());
            }

            store.add(notif);

            return ResponseEntity.ok(Map.of(
                    "message", "Notification créée",
                    "id",      notif.get("id")
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", e.getMessage()));
        }
    }

    // ----------------------------------------------------------------
    // GET /api/notifications — toutes les notifs de l'utilisateur
    // ----------------------------------------------------------------
    @GetMapping
    public ResponseEntity<?> getNotifications(Authentication auth) {
        if (auth == null) {
            return ResponseEntity.status(401)
                    .body(Map.of("error", "Non authentifié"));
        }
        String email = auth.getName();
        List<Map<String, Object>> result = store.stream()
                .filter(n -> email.equals(n.get("userEmail")))
                .sorted((a, b) -> Long.compare(
                        (long) b.getOrDefault("timestamp", 0L),
                        (long) a.getOrDefault("timestamp", 0L)))
                .toList();
        return ResponseEntity.ok(result);
    }

    // ----------------------------------------------------------------
    // PATCH /api/notifications/{id}/lu — marquer comme lue
    // ----------------------------------------------------------------
    @PatchMapping("/{id}/lu")
    public ResponseEntity<?> markAsRead(@PathVariable String id) {
        store.stream()
                .filter(n -> id.equals(n.get("id")))
                .findFirst()
                .ifPresent(n -> n.put("lu", true));
        return ResponseEntity.ok(Map.of("message", "Notification marquée comme lue"));
    }

    // ----------------------------------------------------------------
    // DELETE /api/notifications/{id}
    // ----------------------------------------------------------------
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteNotification(@PathVariable String id) {
        store.removeIf(n -> id.equals(n.get("id")));
        return ResponseEntity.ok(Map.of("message", "Notification supprimée"));
    }
}