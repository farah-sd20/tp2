package tn.delice.delijob.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import tn.delice.delijob.dto.NotificationDTO;
import tn.delice.delijob.entity.Notification;
import tn.delice.delijob.entity.User;
import tn.delice.delijob.repository.NotificationRepository;
import tn.delice.delijob.repository.UserRepository;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class NotificationService {

    private final NotificationRepository notifRepo;
    private final UserRepository         userRepo;

    public NotificationService(NotificationRepository notifRepo,
                               UserRepository userRepo) {
        this.notifRepo = notifRepo;
        this.userRepo  = userRepo;
    }

    /* ── Lecture ──────────────────────────────────────────────────── */

    /** Page de notifs (pour AlertesPage) */
    @Transactional(readOnly = true)
    public Page<NotificationDTO> getPage(Long userId, int page, int size) {
        return notifRepo
                .findByUserIdOrderByCreatedAtDesc(userId, PageRequest.of(page, size))
                .map(NotificationDTO::from);
    }

    /** 20 dernières notifs (pour le dropdown topbar) */
    @Transactional(readOnly = true)
    public List<NotificationDTO> getRecent(Long userId) {
        return notifRepo.findTop20ByUserIdOrderByCreatedAtDesc(userId)
                .stream()
                .map(NotificationDTO::from)
                .collect(Collectors.toList());
    }

    /** Nombre de notifs non lues (badge) */
    @Transactional(readOnly = true)
    public Map<String, Long> getUnreadCount(Long userId) {
        return Map.of("count", notifRepo.countByUserIdAndLuFalse(userId));
    }

    /* ── Écriture ─────────────────────────────────────────────────── */

    @Transactional
    public void markRead(Long id, Long userId) {
        int updated = notifRepo.markAsRead(id, userId);
        if (updated == 0) throw new RuntimeException("Notification introuvable ou accès refusé");
    }

    @Transactional
    public void markAllRead(Long userId) {
        notifRepo.markAllAsRead(userId);
    }

    @Transactional
    public void dismiss(Long id, Long userId) {
        int deleted = notifRepo.deleteByIdAndUserId(id, userId);
        if (deleted == 0) throw new RuntimeException("Notification introuvable ou accès refusé");
    }

    @Transactional
    public void clearAll(Long userId) {
        notifRepo.deleteAllByUserId(userId);
    }

    /* ── Création (appelé en interne par d'autres services) ───────── */

    @Transactional
    public NotificationDTO create(Long userId, String type, String titre,
                                  String message, String avatar, String avatarBg,
                                  String actionLabel, String actionUrl) {
        User user = userRepo.findById(userId)
                .orElseThrow(() -> new RuntimeException("User introuvable: " + userId));

        Notification n = new Notification();
        n.setUser(user);
        n.setType(type);
        n.setTitre(titre);
        n.setMessage(message);
        n.setAvatar(avatar);
        n.setAvatarBg(avatarBg);
        n.setActionLabel(actionLabel);
        n.setActionUrl(actionUrl);

        return NotificationDTO.from(notifRepo.save(n));
    }

    /** Raccourci sans action ni avatar */
    @Transactional
    public NotificationDTO create(Long userId, String type, String titre, String message) {
        return create(userId, type, titre, message, null, null, null, null);
    }
}