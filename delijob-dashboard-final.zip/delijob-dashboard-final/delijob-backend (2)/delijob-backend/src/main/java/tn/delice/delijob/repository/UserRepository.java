package tn.delice.delijob.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import tn.delice.delijob.entity.User;
import java.util.List;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByEmail(String email);

    boolean existsByEmail(String email);
    List<User> findByStatus(User.Status status);
    List<User> findByRole(User.Role role);
    Optional<User> findByEmailIgnoreCase(String email);

}
