package tn.delice.delijob.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import tn.delice.delijob.entity.User;
import tn.delice.delijob.repository.UserRepository;
import tn.delice.delijob.service.AuthService;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/admin")
@PreAuthorize("hasRole('ADMIN')")
public class AdminController {

    private final UserRepository userRepo;
    private final AuthService    authService;

    public AdminController(UserRepository userRepo, AuthService authService) {
        this.userRepo    = userRepo;
        this.authService = authService;
    }

    /* ── Liste tous les utilisateurs (sauf admin hardcodé) ───────── */
    @GetMapping("/users")
    public ResponseEntity<List<User>> getAllUsers() {
        List<User> users = userRepo.findAll()
                .stream()
                .filter(u -> !u.getRole().equals(User.Role.ADMIN))
                .toList();
        return ResponseEntity.ok(users);
    }

    /* ── Changer le statut d'un utilisateur ──────────────────────── */
    @PatchMapping("/users/{id}/status")
    public ResponseEntity<?> updateUserStatus(
            @PathVariable Long id,
            @RequestParam String status) {
        try {
            User.Status newStatus = User.Status.valueOf(status.toUpperCase());
            authService.updateUserStatus(id, newStatus);
            return ResponseEntity.ok(Map.of("message", "Statut mis à jour avec succès."));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "Statut invalide : " + status));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(Map.of("error", e.getMessage()));
        }
    }

    /* ── Supprimer un utilisateur ─────────────────────────────────── */
    @DeleteMapping("/users/{id}")
    public ResponseEntity<?> deleteUser(@PathVariable Long id) {
        try {
            if (!userRepo.existsById(id)) {
                return ResponseEntity.notFound().build();
            }
            userRepo.deleteById(id);
            return ResponseEntity.ok(Map.of("message", "Utilisateur supprimé."));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(Map.of("error", e.getMessage()));
        }
    }
}