package tn.delice.delijob.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "messages")
public class Message {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Long senderId;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private SenderRole senderRole;

    @Column(nullable = false, columnDefinition = "TEXT")
    private String content;

    @Column(nullable = false)
    private Long recruiterId;

    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(nullable = false)
    private boolean readByAdmin = false;

    @PrePersist
    void prePersist() {
        this.createdAt = LocalDateTime.now();
    }

    public enum SenderRole {
        RECRUTEUR, ADMIN
    }

    // Getters
    public Long getId() { return id; }
    public Long getSenderId() { return senderId; }
    public SenderRole getSenderRole() { return senderRole; }
    public String getContent() { return content; }
    public Long getRecruiterId() { return recruiterId; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public boolean isReadByAdmin() { return readByAdmin; }

    // Setters
    public void setId(Long id) { this.id = id; }
    public void setSenderId(Long senderId) { this.senderId = senderId; }
    public void setSenderRole(SenderRole senderRole) { this.senderRole = senderRole; }
    public void setContent(String content) { this.content = content; }
    public void setRecruiterId(Long recruiterId) { this.recruiterId = recruiterId; }
    public void setCreatedAt(LocalDateTime t) { this.createdAt = t; }
    public void setReadByAdmin(boolean v) { this.readByAdmin = v; }
}