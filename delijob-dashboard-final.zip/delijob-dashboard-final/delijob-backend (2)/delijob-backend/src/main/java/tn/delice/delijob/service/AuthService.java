package tn.delice.delijob.service;

import jakarta.mail.internet.MimeMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import tn.delice.delijob.dto.*;
import tn.delice.delijob.entity.User;
import tn.delice.delijob.repository.UserRepository;
import tn.delice.delijob.security.JwtUtil;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.SecureRandom;
import java.util.UUID;

@Service
public class AuthService {

    private final UserRepository      userRepo;
    private final PasswordEncoder     encoder;
    private final JwtUtil             jwtUtil;
    private final JavaMailSender      mailSender;
    private final NotificationService notifService;

    public AuthService(UserRepository userRepo,
                       PasswordEncoder encoder,
                       JwtUtil jwtUtil,
                       JavaMailSender mailSender,
                       NotificationService notifService) {
        this.userRepo     = userRepo;
        this.encoder      = encoder;
        this.jwtUtil      = jwtUtil;
        this.mailSender   = mailSender;
        this.notifService = notifService;
    }

    /* ── Constantes ───────────────────────────────────────────────── */
    private static final String ADMIN_EMAIL  = "admin@delijob.tn";
    private static final String ADMIN_PASS   = "Admin2025";
    private static final String FROM         = "fasthirecompany@gmail.com";
    private static final String PLATFORM_URL = "http://localhost:5173";
    private static final String UPLOAD_DIR   = "uploads/photos/";

    private static final String UPPER  = "ABCDEFGHJKLMNPQRSTUVWXYZ";
    private static final String LOWER  = "abcdefghjkmnpqrstuvwxyz";
    private static final String DIGITS = "23456789";
    private static final String ALL    = UPPER + LOWER + DIGITS;

    /* ── REGISTER ─────────────────────────────────────────────────── */
    public String register(RegisterRequest req, MultipartFile photo) {
        if (userRepo.existsByEmail(req.getEmail()))
            throw new RuntimeException("Email déjà utilisé.");

        String photoPath = null;
        if (photo != null && !photo.isEmpty()) {
            photoPath = savePhoto(photo);
        }

        User u = new User(
                req.getPrenom(), req.getNom(), req.getEmail(),
                encoder.encode(req.getPassword()), req.getDepartement(),
                User.Role.RECRUTEUR, User.Status.PENDING
        );
        if (photoPath != null) {
            u.setPhoto(photoPath);
        }

        userRepo.save(u);
        return "Demande enregistrée. En attente de validation par un administrateur.";
    }

    public String register(RegisterRequest req) {
        return register(req, null);
    }

    /* ── Sauvegarde photo ─────────────────────────────────────────── */
    private String savePhoto(MultipartFile photo) {
        try {
            Path dir = Paths.get(UPLOAD_DIR);
            Files.createDirectories(dir);
            String filename = UUID.randomUUID() + "_" + photo.getOriginalFilename();
            Path dest = dir.resolve(filename);
            photo.transferTo(dest.toFile());
            return UPLOAD_DIR + filename;
        } catch (Exception e) {
            throw new RuntimeException("Erreur lors de la sauvegarde de la photo.");
        }
    }

    /* ── LOGIN ────────────────────────────────────────────────────── */
    public AuthResponse login(LoginRequest req) {
        System.out.println("🔐 Tentative de connexion: " + req.getEmail());

        if (ADMIN_EMAIL.equalsIgnoreCase(req.getEmail().trim())) {
            if (!ADMIN_PASS.equals(req.getPassword())) {
                throw new RuntimeException("Email ou mot de passe incorrect.");
            }
            String token = jwtUtil.generate(ADMIN_EMAIL, "ADMIN");
            System.out.println("✅ Admin connecté: " + ADMIN_EMAIL);
            return new AuthResponse(token, "ADMIN", "ACTIVE",
                    0L, "Administrateur", "Système", ADMIN_EMAIL, "Administration");
        }

        User u = userRepo.findByEmail(req.getEmail().trim())
                .orElseThrow(() -> new RuntimeException("Email ou mot de passe incorrect."));

        boolean passwordMatch = encoder.matches(req.getPassword(), u.getPassword());
        if (!passwordMatch)
            throw new RuntimeException("Email ou mot de passe incorrect.");

        if (u.getStatus() == User.Status.PENDING)  throw new RuntimeException("PENDING");
        if (u.getStatus() == User.Status.REJECTED ||
                u.getStatus() == User.Status.INACTIVE) throw new RuntimeException("REJECTED");

        String role  = u.getRole().name();
        String token = jwtUtil.generate(u.getEmail(), role);

        return new AuthResponse(token, role, u.getStatus().name(),
                u.getId(), u.getPrenom(), u.getNom(), u.getEmail(), u.getDepartement());
    }

    /* ── Changement de statut + notification + email ─────────────── */
    @Transactional
    public void updateUserStatus(Long userId, User.Status newStatus) {
        User u = userRepo.findById(userId)
                .orElseThrow(() -> new RuntimeException("Utilisateur introuvable."));

        u.setStatus(newStatus);
        userRepo.save(u);

        if (newStatus == User.Status.ACTIVE || newStatus == User.Status.APPROVED) {
            notifService.create(userId, "validation", "Compte approuvé",
                    "Votre compte a été activé. Vous pouvez maintenant vous connecter sur " + PLATFORM_URL);
        } else if (newStatus == User.Status.REJECTED || newStatus == User.Status.INACTIVE) {
            notifService.create(userId, "validation", "Compte refusé",
                    "Votre demande d'accès a été refusée. Contactez l'administrateur pour plus d'informations.");
        }

        try {
            if (newStatus == User.Status.ACTIVE || newStatus == User.Status.APPROVED)
                sendApprovalEmail(u);
            else if (newStatus == User.Status.REJECTED || newStatus == User.Status.INACTIVE)
                sendRejectionEmail(u);
        } catch (Exception e) {
            System.err.println("⚠️ Erreur envoi email: " + e.getMessage());
        }
    }

    /* ── Email : compte approuvé ──────────────────────────────────── */
    private void sendApprovalEmail(User u) {
        try {
            String email = u.getEmail() == null ? "" : u.getEmail().trim();
            if (email.isEmpty()) return;

            MimeMessage msg = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(msg, true, "UTF-8");
            helper.setFrom(FROM);
            helper.setTo(email);
            helper.setSubject("DeliJob — Votre compte a été activé !");
            helper.setText(buildApprovalEmailHtml(u), true);
            mailSender.send(msg);
            System.out.println("📧 Email approbation envoyé à: " + email);
        } catch (Exception e) {
            System.err.println("⚠️ Erreur envoi email approbation: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void sendRejectionEmail(User u) {
        try {
            String email = u.getEmail() == null ? "" : u.getEmail().trim();
            if (email.isEmpty()) return;

            MimeMessage msg = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(msg, true, "UTF-8");
            helper.setFrom(FROM);
            helper.setTo(email);
            helper.setSubject("DeliJob — Suite à votre demande d'accès");
            helper.setText(buildRejectionEmailHtml(u), true);
            mailSender.send(msg);
            System.out.println("📧 Email refus envoyé à: " + email);
        } catch (Exception e) {
            System.err.println("⚠️ Erreur envoi email refus: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /* ── Mot de passe oublié ──────────────────────────────────────── */
    public void sendNewPassword(String email) {
        String normalizedEmail = email.trim().toLowerCase();

        User u = userRepo.findByEmail(normalizedEmail).orElse(null);
        if (u == null) {
            System.out.println("⚠️ Tentative reset mdp pour email inconnu: " + normalizedEmail);
            return;
        }

        if (u.getStatus() == User.Status.PENDING) {
            try {
                MimeMessage msg = mailSender.createMimeMessage();
                MimeMessageHelper helper = new MimeMessageHelper(msg, true, "UTF-8");
                helper.setFrom(FROM);
                helper.setTo(u.getEmail());
                helper.setSubject("DeliJob - Compte en attente de validation");
                helper.setText(buildPendingEmailHtml(u), true);
                mailSender.send(msg);
            } catch (Exception e) {
                System.err.println("⚠️ Erreur envoi email pending: " + e.getMessage());
            }
            return;
        }

        if (u.getStatus() == User.Status.REJECTED || u.getStatus() == User.Status.INACTIVE) {
            System.out.println("⛔ Reset mdp refusé — compte " + u.getStatus() + ": " + u.getEmail());
            return;
        }

        String newPassword = generateSecurePassword(12);
        u.setPassword(encoder.encode(newPassword));
        userRepo.save(u);

        User reloaded = userRepo.findByEmail(normalizedEmail).orElse(null);
        if (reloaded != null) {
            boolean matchOk = encoder.matches(newPassword, reloaded.getPassword());
            if (!matchOk) {
                System.err.println("❌ ERREUR CRITIQUE : le hash sauvegardé ne correspond pas !");
                throw new RuntimeException("Erreur interne lors de la sauvegarde du mot de passe.");
            }
        }

        try {
            MimeMessage msg = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(msg, true, "UTF-8");
            helper.setFrom(FROM);
            helper.setTo(u.getEmail());
            helper.setSubject("DeliJob - Votre nouveau mot de passe temporaire");
            helper.setText(buildPasswordEmailHtml(u.getPrenom(), newPassword), true);
            mailSender.send(msg);
            System.out.println("📧 Email reset mdp envoyé à: " + u.getEmail());
        } catch (Exception e) {
            System.err.println("⚠️ Erreur envoi email reset: " + e.getMessage());
            throw new RuntimeException("Erreur lors de l'envoi de l'email. Contactez le support.");
        }
    }

    /* ══════════════════════════════════════════════════════════════════
       TEMPLATES HTML EMAILS
    ══════════════════════════════════════════════════════════════════ */

    /* ── Layout commun (header + footer) ─────────────────────────── */
    private String emailWrapper(String content) {
        return """
            <!DOCTYPE html>
            <html lang="fr">
            <head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
            <body style="margin:0;padding:0;background:#F5F3EF;font-family:'Helvetica Neue',Arial,sans-serif;">
              <table width="100%" cellpadding="0" cellspacing="0" style="background:#F5F3EF;padding:40px 20px;">
                <tr><td align="center">
                  <table width="560" cellpadding="0" cellspacing="0" style="max-width:560px;width:100%%;">

                    <!-- HEADER -->
                    <tr>
                      <td style="background:#003DA5;border-radius:16px 16px 0 0;padding:28px 36px;">
                        <table width="100%%" cellpadding="0" cellspacing="0">
                          <tr>
                            <td>
                              <span style="font-size:20px;font-weight:600;color:#ffffff;letter-spacing:-0.3px;">DeliJob</span>
                              <br>
                              <span style="font-size:12px;color:rgba(255,255,255,0.6);">Plateforme de recrutement · Delice Danone</span>
                            </td>
                            <td align="right">
                              <div style="width:40px;height:40px;background:rgba(255,255,255,0.15);border-radius:50%%;display:inline-flex;align-items:center;justify-content:center;">
                                <span style="color:#fff;font-size:18px;">⚡</span>
                              </div>
                            </td>
                          </tr>
                        </table>
                      </td>
                    </tr>

                    <!-- BODY -->
                    <tr>
                      <td style="background:#ffffff;padding:36px;border-left:1px solid #E5E7EB;border-right:1px solid #E5E7EB;">
                """ + content + """
                      </td>
                    </tr>

                    <!-- FOOTER -->
                    <tr>
                      <td style="background:#F9F8F6;border:1px solid #E5E7EB;border-top:none;border-radius:0 0 16px 16px;padding:16px 36px;">
                        <table width="100%%" cellpadding="0" cellspacing="0">
                          <tr>
                            <td style="font-size:13px;color:#9CA3AF;">L'équipe DeliJob</td>
                            <td align="right" style="font-size:12px;color:#C4C4C4;">© 2026 DeliJob · Delice Danone</td>
                          </tr>
                        </table>
                      </td>
                    </tr>

                  </table>
                </td></tr>
              </table>
            </body>
            </html>
            """;
    }

    /* ── Template : mot de passe temporaire ──────────────────────── */
    private String buildPasswordEmailHtml(String prenom, String password) {
        String body = """
            <p style="font-size:15px;color:#111827;margin:0 0 16px;">Bonjour <strong>%s</strong>,</p>
            <p style="font-size:14px;color:#6B7280;line-height:1.7;margin:0 0 28px;">
              Suite à votre demande de réinitialisation, voici votre nouveau mot de passe temporaire.
              Connectez-vous puis changez-le dès votre première connexion.
            </p>

            <!-- Bloc mot de passe -->
            <table width="100%%" cellpadding="0" cellspacing="0" style="margin-bottom:28px;">
              <tr>
                <td style="background:#E6F1FB;border:1px solid #B5D4F4;border-radius:12px;padding:20px 24px;">
                  <p style="font-size:11px;font-weight:600;color:#185FA5;letter-spacing:0.8px;text-transform:uppercase;margin:0 0 10px;">
                    🔑 Mot de passe temporaire
                  </p>
                  <p style="font-family:'Courier New',monospace;font-size:24px;font-weight:700;color:#0C447C;letter-spacing:3px;margin:0 0 10px;">
                    %s
                  </p>
                  <p style="font-size:12px;color:#185FA5;margin:0;">
                    Copiez uniquement ces caractères, sans espace.
                  </p>
                </td>
              </tr>
            </table>

            <hr style="border:none;border-top:1px solid #E5E7EB;margin:0 0 20px;">
            <p style="font-size:13px;color:#6B7280;margin:0 0 8px;">
              🔒 Pour votre sécurité, changez ce mot de passe après connexion.
            </p>
            <p style="font-size:13px;color:#9CA3AF;margin:0;">
              Si vous n'avez pas effectué cette demande, ignorez cet email.
            </p>
            """.formatted(prenom, password);

        return emailWrapper(body);
    }

    /* ── Template : compte approuvé ──────────────────────────────── */
    private String buildApprovalEmailHtml(User u) {
        String prenom = u.getPrenom();
        String nom    = u.getNom();
        String email  = u.getEmail();
        String dept   = u.getDepartement();

        String body =
                "<!-- Icône succès -->" +
                        "<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"margin-bottom:24px;\">" +
                        "  <tr><td align=\"center\">" +
                        "    <div style=\"width:64px;height:64px;background:#EAF3DE;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;font-size:28px;\">✅</div>" +
                        "  </td></tr>" +
                        "</table>" +
                        "<p style=\"font-size:15px;color:#111827;margin:0 0 8px;text-align:center;\">Bonjour <strong>" + prenom + " " + nom + "</strong>,</p>" +
                        "<p style=\"font-size:22px;font-weight:600;color:#27500A;margin:0 0 20px;text-align:center;\">Votre compte est activé !</p>" +
                        "<p style=\"font-size:14px;color:#6B7280;line-height:1.7;margin:0 0 28px;text-align:center;\">" +
                        "  Votre demande d'accès à la plateforme DeliJob a été approuvée. Vous pouvez désormais vous connecter." +
                        "</p>" +
                        "<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"margin-bottom:28px;\">" +
                        "  <tr><td style=\"background:#F9F8F6;border:1px solid #E5E7EB;border-radius:12px;padding:20px 24px;\">" +
                        "    <p style=\"font-size:11px;font-weight:600;color:#6B7280;letter-spacing:0.8px;text-transform:uppercase;margin:0 0 14px;\">Informations du compte</p>" +
                        "    <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">" +
                        "      <tr>" +
                        "        <td style=\"font-size:13px;color:#9CA3AF;padding:5px 0;\">Email</td>" +
                        "        <td align=\"right\" style=\"font-size:13px;color:#111827;font-weight:500;padding:5px 0;\">" + email + "</td>" +
                        "      </tr>" +
                        "      <tr>" +
                        "        <td style=\"font-size:13px;color:#9CA3AF;padding:5px 0;border-top:1px solid #F3F4F6;\">Département</td>" +
                        "        <td align=\"right\" style=\"font-size:13px;color:#111827;font-weight:500;padding:5px 0;border-top:1px solid #F3F4F6;\">" + dept + "</td>" +
                        "      </tr>" +
                        "      <tr>" +
                        "        <td style=\"font-size:13px;color:#9CA3AF;padding:5px 0;border-top:1px solid #F3F4F6;\">Statut</td>" +
                        "        <td align=\"right\" style=\"padding:5px 0;border-top:1px solid #F3F4F6;\">" +
                        "          <span style=\"background:#EAF3DE;color:#3B6D11;font-size:12px;font-weight:600;padding:3px 10px;border-radius:20px;\">Actif</span>" +
                        "        </td>" +
                        "      </tr>" +
                        "    </table>" +
                        "  </td></tr>" +
                        "</table>" +
                        "<table cellpadding=\"0\" cellspacing=\"0\" style=\"margin:0 auto 28px;\">" +
                        "  <tr><td style=\"background:#003DA5;border-radius:10px;\">" +
                        "    <a href=\"" + PLATFORM_URL + "\" style=\"display:inline-block;padding:13px 28px;font-size:14px;font-weight:500;color:#ffffff;text-decoration:none;\">Accéder à la plateforme &rarr;</a>" +
                        "  </td></tr>" +
                        "</table>" +
                        "<hr style=\"border:none;border-top:1px solid #E5E7EB;margin:0 0 20px;\">" +
                        "<p style=\"font-size:13px;color:#9CA3AF;margin:0;text-align:center;\">Bienvenue dans l'équipe DeliJob.</p>";

        return emailWrapper(body);
    }

    /* ── Template : compte refusé ────────────────────────────────── */
    private String buildRejectionEmailHtml(User u) {
        String prenom = u.getPrenom();
        String nom    = u.getNom();

        String body =
                "<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"margin-bottom:24px;\">" +
                        "  <tr><td align=\"center\">" +
                        "    <div style=\"width:64px;height:64px;background:#FCEBEB;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;font-size:28px;\">❌</div>" +
                        "  </td></tr>" +
                        "</table>" +
                        "<p style=\"font-size:15px;color:#111827;margin:0 0 8px;text-align:center;\">Bonjour <strong>" + prenom + " " + nom + "</strong>,</p>" +
                        "<p style=\"font-size:22px;font-weight:600;color:#7F1D1D;margin:0 0 20px;text-align:center;\">Demande d'accès refusée</p>" +
                        "<p style=\"font-size:14px;color:#6B7280;line-height:1.7;margin:0 0 28px;text-align:center;\">" +
                        "  Nous ne sommes pas en mesure d'approuver votre demande pour le moment." +
                        "  Contactez l'administrateur pour plus d'informations." +
                        "</p>" +
                        "<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"margin-bottom:28px;\">" +
                        "  <tr><td style=\"background:#FEF2F2;border:1px solid #FECACA;border-radius:12px;padding:20px 24px;text-align:center;\">" +
                        "    <p style=\"font-size:13px;color:#991B1B;margin:0 0 6px;font-weight:500;\">Besoin d'informations supplémentaires ?</p>" +
                        "    <p style=\"font-size:13px;color:#B91C1C;margin:0;\">" +
                        "      Contactez l'administrateur DeliJob :<br>" +
                        "      <a href=\"mailto:admin@delijob.tn\" style=\"color:#003DA5;font-weight:500;\">admin@delijob.tn</a>" +
                        "    </p>" +
                        "  </td></tr>" +
                        "</table>" +
                        "<hr style=\"border:none;border-top:1px solid #E5E7EB;margin:0 0 20px;\">" +
                        "<p style=\"font-size:13px;color:#9CA3AF;margin:0;text-align:center;\">Cordialement, l'équipe DeliJob.</p>";

        return emailWrapper(body);
    }

    /* ── Template : compte en attente ────────────────────────────── */
    private String buildPendingEmailHtml(User u) {
        String body = """
            <table width="100%%" cellpadding="0" cellspacing="0" style="margin-bottom:24px;">
              <tr>
                <td align="center">
                  <div style="width:64px;height:64px;background:#FAEEDA;border-radius:50%%;display:inline-flex;align-items:center;justify-content:center;font-size:28px;">
                    ⏳
                  </div>
                </td>
              </tr>
            </table>

            <p style="font-size:15px;color:#111827;margin:0 0 8px;text-align:center;">
              Bonjour <strong>%s</strong>,
            </p>
            <p style="font-size:18px;font-weight:600;color:#92400E;margin:0 0 20px;text-align:center;">
              Compte en attente de validation
            </p>
            <p style="font-size:14px;color:#6B7280;line-height:1.7;margin:0 0 20px;text-align:center;">
              Votre compte est actuellement en attente de validation par un administrateur.
              Vous recevrez un email dès que votre accès sera activé.
            </p>

            <hr style="border:none;border-top:1px solid #E5E7EB;margin:0 0 20px;">
            <p style="font-size:13px;color:#9CA3AF;margin:0;text-align:center;">
              Merci de votre patience. L'équipe DeliJob.
            </p>
            """.formatted(u.getPrenom());

        return emailWrapper(body);
    }

    /* ── Générateur de mot de passe sécurisé ─────────────────────── */
    private String generateSecurePassword(int length) {
        SecureRandom random = new SecureRandom();
        char[] pwd = new char[length];

        pwd[0] = UPPER .charAt(random.nextInt(UPPER.length()));
        pwd[1] = LOWER .charAt(random.nextInt(LOWER.length()));
        pwd[2] = DIGITS.charAt(random.nextInt(DIGITS.length()));

        for (int i = 3; i < length; i++)
            pwd[i] = ALL.charAt(random.nextInt(ALL.length()));

        for (int i = length - 1; i > 0; i--) {
            int j = random.nextInt(i + 1);
            char tmp = pwd[i]; pwd[i] = pwd[j]; pwd[j] = tmp;
        }

        return new String(pwd);
    }

    /* ── REGISTER CANDIDAT (mobile) — actif immédiatement ────────── */
    public String registerCandidat(RegisterRequest req, MultipartFile photo) {
        if (userRepo.existsByEmail(req.getEmail()))
            throw new RuntimeException("Email déjà utilisé.");

        String photoPath = null;
        if (photo != null && !photo.isEmpty()) {
            photoPath = savePhoto(photo);
        }

        User u = new User(
                req.getPrenom(), req.getNom(), req.getEmail(),
                encoder.encode(req.getPassword()), req.getDepartement(),
                User.Role.CANDIDAT, User.Status.ACTIVE
        );
        if (photoPath != null) u.setPhoto(photoPath);

        userRepo.save(u);
        return "Inscription réussie. Vous pouvez maintenant vous connecter.";
    }
}