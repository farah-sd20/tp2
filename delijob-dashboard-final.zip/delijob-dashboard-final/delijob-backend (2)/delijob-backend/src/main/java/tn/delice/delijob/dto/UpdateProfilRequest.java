package tn.delice.delijob.dto;

public class UpdateProfilRequest {
    private String prenom;
    private String nom;
    private String telephone;
    private String poste;

    // Constructeurs
    public UpdateProfilRequest() {}

    public UpdateProfilRequest(String prenom, String nom, String telephone, String poste) {
        this.prenom = prenom;
        this.nom = nom;
        this.telephone = telephone;
        this.poste = poste;
    }

    // Getters et Setters
    public String getPrenom() { return prenom; }
    public void setPrenom(String prenom) { this.prenom = prenom; }

    public String getNom() { return nom; }
    public void setNom(String nom) { this.nom = nom; }

    public String getTelephone() { return telephone; }
    public void setTelephone(String telephone) { this.telephone = telephone; }

    public String getPoste() { return poste; }
    public void setPoste(String poste) { this.poste = poste; }
}