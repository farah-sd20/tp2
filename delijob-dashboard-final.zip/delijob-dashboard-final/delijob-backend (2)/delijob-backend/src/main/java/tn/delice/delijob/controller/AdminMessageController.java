package tn.delice.delijob.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.web.bind.annotation.*;
import tn.delice.delijob.entity.Message;
import tn.delice.delijob.entity.User;
import tn.delice.delijob.repository.UserRepository;
import tn.delice.delijob.service.MessageService;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/admin/messages")
public class AdminMessageController {

    private final MessageService service;
    private final UserRepository userRepository;

    public AdminMessageController(MessageService service, UserRepository userRepository) {
        this.service = service;
        this.userRepository = userRepository;
    }

    @GetMapping("/{recruiterId}")
    public ResponseEntity<?> getConversation(
            @PathVariable Long recruiterId,
            Authentication auth) {
        try {
            checkAdmin(auth);
            List<Message> messages = service.getConversation(recruiterId);
            service.markConversationRead(recruiterId);
            return ResponseEntity.ok(messages);
        } catch (SecurityException e) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", e.getMessage()));
        }
    }

    @PostMapping("/{recruiterId}")
    public ResponseEntity<?> sendAsAdmin(
            @PathVariable Long recruiterId,
            @RequestBody Map<String, String> body,
            Authentication auth) {
        try {
            if (body.get("content") == null || body.get("content").isBlank())
                return ResponseEntity.badRequest().body(Map.of("error", "Contenu vide"));

            String email = checkAdmin(auth);

            // Chercher l'admin en DB pour avoir son ID
            User admin = userRepository.findByEmailIgnoreCase(email)
                    .orElseThrow(() -> new RuntimeException("Admin introuvable : " + email));

            Message m = service.sendAsAdmin(recruiterId, body.get("content"), admin.getId());
            return ResponseEntity.status(HttpStatus.CREATED).body(m);
        } catch (SecurityException e) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", e.getMessage()));
        }
    }

    @GetMapping("/unread")
    public ResponseEntity<?> getUnreadCounts(Authentication auth) {
        try {
            checkAdmin(auth);
            return ResponseEntity.ok(service.getUnreadCounts());
        } catch (SecurityException e) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", e.getMessage()));
        }
    }

    @PutMapping("/{messageId}")
    public ResponseEntity<?> adminUpdateMessage(
            @PathVariable Long messageId,
            @RequestBody Map<String, String> body,
            Authentication auth) {
        try {
            checkAdmin(auth);
            String newContent = body.get("content");
            if (newContent == null || newContent.isBlank())
                return ResponseEntity.badRequest().body(Map.of("error", "Contenu vide"));
            Message message = service.getMessageById(messageId);
            if (message == null)
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("error", "Message non trouvé"));
            return ResponseEntity.ok(service.updateMessageContent(messageId, newContent));
        } catch (SecurityException e) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", e.getMessage()));
        }
    }

    @DeleteMapping("/{messageId}")
    public ResponseEntity<?> adminDeleteMessage(
            @PathVariable Long messageId,
            Authentication auth) {
        try {
            checkAdmin(auth);
            Message message = service.getMessageById(messageId);
            if (message == null)
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("error", "Message non trouvé"));
            service.deleteMessage(messageId);
            return ResponseEntity.ok(Map.of("success", true));
        } catch (SecurityException e) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", e.getMessage()));
        }
    }

    // ✅ Vérifie le rôle directement depuis les authorities du token (pas de DB)
    private String checkAdmin(Authentication auth) {
        if (auth == null || !auth.isAuthenticated()) {
            throw new SecurityException("Non authentifié");
        }

        System.out.println("=== checkAdmin DEBUG ===");
        System.out.println("Principal : " + auth.getPrincipal());
        System.out.println("Authorities : " + auth.getAuthorities());

        boolean isAdmin = auth.getAuthorities().stream()
                .map(GrantedAuthority::getAuthority)
                .anyMatch(a -> a.equals("ROLE_ADMIN") || a.equals("ADMIN"));

        if (!isAdmin) {
            throw new SecurityException("Accès refusé — authorities: " + auth.getAuthorities());
        }

        return auth.getPrincipal().toString();
    }
}