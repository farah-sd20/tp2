package tn.delice.delijob.dto;

public class Entretiendto {

    private Long    id;
    private String  candidat;
    private String  poste;
    private String  emailCandidat;   // adresse email du candidat pour la convocation
    private String  date;            // format YYYY-MM-DD  (String ↔ frontend)
    private String  heure;           // format HH:MM       (String ↔ frontend)
    private String  statut;
    private Integer duree;
    private String  type;
    private String  interviewer;

    // ── Constructeurs ─────────────────────────────────────────────────────

    public Entretiendto() {}

    public Entretiendto(Long id, String candidat, String poste, String emailCandidat,
                        String date, String heure, String statut,
                        Integer duree, String type, String interviewer) {
        this.id            = id;
        this.candidat      = candidat;
        this.poste         = poste;
        this.emailCandidat = emailCandidat;
        this.date          = date;
        this.heure         = heure;
        this.statut        = statut;
        this.duree         = duree;
        this.type          = type;
        this.interviewer   = interviewer;
    }

    // ── Getters & Setters ─────────────────────────────────────────────────

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getCandidat() { return candidat; }
    public void setCandidat(String candidat) { this.candidat = candidat; }

    public String getPoste() { return poste; }
    public void setPoste(String poste) { this.poste = poste; }

    public String getEmailCandidat() { return emailCandidat; }
    public void setEmailCandidat(String emailCandidat) { this.emailCandidat = emailCandidat; }

    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }

    public String getHeure() { return heure; }
    public void setHeure(String heure) { this.heure = heure; }

    public String getStatut() { return statut; }
    public void setStatut(String statut) { this.statut = statut; }

    public Integer getDuree() { return duree; }
    public void setDuree(Integer duree) { this.duree = duree; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public String getInterviewer() { return interviewer; }
    public void setInterviewer(String interviewer) { this.interviewer = interviewer; }

    @Override
    public String toString() {
        return "Entretiendto{" +
                "id=" + id +
                ", candidat='" + candidat + '\'' +
                ", poste='" + poste + '\'' +
                ", emailCandidat='" + emailCandidat + '\'' +
                ", date='" + date + '\'' +
                ", heure='" + heure + '\'' +
                ", statut='" + statut + '\'' +
                ", duree=" + duree +
                ", type='" + type + '\'' +
                ", interviewer='" + interviewer + '\'' +
                '}';
    }
}