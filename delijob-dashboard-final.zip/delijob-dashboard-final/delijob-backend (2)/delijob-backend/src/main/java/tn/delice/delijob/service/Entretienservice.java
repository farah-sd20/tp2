package tn.delice.delijob.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import tn.delice.delijob.dto.Entretiendto;
import tn.delice.delijob.entity.Entretien;
import tn.delice.delijob.repository.Entretienrepository;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class Entretienservice {

    private static final Logger log = LoggerFactory.getLogger(Entretienservice.class);

    private final Entretienrepository repo;
    private final EmailService emailService; // ✅ injection

    public Entretienservice(Entretienrepository repo, EmailService emailService) {
        this.repo = repo;
        this.emailService = emailService;
    }

    public List<Entretiendto> getAll() {
        return repo.findAll().stream().map(this::toDTO).collect(Collectors.toList());
    }

    public List<Entretiendto> search(String q) {
        return repo
                .findByCandidatContainingIgnoreCaseOrPosteContainingIgnoreCaseOrInterviewerContainingIgnoreCase(q, q, q)
                .stream().map(this::toDTO).collect(Collectors.toList());
    }

    public List<Entretiendto> getByMonth(int year, int month) {
        LocalDate from = LocalDate.of(year, month, 1);
        LocalDate to = from.withDayOfMonth(from.lengthOfMonth());
        return repo.findByDateBetweenOrderByDateAscHeureAsc(from, to)
                .stream().map(this::toDTO).collect(Collectors.toList());
    }

    public Entretiendto create(Entretiendto dto) {
        log.info("📥 Création entretien pour : {} - email : {}", dto.getCandidat(), dto.getEmailCandidat());
        Entretien e = toEntity(dto);
        Entretien saved = repo.save(e);
        log.info("✅ Entretien sauvegardé id={}, emailCandidat='{}'", saved.getId(), saved.getEmailCandidat());

        // ✅ Envoi de l'email de convocation
        emailService.envoyerConvocation(saved);

        return toDTO(saved);
    }

    public Entretiendto update(Long id, Entretiendto dto) {
        Entretien e = repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Entretien introuvable : " + id));
        applyDTO(dto, e);
        return toDTO(repo.save(e));
    }

    public void delete(Long id) {
        if (!repo.existsById(id))
            throw new RuntimeException("Entretien introuvable : " + id);
        repo.deleteById(id);
    }

    // ── Mapping ───────────────────────────────────────────────────────────

    private Entretiendto toDTO(Entretien e) {
        Entretiendto d = new Entretiendto();
        d.setId(e.getId());
        d.setCandidat(e.getCandidat());
        d.setPoste(e.getPoste());
        d.setEmailCandidat(e.getEmailCandidat()); // ✅
        d.setDate(e.getDate().toString());
        d.setHeure(e.getHeure().toString().substring(0, 5));
        d.setStatut(e.getStatut());
        d.setDuree(e.getDuree());
        d.setType(e.getType());
        d.setInterviewer(e.getInterviewer());
        return d;
    }

    private Entretien toEntity(Entretiendto d) {
        Entretien e = new Entretien();
        applyDTO(d, e);
        return e;
    }

    private void applyDTO(Entretiendto d, Entretien e) {
        e.setCandidat(d.getCandidat());
        e.setPoste(d.getPoste());
        e.setEmailCandidat(d.getEmailCandidat()); // ✅ champ manquant ajouté
        e.setDate(LocalDate.parse(d.getDate()));
        e.setHeure(LocalTime.parse(d.getHeure()));
        e.setStatut(d.getStatut() != null ? d.getStatut() : "en attente");
        e.setDuree(d.getDuree() != null && d.getDuree() > 0 ? d.getDuree() : 60);
        e.setType(d.getType());
        e.setInterviewer(d.getInterviewer());
    }
}