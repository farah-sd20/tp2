package tn.delice.delijob.repository;

import tn.delice.delijob.entity.Candidature;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface CandidatureRepository extends JpaRepository<Candidature, Long> {

    List<Candidature> findAllByOrderByDateCandidatureDesc();

    List<Candidature> findByCandidatEmailOrderByDateCandidatureDesc(String email);

    boolean existsByCandidatEmailAndOffreId(String email, Long offreId);

    long countByStatut(String statut);
}