package tn.delice.delijob.dto;

public class RegisterRequest {

    private String prenom;
    private String nom;
    private String email;
    private String departement;
    private String password;

    // ── Constructeur utilisé par le controller multipart ─────────────
    public RegisterRequest(String prenom, String nom, String email,
                           String departement, String password) {
        this.prenom      = prenom;
        this.nom         = nom;
        this.email       = email;
        this.departement = departement;
        this.password    = password;
    }

    public RegisterRequest() {}

    // ── Getters ──────────────────────────────────────────────────────
    public String getPrenom()      { return prenom; }
    public String getNom()         { return nom; }
    public String getEmail()       { return email; }
    public String getDepartement() { return departement; }
    public String getPassword()    { return password; }

    // ── Setters ──────────────────────────────────────────────────────
    public void setPrenom(String prenom)           { this.prenom = prenom; }
    public void setNom(String nom)                 { this.nom = nom; }
    public void setEmail(String email)             { this.email = email; }
    public void setDepartement(String d)           { this.departement = d; }
    public void setPassword(String password)       { this.password = password; }
}