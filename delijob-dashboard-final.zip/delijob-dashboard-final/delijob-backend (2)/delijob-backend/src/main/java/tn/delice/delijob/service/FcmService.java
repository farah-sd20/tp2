package tn.delice.delijob.service;

import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.FirebaseMessagingException;
import com.google.firebase.messaging.Message;
import com.google.firebase.messaging.Notification;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * Service d'envoi de notifications push Firebase (FCM).
 * Appelé depuis CandidatureController après chaque changement de statut.
 */
@Service
public class FcmService {

    // ── Messages par statut ────────────────────────────────────────────────────
    // Chaque entrée : { icône, titre, message }
    private static final Map<String, String[]> STATUT_CONFIG = Map.of(
            "Nouveau",         new String[]{"📥", "Candidature reçue",
                    "Votre candidature a bien été enregistrée."},
            "Entretien RH",    new String[]{"🗣️", "Entretien RH planifié",
                    "Vous êtes convoqué(e) à un entretien RH. Consultez l'application."},
            "Test technique",  new String[]{"🧪", "Test technique",
                    "Vous passez à l'étape test technique. Bonne chance !"},
            "Entretien final", new String[]{"🎯", "Entretien final",
                    "Félicitations ! Vous accédez à l'entretien final."},
            "Retenu",          new String[]{"✅", "Candidature retenue !",
                    "Félicitations ! Votre candidature a été retenue. Nous vous contacterons très prochainement."},
            "Refusé",          new String[]{"❌", "Candidature non retenue",
                    "Nous n'avons pas retenu votre candidature. Merci de votre intérêt."}
    );

    /**
     * Envoie une notification push au candidat via son token FCM.
     *
     * @param fcmToken   token FCM de l'appareil Android du candidat
     * @param nomCandidat nom complet du candidat (pour les logs)
     * @param newStatut  nouveau statut de la candidature
     */
    public void sendStatusNotification(String fcmToken, String nomCandidat, String newStatut) {

        if (fcmToken == null || fcmToken.isBlank()) {
            System.out.println("[FCM] Token absent pour " + nomCandidat + " — notification ignorée.");
            return;
        }

        String[] cfg = STATUT_CONFIG.getOrDefault(newStatut,
                new String[]{"🔔", "Mise à jour de votre candidature",
                        "Le statut de votre candidature a été mis à jour : " + newStatut});

        String icone   = cfg[0];
        String titre   = cfg[1];
        String message = cfg[2];

        try {
            Message fcmMessage = Message.builder()
                    .setToken(fcmToken)
                    // ── Notification visible dans la barre système ──
                    .setNotification(Notification.builder()
                            .setTitle(icone + " " + titre)
                            .setBody(message)
                            .build())
                    // ── Data payload : reçu dans onMessageReceived()
                    //    même quand l'app est en arrière-plan ──
                    .putData("statut",  newStatut)
                    .putData("titre",   titre)
                    .putData("message", message)
                    .putData("icone",   icone)
                    .putData("type",    "statut_update")
                    .build();

            String response = FirebaseMessaging.getInstance().send(fcmMessage);
            System.out.println("[FCM] ✅ Notification envoyée à " + nomCandidat
                    + " | statut=" + newStatut + " | msgId=" + response);

        } catch (FirebaseMessagingException e) {
            // Token invalide ou expiré → log sans planter l'API
            System.err.println("[FCM] ❌ Erreur envoi à " + nomCandidat
                    + " : " + e.getMessage());
        }
    }
}