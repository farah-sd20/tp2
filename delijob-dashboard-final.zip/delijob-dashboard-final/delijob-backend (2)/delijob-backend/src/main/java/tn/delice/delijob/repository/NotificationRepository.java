package tn.delice.delijob.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import tn.delice.delijob.entity.Notification;
import java.util.List;

public interface NotificationRepository extends JpaRepository<Notification, Long> {

    /** Toutes les notifs d'un user, du plus récent au plus ancien */
    Page<Notification> findByUserIdOrderByCreatedAtDesc(Long userId, Pageable pageable);

    /** Liste complète sans pagination (pour le dropdown topbar, limiter à 20) */
    List<Notification> findTop20ByUserIdOrderByCreatedAtDesc(Long userId);

    /** Nombre de notifs non lues */
    long countByUserIdAndLuFalse(Long userId);

    /** Marquer UNE notif comme lue */
    @Modifying
    @Query("UPDATE Notification n SET n.lu = true, n.readAt = CURRENT_TIMESTAMP " +
            "WHERE n.id = :id AND n.user.id = :userId")
    int markAsRead(@Param("id") Long id, @Param("userId") Long userId);

    /** Marquer TOUTES les notifs d'un user comme lues */
    @Modifying
    @Query("UPDATE Notification n SET n.lu = true, n.readAt = CURRENT_TIMESTAMP " +
            "WHERE n.user.id = :userId AND n.lu = false")
    int markAllAsRead(@Param("userId") Long userId);

    /** Supprimer UNE notif (appartenant au user) */
    @Modifying
    @Query("DELETE FROM Notification n WHERE n.id = :id AND n.user.id = :userId")
    int deleteByIdAndUserId(@Param("id") Long id, @Param("userId") Long userId);

    /** Supprimer TOUTES les notifs d'un user */
    @Modifying
    @Query("DELETE FROM Notification n WHERE n.user.id = :userId")
    int deleteAllByUserId(@Param("userId") Long userId);
}