package tn.delice.delijob.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "candidatures")
public class Candidature {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "candidat_email")
    private String candidatEmail;

    @Column(name = "candidat_nom")
    private String candidatNom;

    @Column(name = "candidat_prenom")
    private String candidatPrenom;

    @Column(name = "offre_id")
    private Long offreId;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "offre_id", insertable = false, updatable = false)
    private Offre offre;

    @Column(name = "statut")
    private String statut = "EN_ATTENTE";

    @Column(name = "date_postulation")
    private LocalDateTime dateCandidature;

    @Column(name = "cv_path")
    private String cvPath;

    // --- Constructeurs ---
    public Candidature() {}

    public Candidature(String candidatEmail, String candidatNom, String candidatPrenom,
                       Long offreId, String cvPath) {
        this.candidatEmail   = candidatEmail;
        this.candidatNom     = candidatNom;
        this.candidatPrenom  = candidatPrenom;
        this.offreId         = offreId;
        this.cvPath          = cvPath;
        this.statut          = "EN_ATTENTE";
        this.dateCandidature = LocalDateTime.now();
    }

    // --- Getters & Setters ---

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getCandidatEmail() { return candidatEmail; }
    public void setCandidatEmail(String candidatEmail) { this.candidatEmail = candidatEmail; }

    public String getCandidatNom() { return candidatNom; }
    public void setCandidatNom(String candidatNom) { this.candidatNom = candidatNom; }

    public String getCandidatPrenom() { return candidatPrenom; }
    public void setCandidatPrenom(String candidatPrenom) { this.candidatPrenom = candidatPrenom; }

    public Long getOffreId() { return offreId; }
    public void setOffreId(Long offreId) { this.offreId = offreId; }

    public Offre getOffre() { return offre; }
    public void setOffre(Offre offre) {
        this.offre = offre;
        if (offre != null) this.offreId = offre.getId();
    }

    public String getStatut() { return statut; }
    public void setStatut(String statut) { this.statut = statut; }

    public LocalDateTime getDateCandidature() { return dateCandidature; }
    public void setDateCandidature(LocalDateTime dateCandidature) { this.dateCandidature = dateCandidature; }

    public String getCvPath() { return cvPath; }
    public void setCvPath(String cvPath) { this.cvPath = cvPath; }

    @JsonProperty
    public String getCandidatFullName() {
        return (candidatPrenom != null ? candidatPrenom + " " : "")
                + (candidatNom    != null ? candidatNom    : "");
    }

    @Override
    public String toString() {
        return "Candidature{id=" + id
                + ", candidatEmail='" + candidatEmail + '\''
                + ", candidatNom='"   + candidatNom   + '\''
                + ", statut='"        + statut        + '\''
                + ", dateCandidature=" + dateCandidature + '}';
    }
}