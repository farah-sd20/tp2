package tn.delice.delijob.controller;

import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.multipart.MultipartFile;
import tn.delice.delijob.entity.Candidature;
import tn.delice.delijob.entity.NotifStatut;
import tn.delice.delijob.entity.Offre;
import tn.delice.delijob.entity.User;
import tn.delice.delijob.repository.CandidatureRepository;
import tn.delice.delijob.repository.NotifStatutRepository;
import tn.delice.delijob.repository.OffreRepository;
import tn.delice.delijob.repository.UserRepository;
import tn.delice.delijob.security.JwtUtil;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.*;

@RestController
@RequestMapping("/api/candidatures")
public class CandidatureController {

    private final CandidatureRepository candidatureRepo;
    private final NotifStatutRepository notifRepo;
    private final OffreRepository       offreRepo;
    private final UserRepository        userRepo;
    private final JwtUtil               jwtUtil;

    // Dossier de stockage des CVs (dans le home de l'utilisateur système)
    private static final String CV_UPLOAD_DIR =
            System.getProperty("user.home") + "/delijob-cvs/";

    public CandidatureController(CandidatureRepository candidatureRepo,
                                 NotifStatutRepository notifRepo,
                                 OffreRepository offreRepo,
                                 UserRepository userRepo,
                                 JwtUtil jwtUtil) {
        this.candidatureRepo = candidatureRepo;
        this.notifRepo       = notifRepo;
        this.offreRepo       = offreRepo;
        this.userRepo        = userRepo;
        this.jwtUtil         = jwtUtil;
    }

    private String emailFromHeader(String authHeader) {
        if (authHeader == null || !authHeader.startsWith("Bearer ")) return null;
        return jwtUtil.extractEmail(authHeader.substring(7));
    }

    private String roleOf(User u) {
        return (u != null && u.getRole() != null) ? u.getRole().name() : "";
    }

    private boolean isRH(User u) {
        String r = roleOf(u);
        return r.equals("RH") || r.equals("ADMIN") || r.equals("RECRUTEUR");
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  UTILITAIRE  →  Sauvegarder un fichier CV sur disque
    // ═══════════════════════════════════════════════════════════════════════════
    private String saveCvFile(MultipartFile file) throws IOException {
        Files.createDirectories(Paths.get(CV_UPLOAD_DIR));
        String safeName = System.currentTimeMillis() + "_"
                + file.getOriginalFilename().replaceAll("[^a-zA-Z0-9._-]", "_");
        Path dest = Paths.get(CV_UPLOAD_DIR + safeName);
        Files.write(dest, file.getBytes());
        return dest.toAbsolutePath().toString();
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  0.  GET /api/candidatures  →  alias de /toutes
    // ═══════════════════════════════════════════════════════════════════════════
    @GetMapping
    public ResponseEntity<?> getAllCandidatures(
            @RequestHeader("Authorization") String auth) {
        return toutesCandidatures(auth);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  1.  POST /api/candidatures/{offreId}  →  Postuler (avec CV optionnel)
    // ═══════════════════════════════════════════════════════════════════════════
    @PostMapping(value = "/{offreId}", consumes = "multipart/form-data")
    public ResponseEntity<?> postuler(
            @PathVariable Long offreId,
            @RequestParam("cv") MultipartFile cvFile,  // ← obligatoire, pas "required = false"
            @RequestHeader("Authorization") String auth) {

        String email = emailFromHeader(auth);
        if (email == null) return ResponseEntity.status(401).body("Token invalide");

        User user = userRepo.findByEmail(email).orElse(null);
        if (user == null) return ResponseEntity.status(404).body("Utilisateur introuvable");

        Offre offre = offreRepo.findById(offreId).orElse(null);
        if (offre == null) return ResponseEntity.status(404).body("Offre introuvable");

        if (candidatureRepo.existsByCandidatEmailAndOffreId(email, offreId))
            return ResponseEntity.status(409).body("Vous avez déjà postulé à cette offre");

        // ✅ Vérification CV obligatoire
        if (cvFile == null || cvFile.isEmpty())
            return ResponseEntity.status(400).body("Le CV est obligatoire pour postuler");

        Candidature c = new Candidature();
        c.setCandidatEmail(user.getEmail());
        c.setCandidatNom(user.getNom() != null ? user.getNom() : "");
        c.setCandidatPrenom(user.getPrenom() != null ? user.getPrenom() : "");
        c.setOffreId(offreId);
        c.setStatut("EN_ATTENTE");
        c.setDateCandidature(LocalDateTime.now());

        try {
            c.setCvPath(saveCvFile(cvFile));
        } catch (IOException e) {
            return ResponseEntity.status(500).body("Erreur sauvegarde CV : " + e.getMessage());
        }

        candidatureRepo.save(c);

        return ResponseEntity.ok(Map.of(
                "message",       "Candidature envoyée avec succès",
                "candidatureId", c.getId(),
                "cvJoint",       true  // ← toujours true maintenant
        ));
    }
    // ═══════════════════════════════════════════════════════════════════════════
    //  2.  GET /api/candidatures/moi  →  Mes candidatures
    // ═══════════════════════════════════════════════════════════════════════════
    @GetMapping("/moi")
    public ResponseEntity<?> mesCandidatures(
            @RequestHeader("Authorization") String auth) {

        String email = emailFromHeader(auth);
        if (email == null) return ResponseEntity.status(401).body("Token invalide");

        List<Candidature> list =
                candidatureRepo.findByCandidatEmailOrderByDateCandidatureDesc(email);

        List<Map<String, Object>> result = new ArrayList<>();
        for (Candidature c : list) {
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("id",              c.getId());
            item.put("statut",          c.getStatut());
            item.put("dateCandidature", c.getDateCandidature() != null
                    ? c.getDateCandidature().toString() : "");
            item.put("offreId",         c.getOffreId());
            item.put("offreTitre",      c.getOffre() != null ? c.getOffre().getTitre() : "—");
            item.put("cvDisponible",    c.getCvPath() != null);
            result.add(item);
        }
        return ResponseEntity.ok(result);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  3.  PUT /api/candidatures/{id}/statut  →  Changer statut
    // ═══════════════════════════════════════════════════════════════════════════
    @PutMapping("/{id}/statut")
    public ResponseEntity<?> changerStatut(
            @PathVariable Long id,
            @RequestBody Map<String, String> body,
            @RequestHeader("Authorization") String auth) {

        String emailRH = emailFromHeader(auth);
        if (emailRH == null) return ResponseEntity.status(401).body("Token invalide");

        User rh = userRepo.findByEmail(emailRH).orElse(null);
        if (rh == null || !isRH(rh))
            return ResponseEntity.status(403).body("Accès refusé");

        Candidature c = candidatureRepo.findById(id).orElse(null);
        if (c == null) return ResponseEntity.status(404).body("Candidature introuvable");

        String nouveauStatut = body.get("statut");
        if (nouveauStatut == null || nouveauStatut.isBlank())
            return ResponseEntity.badRequest().body("Statut requis");

        String ancienStatut = c.getStatut();
        c.setStatut(nouveauStatut);
        candidatureRepo.save(c);

        String offreTitre = c.getOffre() != null ? c.getOffre().getTitre() : "—";
        String msg = buildMessage(nouveauStatut, offreTitre);

        User candidat = userRepo.findByEmail(c.getCandidatEmail()).orElse(null);
        if (candidat != null) {
            NotifStatut notif = new NotifStatut(
                    candidat.getId(), c.getOffreId(), offreTitre, nouveauStatut, msg);
            notifRepo.save(notif);
        }

        return ResponseEntity.ok(Map.of(
                "message",       "Statut mis à jour : " + ancienStatut + " → " + nouveauStatut,
                "candidatureId", c.getId(),
                "nouveauStatut", nouveauStatut
        ));
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  4.  GET /api/candidatures/moi/notifications
    // ═══════════════════════════════════════════════════════════════════════════
    @GetMapping("/moi/notifications")
    public ResponseEntity<?> mesNotifications(
            @RequestHeader("Authorization") String auth) {

        String email = emailFromHeader(auth);
        if (email == null) return ResponseEntity.status(401).body("Token invalide");

        User user = userRepo.findByEmail(email).orElse(null);
        if (user == null) return ResponseEntity.status(404).body("Utilisateur introuvable");

        List<NotifStatut> notifs =
                notifRepo.findByUserIdAndLuFalseOrderByCreatedAtDesc(user.getId());

        List<Map<String, Object>> result = new ArrayList<>();
        for (NotifStatut n : notifs) {
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("id",         n.getId());
            item.put("offreId",    n.getOffreId());
            item.put("offreTitre", n.getOffreTitre());
            item.put("statut",     n.getNouveauStatut());
            item.put("message",    n.getMessage());
            item.put("createdAt",  n.getCreatedAt().toString());
            result.add(item);
        }
        return ResponseEntity.ok(result);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  5.  POST /api/candidatures/moi/notifications/{notifId}/lu
    // ═══════════════════════════════════════════════════════════════════════════
    @PostMapping("/moi/notifications/{notifId}/lu")
    public ResponseEntity<?> marquerLue(
            @PathVariable Long notifId,
            @RequestHeader("Authorization") String auth) {

        String email = emailFromHeader(auth);
        if (email == null) return ResponseEntity.status(401).body("Token invalide");

        User user = userRepo.findByEmail(email).orElse(null);
        if (user == null) return ResponseEntity.status(404).body("Utilisateur introuvable");

        int updated = notifRepo.markAsRead(notifId, user.getId());
        if (updated == 0) return ResponseEntity.status(404).body("Notification introuvable");

        return ResponseEntity.ok(Map.of("message", "Notification marquée comme lue"));
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  6.  POST /api/candidatures/moi/notifications/tout-lu
    // ═══════════════════════════════════════════════════════════════════════════
    @PostMapping("/moi/notifications/tout-lu")
    public ResponseEntity<?> toutMarquerLu(
            @RequestHeader("Authorization") String auth) {

        String email = emailFromHeader(auth);
        if (email == null) return ResponseEntity.status(401).body("Token invalide");

        User user = userRepo.findByEmail(email).orElse(null);
        if (user == null) return ResponseEntity.status(404).body("Utilisateur introuvable");

        int count = notifRepo.markAllAsRead(user.getId());
        return ResponseEntity.ok(Map.of("marquees", count));
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  7.  GET /api/candidatures/toutes
    // ═══════════════════════════════════════════════════════════════════════════
    @GetMapping("/toutes")
    public ResponseEntity<?> toutesCandidatures(
            @RequestHeader("Authorization") String auth) {

        String email = emailFromHeader(auth);
        if (email == null) return ResponseEntity.status(401).body("Token invalide");

        User rh = userRepo.findByEmail(email).orElse(null);
        if (rh == null || !isRH(rh))
            return ResponseEntity.status(403).body("Accès refusé - role=" + roleOf(rh));

        List<Candidature> list = candidatureRepo.findAllByOrderByDateCandidatureDesc();

        List<Map<String, Object>> result = new ArrayList<>();
        for (Candidature c : list) {
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("id",              c.getId());
            item.put("statut",          c.getStatut());
            item.put("dateCandidature", c.getDateCandidature() != null
                    ? c.getDateCandidature().toString() : "");
            item.put("candidatId",      c.getId());
            item.put("candidatNom",     (c.getCandidatNom()    != null ? c.getCandidatNom()    : "")
                    + " " + (c.getCandidatPrenom() != null ? c.getCandidatPrenom() : ""));
            item.put("candidatEmail",   c.getCandidatEmail() != null ? c.getCandidatEmail() : "");
            item.put("offreId",         c.getOffreId());
            item.put("offreTitre",      c.getOffre() != null ? c.getOffre().getTitre() : "—");
            item.put("cvDisponible",    c.getCvPath() != null);   // ← utile côté React
            result.add(item);
        }
        return ResponseEntity.ok(result);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  8.  GET /api/candidatures/pipeline
    // ═══════════════════════════════════════════════════════════════════════════
    @GetMapping("/pipeline")
    public ResponseEntity<?> getPipeline(
            @RequestHeader("Authorization") String auth) {

        String email = emailFromHeader(auth);
        if (email == null) return ResponseEntity.status(401).body("Token invalide");

        User rh = userRepo.findByEmail(email).orElse(null);
        if (rh == null || !isRH(rh))
            return ResponseEntity.status(403).body("Accès refusé");

        Map<String, Long> pipeline = new LinkedHashMap<>();
        pipeline.put("EN_ATTENTE",      candidatureRepo.countByStatut("EN_ATTENTE"));
        pipeline.put("ENTRETIEN",       candidatureRepo.countByStatut("ENTRETIEN"));
        pipeline.put("TEST_TECHNIQUE",  candidatureRepo.countByStatut("TEST_TECHNIQUE"));
        pipeline.put("ENTRETIEN_FINAL", candidatureRepo.countByStatut("ENTRETIEN_FINAL"));
        pipeline.put("ACCEPTE",         candidatureRepo.countByStatut("ACCEPTE"));
        pipeline.put("REFUSE",          candidatureRepo.countByStatut("REFUSE"));

        return ResponseEntity.ok(pipeline);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  9.  GET /api/candidatures/{id}/cv  →  Télécharger / Visionner le CV
    // ═══════════════════════════════════════════════════════════════════════════
    @GetMapping("/{id}/cv")
    public ResponseEntity<?> getCv(
            @PathVariable Long id,
            @RequestHeader("Authorization") String auth) {

        String email = emailFromHeader(auth);
        if (email == null) return ResponseEntity.status(401).body("Token invalide");

        User user = userRepo.findByEmail(email).orElse(null);
        if (user == null) return ResponseEntity.status(404).body("Utilisateur introuvable");

        Candidature c = candidatureRepo.findById(id).orElse(null);
        if (c == null) return ResponseEntity.status(404).body("Candidature introuvable");

        // Seuls le RH/ADMIN/RECRUTEUR ou le candidat lui-même peuvent voir le CV
        if (!isRH(user) && !c.getCandidatEmail().equals(email))
            return ResponseEntity.status(403).body("Accès refusé");

        if (c.getCvPath() == null || c.getCvPath().isBlank())
            return ResponseEntity.status(404).body("Aucun CV associé à cette candidature");

        try {
            Path filePath = Paths.get(c.getCvPath());
            Resource resource = new UrlResource(filePath.toUri());

            if (!resource.exists() || !resource.isReadable())
                return ResponseEntity.status(404).body("Fichier CV introuvable sur le serveur");

            String contentType = Files.probeContentType(filePath);
            if (contentType == null) contentType = "application/octet-stream";

            return ResponseEntity.ok()
                    .contentType(MediaType.parseMediaType(contentType))
                    .header(HttpHeaders.CONTENT_DISPOSITION,
                            "inline; filename=\"" + resource.getFilename() + "\"")
                    .body(resource);

        } catch (IOException e) {
            return ResponseEntity.status(500).body("Erreur lors de la lecture du CV");
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  10. POST /api/candidatures/{id}/cv  →  Upload CV (après postulation)
    // ═══════════════════════════════════════════════════════════════════════════
    @PostMapping("/{id}/cv")
    public ResponseEntity<?> uploadCv(
            @PathVariable Long id,
            @RequestParam("cv") MultipartFile cvFile,
            @RequestHeader("Authorization") String auth) {

        String email = emailFromHeader(auth);
        if (email == null) return ResponseEntity.status(401).body("Token invalide");

        User user = userRepo.findByEmail(email).orElse(null);
        if (user == null) return ResponseEntity.status(404).body("Utilisateur introuvable");

        Candidature c = candidatureRepo.findById(id).orElse(null);
        if (c == null) return ResponseEntity.status(404).body("Candidature introuvable");

        // Le candidat lui-même ou un RH peut uploader
        if (!isRH(user) && !c.getCandidatEmail().equals(email))
            return ResponseEntity.status(403).body("Accès refusé");

        if (cvFile == null || cvFile.isEmpty())
            return ResponseEntity.badRequest().body("Fichier CV requis");

        try {
            // Supprimer l'ancien fichier si existant
            if (c.getCvPath() != null) {
                try { Files.deleteIfExists(Paths.get(c.getCvPath())); }
                catch (IOException ignored) {}
            }

            c.setCvPath(saveCvFile(cvFile));
            candidatureRepo.save(c);
            return ResponseEntity.ok(Map.of("message", "CV uploadé avec succès"));

        } catch (IOException e) {
            return ResponseEntity.status(500).body("Erreur upload CV : " + e.getMessage());
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    private String buildMessage(String statut, String titre) {
        return switch (statut) {
            case "ACCEPTE"    -> "🎉 Félicitations ! Votre candidature pour « " + titre + " » a été acceptée.";
            case "REFUSE"     -> "Votre candidature pour « " + titre + " » n'a pas été retenue.";
            case "ENTRETIEN"  -> "📅 Vous êtes invité(e) à un entretien pour « " + titre + " ».";
            case "EN_ATTENTE" -> "Votre candidature pour « " + titre + " » est en cours d'examen.";
            default           -> "Mise à jour de votre candidature pour « " + titre + " » : " + statut;
        };
    }

}