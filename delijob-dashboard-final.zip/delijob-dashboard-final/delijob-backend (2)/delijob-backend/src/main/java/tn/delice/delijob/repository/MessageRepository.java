package tn.delice.delijob.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import tn.delice.delijob.entity.Message;
import java.util.List;

@Repository
public interface MessageRepository extends JpaRepository<Message, Long> {

    @Query("SELECT m FROM Message m WHERE m.recruiterId = :recruiterId ORDER BY m.createdAt ASC")
    List<Message> findConversation(@Param("recruiterId") Long recruiterId);

    @Query("SELECT m.recruiterId, COUNT(m) FROM Message m WHERE m.senderRole = 'RECRUTEUR' AND m.readByAdmin = false GROUP BY m.recruiterId")
    List<Object[]> countUnreadGroupedByRecruiter();

    @Query("SELECT m FROM Message m WHERE m.senderRole = 'ADMIN' AND m.recruiterId = :recruiterId AND m.readByAdmin = false")
    List<Message> findUnreadAdminMessages(@Param("recruiterId") Long recruiterId);
}