package tn.delice.delijob.service;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import tn.delice.delijob.dto.*;
import tn.delice.delijob.entity.Recruteur;
import tn.delice.delijob.repository.RecruteurRepository;

import java.io.IOException;
import java.nio.file.*;

@Service
public class RecruteurService {

    private final RecruteurRepository repo;
    private final PasswordEncoder passwordEncoder;

    /**
     * CORRECTION : Le chemin de l'URL stockée en base doit correspondre
     * au mapping du controller : "/api/recruteur/photos/{filename}"
     * (l'ancien chemin "/api/recruteur/photos/" était correct côté stockage
     * mais le controller exposait "/api/photos/" — maintenant aligné)
     */
    private static final String UPLOAD_DIR   = "uploads/photos/";
    private static final String PHOTO_URL_PREFIX = "/api/recruteur/photos/";

    public RecruteurService(RecruteurRepository repo, PasswordEncoder passwordEncoder) {
        this.repo = repo;
        this.passwordEncoder = passwordEncoder;
    }

    public RecruteurProfilDTO getProfil(String email) {
        Recruteur r = repo.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Recruteur non trouvé : " + email));
        System.out.println("📋 getProfil → photoUrl: " + r.getPhotoUrl());
        return toDTO(r);
    }

    public RecruteurProfilDTO updateProfil(String email, UpdateProfilRequest req) {
        Recruteur r = repo.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Recruteur non trouvé : " + email));
        if (req.getPrenom() != null && !req.getPrenom().isBlank()) r.setPrenom(req.getPrenom());
        if (req.getNom()    != null && !req.getNom().isBlank())    r.setNom(req.getNom());
        if (req.getTelephone() != null) r.setTelephone(req.getTelephone());
        if (req.getPoste()     != null) r.setPoste(req.getPoste());
        return toDTO(repo.save(r));
    }

    public String updatePhoto(String email, MultipartFile file) throws IOException {
        Recruteur r = repo.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Recruteur non trouvé : " + email));

        System.out.println("📸 updatePhoto — email: " + email);
        System.out.println("📸 fichier: " + file.getOriginalFilename()
                + " | taille: " + file.getSize()
                + " | type: "   + file.getContentType());

        // Créer le dossier uploads/photos/ si absent
        Path uploadPath = Paths.get(UPLOAD_DIR).toAbsolutePath();
        if (!Files.exists(uploadPath)) {
            Files.createDirectories(uploadPath);
            System.out.println("📁 Dossier créé : " + uploadPath);
        }

        // Supprimer l'ancienne photo si elle existe
        if (r.getPhotoUrl() != null) {
            String oldFilename = r.getPhotoUrl().replace(PHOTO_URL_PREFIX, "");
            Path oldFile = uploadPath.resolve(oldFilename);
            boolean deleted = Files.deleteIfExists(oldFile);
            System.out.println("🗑️ Ancienne photo supprimée: " + deleted + " → " + oldFile);
        }

        // Générer un nom de fichier unique
        String ext = getExtension(file.getOriginalFilename());
        String filename = email.replaceAll("[^a-zA-Z0-9]", "_")
                + "_" + System.currentTimeMillis() + "." + ext;
        Path dest = uploadPath.resolve(filename);

        // Écrire le fichier sur le disque
        Files.copy(file.getInputStream(), dest, StandardCopyOption.REPLACE_EXISTING);
        System.out.println("✅ Photo sauvegardée : " + dest);

        // URL relative retournée au frontend — alignée avec le mapping controller
        String photoUrl = PHOTO_URL_PREFIX + filename;
        r.setPhotoUrl(photoUrl);
        Recruteur saved = repo.save(r);
        System.out.println("✅ photoUrl sauvegardée en base : " + saved.getPhotoUrl());

        return photoUrl;
    }

    public void removePhoto(String email) throws IOException {
        Recruteur r = repo.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Recruteur non trouvé : " + email));
        if (r.getPhotoUrl() != null) {
            String filename = r.getPhotoUrl().replace(PHOTO_URL_PREFIX, "");
            Path uploadPath = Paths.get(UPLOAD_DIR).toAbsolutePath();
            boolean deleted = Files.deleteIfExists(uploadPath.resolve(filename));
            System.out.println("🗑️ Photo supprimée depuis le disque : " + deleted + " → " + filename);
            r.setPhotoUrl(null);
            repo.save(r);
        }
    }

    public void changePassword(String email, ChangePasswordRequest req) {
        Recruteur r = repo.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Recruteur non trouvé : " + email));
        if (!passwordEncoder.matches(req.getCurrentPassword(), r.getPassword()))
            throw new RuntimeException("Mot de passe actuel incorrect");
        r.setPassword(passwordEncoder.encode(req.getNewPassword()));
        repo.save(r);
    }

    private RecruteurProfilDTO toDTO(Recruteur r) {
        return new RecruteurProfilDTO(
                r.getId(), r.getPrenom(), r.getNom(), r.getEmail(),
                r.getTelephone(), r.getPoste(), r.getDepartement(),
                r.getPhotoUrl(), r.getRole()
        );
    }

    private String getExtension(String filename) {
        if (filename == null || !filename.contains(".")) return "jpg";
        return filename.substring(filename.lastIndexOf('.') + 1).toLowerCase();
    }
}