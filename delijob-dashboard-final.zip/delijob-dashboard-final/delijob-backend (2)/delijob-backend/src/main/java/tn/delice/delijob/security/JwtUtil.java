package tn.delice.delijob.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
public class JwtUtil {

    @Value("${jwt.secret:delijobSecretKey2025WithEnoughLengthForHS256}")
    private String SECRET_KEY;

    @Value("${jwt.expiration:86400000}")
    private long EXPIRATION_TIME;

    // ✅ Méthode generate() - CORRECTION PRINCIPALE
    public String generate(String email, String role) {
        return Jwts.builder()
                .setSubject(email)
                .claim("role", role)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + EXPIRATION_TIME))
                .signWith(SignatureAlgorithm.HS256, SECRET_KEY.getBytes())
                .compact();
    }

    // ✅ Méthode extractEmail()
    public String extractEmail(String token) {
        return getClaims(token).getSubject();
    }

    // ✅ Méthode extractRole()
    public String extractRole(String token) {
        Claims claims = getClaims(token);
        Object role = claims.get("role");
        return role != null ? role.toString() : null;
    }

    // ✅ Méthode validate()
    public boolean validate(String token) {
        try {
            getClaims(token);
            return true;
        } catch (Exception e) {
            System.out.println("Token validation error: " + e.getMessage());
            return false;
        }
    }

    // ✅ Méthode getClaims()
    private Claims getClaims(String token) {
        return Jwts.parser()
                .setSigningKey(SECRET_KEY.getBytes())
                .parseClaimsJws(token)
                .getBody();
    }
}