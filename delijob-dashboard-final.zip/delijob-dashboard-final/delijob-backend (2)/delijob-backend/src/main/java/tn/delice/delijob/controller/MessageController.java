package tn.delice.delijob.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import tn.delice.delijob.entity.Message;
import tn.delice.delijob.entity.User;
import tn.delice.delijob.repository.UserRepository;
import tn.delice.delijob.service.MessageService;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/messages")
public class MessageController {

    private final MessageService service;
    private final UserRepository userRepository;

    public MessageController(MessageService service, UserRepository userRepository) {
        this.service = service;
        this.userRepository = userRepository;
    }

    // ==================== ENDPOINTS RECRUTEUR ====================

    @GetMapping
    public ResponseEntity<?> getMessages(Authentication auth) {
        User user = extractUser(auth);

        if ("ADMIN".equals(user.getRole().name())) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN)
                    .body(Map.of("error", "Les admins utilisent /api/admin/messages/{recruiterId}"));
        }

        List<Message> messages = service.getRecruiterMessages(user.getId());
        return ResponseEntity.ok(messages);
    }

    @GetMapping("/unread")
    public ResponseEntity<?> getUnreadCount(Authentication auth) {
        User user = extractUser(auth);

        if (user.getRole() == User.Role.ADMIN) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN)
                    .body(Map.of("error", "Utilisez /api/admin/messages/unread"));
        }

        long count = service.getRecruiterMessages(user.getId())
                .stream()
                .filter(m -> m.getSenderRole() == Message.SenderRole.ADMIN && !m.isReadByAdmin())
                .count();
        return ResponseEntity.ok(Map.of("unread", count));
    }

    @PostMapping
    public ResponseEntity<?> send(
            @RequestBody Map<String, String> body,
            Authentication auth) {

        if (body.get("content") == null || body.get("content").isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Le contenu ne peut pas être vide"));
        }

        User user = extractUser(auth);

        if (user.getRole() == User.Role.ADMIN) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN)
                    .body(Map.of("error", "Les admins utilisent /api/admin/messages/{recruiterId}"));
        }

        Message m = service.sendAsRecruiter(user.getId(), body.get("content"));
        return ResponseEntity.status(HttpStatus.CREATED).body(m);
    }

    @PutMapping("/{messageId}")
    public ResponseEntity<?> updateMessage(
            @PathVariable Long messageId,
            @RequestBody Map<String, String> body,
            Authentication auth) {

        User user = extractUser(auth);
        String newContent = body.get("content");

        if (newContent == null || newContent.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Le contenu ne peut pas être vide"));
        }

        Message message = service.getMessageById(messageId);
        if (message == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", "Message non trouvé"));
        }

        // Vérifier que l'utilisateur est bien l'expéditeur
        if (!message.getSenderId().equals(user.getId())) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN)
                    .body(Map.of("error", "Vous ne pouvez modifier que vos propres messages"));
        }

        // Seuls les RECRUTEURS peuvent modifier leurs messages
        if (user.getRole() != User.Role.RECRUTEUR) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN)
                    .body(Map.of("error", "Seuls les recruteurs peuvent modifier leurs messages"));
        }

        Message updated = service.updateMessageContent(messageId, newContent);
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/{messageId}")
    public ResponseEntity<?> deleteMessage(
            @PathVariable Long messageId,
            Authentication auth) {

        User user = extractUser(auth);

        Message message = service.getMessageById(messageId);
        if (message == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", "Message non trouvé"));
        }

        // Vérifier que l'utilisateur est bien l'expéditeur
        if (!message.getSenderId().equals(user.getId())) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN)
                    .body(Map.of("error", "Vous ne pouvez supprimer que vos propres messages"));
        }

        // Seuls les RECRUTEURS peuvent supprimer leurs messages
        if (user.getRole() != User.Role.RECRUTEUR) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN)
                    .body(Map.of("error", "Seuls les recruteurs peuvent supprimer leurs messages"));
        }

        service.deleteMessage(messageId);
        return ResponseEntity.ok(Map.of("success", true, "message", "Message supprimé avec succès"));
    }

    // ==================== ENDPOINTS ADMIN ====================

    private User extractUser(Authentication auth) {
        if (auth == null || auth.getPrincipal() == null) {
            throw new RuntimeException("Utilisateur non authentifié");
        }

        String email = (String) auth.getPrincipal();
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Utilisateur introuvable : " + email));
    }
}