package tn.delice.delijob.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import tn.delice.delijob.entity.Recruteur;
import java.util.Optional;

public interface RecruteurRepository extends JpaRepository<Recruteur, Long> {
    Optional<Recruteur> findByEmail(String email);
    boolean existsByEmail(String email);
}