package tn.delice.delijob.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import tn.delice.delijob.dto.Entretiendto;
import tn.delice.delijob.service.Entretienservice;

import java.util.List;

@RestController
@RequestMapping("/api/entretiens")
@CrossOrigin(origins = "http://localhost:5173")
public class Entretiencontroller {

    private static final Logger log = LoggerFactory.getLogger(Entretiencontroller.class);

    private final Entretienservice service;

    public Entretiencontroller(Entretienservice service) {
        this.service = service;
    }

    // ── GET /api/entretiens?q=dupont  OU  GET /api/entretiens ─────────────
    @GetMapping
    public ResponseEntity<List<Entretiendto>> getAll(
            @RequestParam(required = false) String q) {
        log.info("GET /api/entretiens - q={}", q);
        if (q != null && !q.isEmpty()) {
            return ResponseEntity.ok(service.search(q));
        }
        return ResponseEntity.ok(service.getAll());
    }

    // ── GET /api/entretiens/month?year=2025&month=5 ───────────────────────
    @GetMapping("/month")
    public ResponseEntity<List<Entretiendto>> getByMonth(
            @RequestParam int year,
            @RequestParam int month) {
        log.info("GET /api/entretiens/month - year={}, month={}", year, month);
        return ResponseEntity.ok(service.getByMonth(year, month));
    }

    // ── POST /api/entretiens  → crée l'entretien + envoie l'email ─────────
    @PostMapping
    public ResponseEntity<Entretiendto> create(@RequestBody Entretiendto dto) {
        log.info("POST /api/entretiens - dto={}", dto);
        try {
            Entretiendto created = service.create(dto);
            log.info("Entretien créé avec succès: id={}", created.getId());
            return ResponseEntity.ok(created);
        } catch (Exception e) {
            log.error("Erreur lors de la création: {}", e.getMessage(), e);
            throw e;
        }
    }

    // ── PUT /api/entretiens/{id} ──────────────────────────────────────────
    @PutMapping("/{id}")
    public ResponseEntity<Entretiendto> update(
            @PathVariable Long id,
            @RequestBody Entretiendto dto) {
        log.info("PUT /api/entretiens/{} - dto={}", id, dto);
        return ResponseEntity.ok(service.update(id, dto));
    }

    // ── DELETE /api/entretiens/{id} ───────────────────────────────────────
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        log.info("DELETE /api/entretiens/{}", id);
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}