package tn.delice.delijob.dto;

import tn.delice.delijob.entity.Notification;
import java.time.Instant;

public class NotificationDTO {

    private Long    id;
    private String  type;
    private String  titre;
    private String  message;
    private String  avatar;
    private String  avatarBg;
    private boolean lu;
    private Instant timestamp;
    private Action  action;

    public NotificationDTO() {}

    public static class Action {
        private String label;
        private String url;

        public Action() {}

        public Action(String label, String url) {
            this.label = label;
            this.url   = url;
        }

        public String getLabel() { return label; }
        public void setLabel(String label) { this.label = label; }

        public String getUrl() { return url; }
        public void setUrl(String url) { this.url = url; }
    }

    /** Convertit l'entité en DTO */
    public static NotificationDTO from(Notification n) {
        Action action = null;
        if (n.getActionLabel() != null) {
            action = new Action(n.getActionLabel(), n.getActionUrl());
        }

        NotificationDTO dto = new NotificationDTO();
        dto.setId(n.getId());
        dto.setType(n.getType());
        dto.setTitre(n.getTitre());
        dto.setMessage(n.getMessage());
        dto.setAvatar(n.getAvatar());
        dto.setAvatarBg(n.getAvatarBg());
        dto.setLu(n.isLu());
        dto.setTimestamp(n.getCreatedAt());
        dto.setAction(action);
        return dto;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public String getTitre() { return titre; }
    public void setTitre(String titre) { this.titre = titre; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public String getAvatar() { return avatar; }
    public void setAvatar(String avatar) { this.avatar = avatar; }

    public String getAvatarBg() { return avatarBg; }
    public void setAvatarBg(String avatarBg) { this.avatarBg = avatarBg; }

    public boolean isLu() { return lu; }
    public void setLu(boolean lu) { this.lu = lu; }

    public Instant getTimestamp() { return timestamp; }
    public void setTimestamp(Instant timestamp) { this.timestamp = timestamp; }

    public Action getAction() { return action; }
    public void setAction(Action action) { this.action = action; }
}