package tn.delice.delijob.dto;

import jakarta.validation.constraints.NotBlank;

public class OffreDTO {

    // ── Identifiants ──────────────────────────────────────────────────
    private Long   id;
    private String code;

    // ── Champs obligatoires ───────────────────────────────────────────
    @NotBlank private String titre;
    @NotBlank private String departement;
    @NotBlank private String typeContrat;

  // ── Champs optionnels ─────────────────────────────────────────────
    private String  niveauEtudes;
    private String  experienceRequise;
    private String  description;
    private Integer nbCandidats;
    private String  statut;

    // ── Champs ajoutés pour le mobile ─────────────────────────────────
    private String entreprise;   // nom de la société / département RH
    private String salaire;      // ex: "2000 - 3000 TND"
    private String logo;         // URL du logo (optionnel)
    private String localisation; // ville ou région (alias de departement si absent)

    // ── Dates ─────────────────────────────────────────────────────────
    private String datePublication;
    private String updatedAt;

    // ── Soft delete ───────────────────────────────────────────────────
    private Boolean isDeleted;

    // ── Créateur ──────────────────────────────────────────────────────
    private Long   createurId;
    private String createurEmail;
    private String createurNom;    // ⭐ NOUVEAU — nom complet du recruteur

    // ═════════════════════════════════════════════════════════════════
    //  Getters / Setters
    // ═════════════════════════════════════════════════════════════════

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }

    public String getTitre() { return titre; }
    public void setTitre(String titre) { this.titre = titre; }

    public String getDepartement() { return departement; }
    public void setDepartement(String departement) { this.departement = departement; }

    public String getTypeContrat() { return typeContrat; }
    public void setTypeContrat(String typeContrat) { this.typeContrat = typeContrat; }

    public String getNiveauEtudes() { return niveauEtudes; }
    public void setNiveauEtudes(String niveauEtudes) { this.niveauEtudes = niveauEtudes; }

    public String getExperienceRequise() { return experienceRequise; }
    public void setExperienceRequise(String experienceRequise) { this.experienceRequise = experienceRequise; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public Integer getNbCandidats() { return nbCandidats; }
    public void setNbCandidats(Integer nbCandidats) { this.nbCandidats = nbCandidats; }

    public String getStatut() { return statut; }
    public void setStatut(String statut) { this.statut = statut; }

    // ── Mobile ────────────────────────────────────────────────────────

    public String getEntreprise() { return entreprise; }
    public void setEntreprise(String entreprise) { this.entreprise = entreprise; }

    public String getSalaire() { return salaire; }
    public void setSalaire(String salaire) { this.salaire = salaire; }

    public String getLogo() { return logo; }
    public void setLogo(String logo) { this.logo = logo; }

    public String getLocalisation() { return localisation; }
    public void setLocalisation(String localisation) { this.localisation = localisation; }

    // ── Dates ─────────────────────────────────────────────────────────

    public String getDatePublication() { return datePublication; }
    public void setDatePublication(String datePublication) { this.datePublication = datePublication; }

    public String getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(String updatedAt) { this.updatedAt = updatedAt; }

    // ── Soft delete ───────────────────────────────────────────────────

    public Boolean getIsDeleted() { return isDeleted; }
    public void setIsDeleted(Boolean isDeleted) { this.isDeleted = isDeleted; }

    // ── Créateur ──────────────────────────────────────────────────────

    public Long getCreateurId() { return createurId; }
    public void setCreateurId(Long createurId) { this.createurId = createurId; }

    public String getCreateurEmail() { return createurEmail; }
    public void setCreateurEmail(String createurEmail) { this.createurEmail = createurEmail; }

    public String getCreateurNom() { return createurNom; }
    public void setCreateurNom(String createurNom) { this.createurNom = createurNom; }
}