package tn.delice.delijob.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import tn.delice.delijob.dto.OffreDTO;
import tn.delice.delijob.entity.Offre;
import tn.delice.delijob.entity.User;
import tn.delice.delijob.repository.OffreRepository;
import tn.delice.delijob.repository.UserRepository;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class OffreService {

    private final OffreRepository offreRepo;
    private final UserRepository userRepo;

    public OffreService(OffreRepository offreRepo, UserRepository userRepo) {
        this.offreRepo = offreRepo;
        this.userRepo = userRepo;
    }

    @Transactional(readOnly = true)
    public List<OffreDTO> getAll() {
        return offreRepo.findAllWithCreateur()
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<OffreDTO> getMesOffres(User createur) {
        return offreRepo.findByCreateurAndIsDeletedFalse(createur)
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @Transactional
    public OffreDTO create(OffreDTO dto, User createur) {
        if (offreRepo.existsByCode(dto.getCode()))
            throw new RuntimeException("Code offre deja existant.");
        Offre o = new Offre();
        o.setCode(dto.getCode());
        o.setTitre(dto.getTitre());
        o.setDepartement(dto.getDepartement());
        o.setTypeContrat(dto.getTypeContrat());
        o.setNiveauEtudes(dto.getNiveauEtudes());
        o.setExperienceRequise(dto.getExperienceRequise());
        o.setDescription(dto.getDescription());
        o.setNbCandidats(0);
        o.setStatut(Offre.Statut.OUVERT);
        o.setIsDeleted(false);
        o.setCreateur(createur);
        return toDTO(offreRepo.save(o));
    }

    @Transactional
    public OffreDTO updateStatut(Long id, String statut, User user) {
        Offre offre = offreRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Offre introuvable."));

        boolean isAdmin = user.getRole().name().equalsIgnoreCase("ADMIN");
        if (!isAdmin && !offre.getCreateur().getEmail().equals(user.getEmail())) {
            throw new SecurityException("Vous ne pouvez modifier que vos propres offres.");
        }

        offre.setStatut(Offre.Statut.valueOf(statut.toUpperCase()));
        offre.setUpdatedAt(LocalDateTime.now());
        return toDTO(offreRepo.save(offre));
    }

    @Transactional
    public OffreDTO update(Long id, OffreDTO dto, User user) {
        Offre offre = offreRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Offre introuvable."));

        boolean isAdmin = user.getRole().name().equalsIgnoreCase("ADMIN");
        if (!isAdmin && !offre.getCreateur().getEmail().equals(user.getEmail())) {
            throw new SecurityException("Vous ne pouvez modifier que vos propres offres.");
        }

        if (dto.getTitre()        != null) offre.setTitre(dto.getTitre());
        if (dto.getDepartement()  != null) offre.setDepartement(dto.getDepartement());
        if (dto.getTypeContrat()  != null) offre.setTypeContrat(dto.getTypeContrat());
        if (dto.getNiveauEtudes() != null) offre.setNiveauEtudes(dto.getNiveauEtudes());
        if (dto.getDescription()  != null) offre.setDescription(dto.getDescription());
        offre.setUpdatedAt(LocalDateTime.now());

        return toDTO(offreRepo.save(offre));
    }

    @Transactional
    public void delete(Long id, User user) {
        Offre offre = offreRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Offre introuvable."));

        boolean isAdmin = user.getRole().name().equalsIgnoreCase("ADMIN");
        if (!isAdmin && !offre.getCreateur().getEmail().equals(user.getEmail())) {
            throw new SecurityException("Vous ne pouvez supprimer que vos propres offres.");
        }

        offre.setIsDeleted(true);
        offreRepo.save(offre);
    }

    @Transactional(readOnly = true)
    public List<OffreDTO> getModifiedSince(LocalDateTime lastSync) {
        List<Offre> offres = (lastSync == null)
                ? offreRepo.findAllWithCreateur()
                : offreRepo.findAllModifiedSince(lastSync);
        return offres.stream().map(this::toDTO).collect(Collectors.toList());
    }

    @Transactional
    public void pushFromAndroid(List<OffreDTO> records) {
        for (OffreDTO dto : records) {
            if (dto.getId() == null) continue;
            offreRepo.findById(dto.getId()).ifPresent(existing -> {
                LocalDateTime incomingTime = dto.getUpdatedAt() != null
                        ? LocalDateTime.parse(dto.getUpdatedAt()) : null;
                if (incomingTime != null &&
                        (existing.getUpdatedAt() == null ||
                                incomingTime.isAfter(existing.getUpdatedAt()))) {
                    if (dto.getStatut() != null)
                        existing.setStatut(Offre.Statut.valueOf(dto.getStatut().toUpperCase()));
                    if (dto.getIsDeleted() != null)
                        existing.setIsDeleted(dto.getIsDeleted());
                    offreRepo.save(existing);
                }
            });
        }
    }

    public OffreDTO toDTO(Offre o) {
        OffreDTO d = new OffreDTO();
        d.setId(o.getId());
        d.setCode(o.getCode());
        d.setTitre(o.getTitre());
        d.setDepartement(o.getDepartement());
        d.setTypeContrat(o.getTypeContrat());
        d.setNiveauEtudes(o.getNiveauEtudes());
        d.setExperienceRequise(o.getExperienceRequise());
        d.setDescription(o.getDescription());
        d.setNbCandidats(o.getNbCandidats());
        d.setStatut(o.getStatut().name());
        d.setDatePublication(o.getDatePublication() != null
                ? o.getDatePublication().toString() : null);
        d.setUpdatedAt(o.getUpdatedAt() != null
                ? o.getUpdatedAt().toString() : null);
        d.setIsDeleted(o.getIsDeleted());
        if (o.getCreateur() != null) {
            d.setCreateurId(o.getCreateur().getId());
            d.setCreateurEmail(o.getCreateur().getEmail());
        }
        return d;
    }
}