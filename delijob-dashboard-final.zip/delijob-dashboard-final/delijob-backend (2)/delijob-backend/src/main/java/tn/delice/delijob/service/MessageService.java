package tn.delice.delijob.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import tn.delice.delijob.entity.Message;
import tn.delice.delijob.repository.MessageRepository;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class MessageService {

    private final MessageRepository repo;

    public MessageService(MessageRepository repo) {
        this.repo = repo;
    }

    // Récupérer un message par son ID
    public Message getMessageById(Long messageId) {
        return repo.findById(messageId).orElse(null);
    }

    // Côté RECRUTEUR — récupère toute la conversation
    public List<Message> getRecruiterMessages(Long recruiterId) {
        return repo.findConversation(recruiterId);
    }

    // Recruteur envoie un message
    public Message sendAsRecruiter(Long recruiterId, String content) {
        Message m = new Message();
        m.setSenderId(recruiterId);
        m.setSenderRole(Message.SenderRole.RECRUTEUR);
        m.setRecruiterId(recruiterId);
        m.setContent(content);
        return repo.save(m);
    }

    // Côté ADMIN — récupère la conversation avec un recruteur
    public List<Message> getConversation(Long recruiterId) {
        return repo.findConversation(recruiterId);
    }

    // Admin répond à un recruteur
    public Message sendAsAdmin(Long recruiterId, String content, Long adminId) {
        Message m = new Message();
        m.setSenderId(adminId);
        m.setSenderRole(Message.SenderRole.ADMIN);
        m.setRecruiterId(recruiterId);
        m.setContent(content);
        return repo.save(m);
    }

    // Mettre à jour un message
    @Transactional
    public Message updateMessageContent(Long messageId, String newContent) {
        Message message = repo.findById(messageId)
                .orElseThrow(() -> new RuntimeException("Message non trouvé: " + messageId));
        message.setContent(newContent);
        return repo.save(message);
    }

    // Supprimer un message
    @Transactional
    public void deleteMessage(Long messageId) {
        if (!repo.existsById(messageId)) {
            throw new RuntimeException("Message non trouvé: " + messageId);
        }
        repo.deleteById(messageId);
    }

    // Nombre de messages non lus par recruteur (envoyés par RECRUTEUR, non lus par admin)
    public Map<Long, Long> getUnreadCounts() {
        return repo.countUnreadGroupedByRecruiter()
                .stream()
                .collect(Collectors.toMap(
                        row -> (Long) row[0],
                        row -> (Long) row[1]
                ));
    }

    // Marquer la conversation comme lue par l'admin
    @Transactional
    public void markConversationRead(Long recruiterId) {
        List<Message> unread = repo.findConversation(recruiterId)
                .stream()
                .filter(m -> !m.isReadByAdmin())
                .collect(Collectors.toList());
        unread.forEach(m -> m.setReadByAdmin(true));
        repo.saveAll(unread);
    }
}