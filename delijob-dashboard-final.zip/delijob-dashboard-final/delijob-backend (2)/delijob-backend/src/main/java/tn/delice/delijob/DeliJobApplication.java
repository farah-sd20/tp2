package tn.delice.delijob;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeliJobApplication {
    public static void main(String[] args) {
        SpringApplication.run(DeliJobApplication.class, args);
    }
}
