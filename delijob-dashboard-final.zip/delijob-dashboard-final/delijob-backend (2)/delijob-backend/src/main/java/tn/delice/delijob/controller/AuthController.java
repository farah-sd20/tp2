package tn.delice.delijob.controller;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import tn.delice.delijob.dto.*;
import tn.delice.delijob.service.AuthService;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    /* ── REGISTER — multipart/form-data (photo optionnelle) ─────────── */
    @PostMapping(value = "/register", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<?> register(
            @RequestParam("prenom")      String prenom,
            @RequestParam("nom")         String nom,
            @RequestParam("email")       String email,
            @RequestParam("departement") String departement,
            @RequestParam("password")    String password,
            @RequestParam(value = "photo", required = false) MultipartFile photo
    ) {
        if (prenom.isBlank() || nom.isBlank() || email.isBlank()
                || departement.isBlank() || password.isBlank()) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "Tous les champs obligatoires doivent être remplis."));
        }
        if (!email.matches("\\S+@\\S+\\.\\S+")) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "Adresse email invalide."));
        }
        if (password.length() < 8
                || !password.matches(".*[A-Z].*")
                || !password.matches(".*[0-9].*")
                || !password.matches(".*[^A-Za-z0-9].*")) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error",
                            "Mot de passe trop faible (8 car. min, 1 majuscule, 1 chiffre, 1 spécial)."));
        }

        if (photo != null && !photo.isEmpty()) {
            String ct = photo.getContentType();
            if (ct == null || !ct.startsWith("image/")) {
                return ResponseEntity.badRequest()
                        .body(Map.of("error", "La photo doit être une image (JPG, PNG, WEBP)."));
            }
            if (photo.getSize() > 5L * 1024 * 1024) {
                return ResponseEntity.badRequest()
                        .body(Map.of("error", "La photo ne doit pas dépasser 5 Mo."));
            }
        }

        try {
            RegisterRequest req = new RegisterRequest(
                    prenom, nom, email, departement, password);
            String message = authService.register(req, photo);
            return ResponseEntity.ok(Map.of("message", message));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    /* ── LOGIN ───────────────────────────────────────────────────────── */
    @PostMapping("/login")
    public ResponseEntity<?> login(@jakarta.validation.Valid
                                   @RequestBody LoginRequest req) {
        try {
            return ResponseEntity.ok(authService.login(req));
        } catch (RuntimeException e) {
            String msg = e.getMessage();
            if ("PENDING".equals(msg))
                return ResponseEntity.status(403)
                        .body(Map.of("error", "PENDING",
                                "message", "Compte en attente de validation."));
            if ("REJECTED".equals(msg))
                return ResponseEntity.status(403)
                        .body(Map.of("error", "REJECTED",
                                "message", "Accès refusé."));
            return ResponseEntity.status(401).body(Map.of("error", msg));
        }
    }

    /* ── FORGOT PASSWORD ─────────────────────────────────────────────── */
    @PostMapping("/forgot-password")
    public ResponseEntity<?> forgotPassword(@RequestBody ForgotPasswordRequest req) {
        if (req.getEmail() == null || req.getEmail().isBlank()) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "Adresse email requise."));
        }
        if (!req.getEmail().matches("\\S+@\\S+\\.\\S+")) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "Adresse email invalide."));
        }

        try {
            authService.sendNewPassword(req.getEmail().trim().toLowerCase());
        } catch (RuntimeException e) {
            System.err.println("⚠️ Erreur forgot-password: " + e.getMessage());
        }

        return ResponseEntity.ok(Map.of("message",
                "Si cet email est enregistré et actif, vous recevrez un nouveau mot de passe."));
    }

    /* ── REGISTER CANDIDAT MOBILE ────────────────────────────────────── */
    @PostMapping(value = "/register/candidat", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<?> registerCandidat(
            @RequestParam("prenom")   String prenom,
            @RequestParam("nom")      String nom,
            @RequestParam("email")    String email,
            @RequestParam("password") String password,
            // ✅ CORRECTION : departement optionnel pour les candidats mobiles
            @RequestParam(value = "departement", required = false, defaultValue = "") String departement,
            @RequestParam(value = "photo", required = false) MultipartFile photo
    ) {
        if (prenom.isBlank() || nom.isBlank() || email.isBlank() || password.isBlank()) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "Tous les champs obligatoires doivent être remplis."));
        }
        if (!email.matches("\\S+@\\S+\\.\\S+")) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "Adresse email invalide."));
        }
        if (password.length() < 8
                || !password.matches(".*[A-Z].*")
                || !password.matches(".*[0-9].*")
                || !password.matches(".*[^A-Za-z0-9].*")) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error",
                            "Mot de passe trop faible (8 car. min, 1 majuscule, 1 chiffre, 1 spécial)."));
        }
        if (photo != null && !photo.isEmpty()) {
            String ct = photo.getContentType();
            if (ct == null || !ct.startsWith("image/")) {
                return ResponseEntity.badRequest()
                        .body(Map.of("error", "La photo doit être une image (JPG, PNG, WEBP)."));
            }
            if (photo.getSize() > 5L * 1024 * 1024) {
                return ResponseEntity.badRequest()
                        .body(Map.of("error", "La photo ne doit pas dépasser 5 Mo."));
            }
        }
        try {
            RegisterRequest req = new RegisterRequest(prenom, nom, email, departement, password);
            String message = authService.registerCandidat(req, photo);
            return ResponseEntity.ok(Map.of("message", message));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }
}