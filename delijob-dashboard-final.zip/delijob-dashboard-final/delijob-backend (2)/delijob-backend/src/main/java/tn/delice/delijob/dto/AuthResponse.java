package tn.delice.delijob.dto;

public class AuthResponse {
    private String token;
    private String role;
    private String status;
    private Long userId;
    private String prenom;
    private String nom;
    private String email;
    private String departement;

    // Constructeur complet
    public AuthResponse(String token, String role, String status,
                        Long userId, String prenom, String nom,
                        String email, String departement) {
        this.token = token;
        this.role = role;
        this.status = status;
        this.userId = userId;
        this.prenom = prenom;
        this.nom = nom;
        this.email = email;
        this.departement = departement;
    }

    // Constructeur simplifié pour l'admin
    public AuthResponse(String token, String role, String status) {
        this(token, role, status, 0L, "", "", "", "");
    }

    // Getters
    public String getToken() { return token; }
    public String getRole() { return role; }
    public String getStatus() { return status; }
    public Long getUserId() { return userId; }
    public String getPrenom() { return prenom; }
    public String getNom() { return nom; }
    public String getEmail() { return email; }
    public String getDepartement() { return departement; }
}