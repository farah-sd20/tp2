package tn.delice.delijob.controller;

import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.*;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import tn.delice.delijob.dto.*;
import tn.delice.delijob.service.RecruteurService;

import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.*;

@RestController
@RequestMapping("/api")
public class RecruteurController {

    private final RecruteurService service;

    public RecruteurController(RecruteurService service) {
        this.service = service;
    }

    /** GET /api/recruteur/profil — récupérer le profil connecté */
    @GetMapping("/recruteur/profil")
    public ResponseEntity<RecruteurProfilDTO> getProfil(Authentication auth) {
        String email = auth.getName();
        return ResponseEntity.ok(service.getProfil(email));
    }

    /** PUT /api/recruteur/profil — modifier prenom/nom/telephone/poste */
    @PutMapping("/recruteur/profil")
    public ResponseEntity<RecruteurProfilDTO> updateProfil(
            Authentication auth,
            @RequestBody UpdateProfilRequest req) {
        return ResponseEntity.ok(service.updateProfil(auth.getName(), req));
    }

    /** POST /api/recruteur/photo — uploader une photo */
    @PostMapping(value = "/recruteur/photo", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<?> uploadPhoto(
            Authentication auth,
            @RequestParam("photo") MultipartFile file) throws IOException {

        if (file.isEmpty())
            return ResponseEntity.badRequest().body("Fichier vide");
        if (file.getContentType() == null || !file.getContentType().startsWith("image/"))
            return ResponseEntity.badRequest().body("Fichier non valide");
        if (file.getSize() > 5 * 1024 * 1024)
            return ResponseEntity.badRequest().body("Fichier trop volumineux (max 5 MB)");

        String photoUrl = service.updatePhoto(auth.getName(), file);
        return ResponseEntity.ok().body(java.util.Map.of("photoUrl", photoUrl));
    }

    /** DELETE /api/recruteur/photo — supprimer la photo */
    @DeleteMapping("/recruteur/photo")
    public ResponseEntity<Void> deletePhoto(Authentication auth) throws IOException {
        service.removePhoto(auth.getName());
        return ResponseEntity.noContent().build();
    }

    /** POST /api/recruteur/change-password */
    @PostMapping("/recruteur/change-password")
    public ResponseEntity<?> changePassword(
            Authentication auth,
            @RequestBody ChangePasswordRequest req) {
        try {
            service.changePassword(auth.getName(), req);
            return ResponseEntity.ok().body(java.util.Map.of("message", "Mot de passe modifié"));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(java.util.Map.of("error", e.getMessage()));
        }
    }

    /**
     * GET /api/recruteur/photos/{filename} — servir les photos stockées
     *
     * CORRECTION : le mapping était "/api/photos/{filename}" alors que le service
     * stocke l'URL "/api/recruteur/photos/{filename}".
     * On aligne ici en ajoutant "recruteur/" dans le path.
     */
    @GetMapping("/recruteur/photos/{filename}")
    public ResponseEntity<Resource> servePhoto(@PathVariable String filename) {
        try {
            Path uploadPath = Paths.get("uploads/photos/").toAbsolutePath().normalize();
            Path file = uploadPath.resolve(filename).normalize();

            // Sécurité anti path-traversal
            if (!file.startsWith(uploadPath)) {
                System.err.println("⚠️ Tentative de path traversal : " + filename);
                return ResponseEntity.badRequest().build();
            }

            Resource resource = new UrlResource(file.toUri());
            if (!resource.exists() || !resource.isReadable()) {
                System.err.println("❌ Photo introuvable : " + file);
                return ResponseEntity.notFound().build();
            }

            String contentType = Files.probeContentType(file);
            if (contentType == null) contentType = "application/octet-stream";

            System.out.println("✅ Serving photo: " + filename);
            return ResponseEntity.ok()
                    .contentType(MediaType.parseMediaType(contentType))
                    .header(HttpHeaders.CACHE_CONTROL, "max-age=3600")
                    .body(resource);

        } catch (MalformedURLException e) {
            return ResponseEntity.badRequest().build();
        } catch (IOException e) {
            return ResponseEntity.internalServerError().build();
        }
    }
}