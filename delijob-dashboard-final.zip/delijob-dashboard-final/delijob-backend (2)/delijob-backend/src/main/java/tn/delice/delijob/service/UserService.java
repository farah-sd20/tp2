package tn.delice.delijob.service;

import org.springframework.stereotype.Service;
import tn.delice.delijob.dto.UserDTO;
import tn.delice.delijob.entity.User;
import tn.delice.delijob.repository.UserRepository;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class UserService {
    private final UserRepository userRepo;

    public UserService(UserRepository userRepo) { this.userRepo = userRepo; }

    public List<UserDTO> getAllUsers() {
        return userRepo.findAll().stream().map(UserDTO::from).collect(Collectors.toList());
    }

    public List<UserDTO> getByStatus(String status) {
        return userRepo.findByStatus(User.Status.valueOf(status.toUpperCase()))
            .stream().map(UserDTO::from).collect(Collectors.toList());
    }

    public UserDTO updateStatus(Long id, String status) {
        User u = userRepo.findById(id)
            .orElseThrow(() -> new RuntimeException("Utilisateur introuvable."));
        u.setStatus(User.Status.valueOf(status.toUpperCase()));
        return UserDTO.from(userRepo.save(u));
    }

    public void deleteUser(Long id) {
        if (!userRepo.existsById(id)) throw new RuntimeException("Utilisateur introuvable.");
        userRepo.deleteById(id);
    }

    public UserDTO getProfile(String email) {
        return UserDTO.from(userRepo.findByEmail(email)
            .orElseThrow(() -> new RuntimeException("Utilisateur introuvable.")));
    }
}
