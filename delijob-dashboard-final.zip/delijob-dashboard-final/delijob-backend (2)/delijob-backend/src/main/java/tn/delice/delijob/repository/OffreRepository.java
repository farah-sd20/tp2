package tn.delice.delijob.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import tn.delice.delijob.entity.Offre;
import tn.delice.delijob.entity.User;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface OffreRepository extends JpaRepository<Offre, Long> {
    Optional<Offre> findByCode(String code);
    boolean existsByCode(String code);
    List<Offre> findByStatut(Offre.Statut statut);
    List<Offre> findByDepartement(String departement);

    @Query("SELECT o FROM Offre o WHERE o.updatedAt > :lastSync")
    List<Offre> findAllModifiedSince(@Param("lastSync") LocalDateTime lastSync);

    // ✅ FIX : JOIN FETCH charge le createur dans la même requête SQL
    // → évite le "no Session" lors de l'accès à createur.getEmail() dans toDTO()
    @Query("SELECT o FROM Offre o JOIN FETCH o.createur WHERE o.createur = :createur AND o.isDeleted = false")
    List<Offre> findByCreateurAndIsDeletedFalse(@Param("createur") User createur);

    // ✅ FIX : même correction pour getAll() — charge tous les créateurs d'un coup
    @Query("SELECT o FROM Offre o JOIN FETCH o.createur WHERE (o.isDeleted = false OR o.isDeleted IS NULL)")
    List<Offre> findAllWithCreateur();
}