package tn.delice.delijob.service;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import tn.delice.delijob.entity.Entretien;

import java.time.format.DateTimeFormatter;
import java.util.Locale;

@Service
public class EmailService {

    private static final Logger log = LoggerFactory.getLogger(EmailService.class);

    private final JavaMailSender mailSender;

    @Value("${spring.mail.username}")
    private String fromEmail;

    @Value("${app.company.name:Delice - DeliJob}")
    private String companyName;

    public EmailService(JavaMailSender mailSender) {
        this.mailSender = mailSender;
    }

    // ─────────────────────────────────────────────────────────────────────
    //  Méthode publique appelée par Entretienservice après chaque création
    // ─────────────────────────────────────────────────────────────────────

    /**
     * Envoie un email HTML de convocation au candidat.
     * - Si emailCandidat est null ou vide  → ne fait rien, pas d'exception.
     * - Si l'envoi SMTP échoue            → log l'erreur, ne bloque PAS la
     *   création de l'entretien (exception avalée volontairement).
     */
    public void envoyerConvocation(Entretien entretien) {

        if (entretien.getEmailCandidat() == null
                || entretien.getEmailCandidat().isBlank()) {
            log.info("Aucun email candidat renseigné pour l'entretien id={} — envoi ignoré.",
                    entretien.getId());
            return;
        }

        try {
            MimeMessage message = mailSender.createMimeMessage();
            // true  = multipart (pièces jointes possibles)
            // UTF-8 = encodage
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");

            helper.setFrom(fromEmail);
            helper.setTo(entretien.getEmailCandidat());
            helper.setSubject("Convocation à un entretien – "
                    + entretien.getPoste() + " | " + companyName);
            helper.setText(buildHtml(entretien), true); // true = corps HTML

            mailSender.send(message);
            log.info("✅ Email de convocation envoyé à {} pour le poste {}",
                    entretien.getEmailCandidat(), entretien.getPoste());

        } catch (MessagingException ex) {
            // On log sans propager : la création de l'entretien reste valide
            log.error("⚠️ Impossible d'envoyer l'email à {} : {}",
                    entretien.getEmailCandidat(), ex.getMessage(), ex);
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  Construction du corps HTML de l'email
    // ─────────────────────────────────────────────────────────────────────

    private String buildHtml(Entretien entretien) {

        // "lundi 12 mai 2025"
        String dateFormatee = entretien.getDate()
                .format(DateTimeFormatter.ofPattern("EEEE d MMMM yyyy", Locale.FRENCH));

        // "09:30"
        String heureDebut = entretien.getHeure()
                .format(DateTimeFormatter.ofPattern("HH:mm"));

        // "10:30"  (heure de début + durée)
        int dureeMin = entretien.getDuree() != null ? entretien.getDuree() : 60;
        String heureFin = entretien.getHeure()
                .plusMinutes(dureeMin)
                .format(DateTimeFormatter.ofPattern("HH:mm"));

        return "<!DOCTYPE html>" +
                "<html lang=\"fr\">" +
                "<head>" +
                "  <meta charset=\"UTF-8\"/>" +
                "  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\"/>" +
                "  <title>Convocation entretien</title>" +
                "</head>" +
                "<body style=\"margin:0;padding:0;background:#F8FAFC;" +
                "             font-family:'Segoe UI',Arial,sans-serif;\">" +

                // ── Conteneur principal
                "<div style=\"max-width:600px;margin:40px auto;background:#FFFFFF;" +
                "            border-radius:16px;overflow:hidden;" +
                "            box-shadow:0 4px 24px rgba(0,0,0,0.08);\">" +

                // ── En-tête bleue
                "<div style=\"background:#0EA5E9;padding:36px 40px;text-align:center;\">" +
                "  <div style=\"font-size:32px;margin-bottom:10px;\">📋</div>" +
                "  <h1 style=\"margin:0;color:#FFFFFF;font-size:24px;" +
                "              font-weight:700;letter-spacing:-0.3px;\">" +
                "    Convocation à un entretien" +
                "  </h1>" +
                "  <p style=\"margin:8px 0 0;color:#BAE6FD;font-size:14px;\">" +
                companyName +
                "  </p>" +
                "</div>" +

                // ── Corps
                "<div style=\"padding:36px 40px;\">" +

                "  <p style=\"margin:0 0 18px;font-size:15px;color:#334155;line-height:1.7;\">" +
                "    Bonjour <strong>" + entretien.getCandidat() + "</strong>," +
                "  </p>" +

                "  <p style=\"margin:0 0 24px;font-size:15px;color:#334155;line-height:1.7;\">" +
                "    Nous avons le plaisir de vous convoquer à un entretien pour le poste de" +
                "    <strong>" + entretien.getPoste() + "</strong>." +
                "  </p>" +

                // ── Bloc détails
                "  <div style=\"background:#F0F9FF;border:1px solid #BAE6FD;" +
                "               border-radius:12px;padding:24px;margin-bottom:28px;\">" +

                "    <h2 style=\"margin:0 0 18px;font-size:12px;font-weight:700;" +
                "                color:#0C4A6E;text-transform:uppercase;" +
                "                letter-spacing:0.08em;\">" +
                "      Détails de l'entretien" +
                "    </h2>" +

                "    <table style=\"width:100%;border-collapse:collapse;\">" +

                // Date
                "      <tr>" +
                "        <td style=\"padding:10px 0;font-size:13px;color:#64748B;" +
                "                   width:38%;vertical-align:top;\">" +
                "          <span style=\"margin-right:6px;\">📅</span> Date" +
                "        </td>" +
                "        <td style=\"padding:10px 0;font-size:14px;font-weight:600;" +
                "                   color:#0F172A;text-transform:capitalize;\">" +
                dateFormatee +
                "        </td>" +
                "      </tr>" +

                // Heure
                "      <tr style=\"border-top:1px solid #E0F2FE;\">" +
                "        <td style=\"padding:10px 0;font-size:13px;color:#64748B;\">" +
                "          <span style=\"margin-right:6px;\">⏰</span> Heure" +
                "        </td>" +
                "        <td style=\"padding:10px 0;font-size:14px;font-weight:600;color:#0F172A;\">" +
                heureDebut + " – " + heureFin +
                "        </td>" +
                "      </tr>" +

                // Durée
                "      <tr style=\"border-top:1px solid #E0F2FE;\">" +
                "        <td style=\"padding:10px 0;font-size:13px;color:#64748B;\">" +
                "          <span style=\"margin-right:6px;\">⏱</span> Durée" +
                "        </td>" +
                "        <td style=\"padding:10px 0;font-size:14px;font-weight:600;color:#0F172A;\">" +
                dureeMin + " minutes" +
                "        </td>" +
                "      </tr>" +

                // Type
                "      <tr style=\"border-top:1px solid #E0F2FE;\">" +
                "        <td style=\"padding:10px 0;font-size:13px;color:#64748B;\">" +
                "          <span style=\"margin-right:6px;\">🎯</span> Type" +
                "        </td>" +
                "        <td style=\"padding:10px 0;font-size:14px;font-weight:600;color:#0F172A;\">" +
                entretien.getType() +
                "        </td>" +
                "      </tr>" +

                // Interviewer
                "      <tr style=\"border-top:1px solid #E0F2FE;\">" +
                "        <td style=\"padding:10px 0;font-size:13px;color:#64748B;\">" +
                "          <span style=\"margin-right:6px;\">👤</span> Interviewer" +
                "        </td>" +
                "        <td style=\"padding:10px 0;font-size:14px;font-weight:600;color:#0F172A;\">" +
                entretien.getInterviewer() +
                "        </td>" +
                "      </tr>" +

                "    </table>" +
                "  </div>" +  // fin bloc détails

                "  <p style=\"margin:0 0 14px;font-size:14px;color:#475569;line-height:1.7;\">" +
                "    Merci de confirmer votre présence en répondant à cet email." +
                "    En cas d'empêchement, veuillez nous contacter dès que possible." +
                "  </p>" +

                "  <p style=\"margin:0;font-size:14px;color:#475569;line-height:1.7;\">" +
                "    Nous vous souhaitons bonne chance pour cet entretien et restons" +
                "    disponibles pour toute question." +
                "  </p>" +

                "  <p style=\"margin:24px 0 0;font-size:14px;color:#475569;\">" +
                "    Cordialement,<br/>" +
                "    <strong>L'équipe RH – " + companyName + "</strong>" +
                "  </p>" +

                "</div>" +  // fin corps

                // ── Pied de page
                "<div style=\"background:#F1F5F9;padding:20px 40px;" +
                "             text-align:center;border-top:1px solid #E2E8F0;\">" +
                "  <p style=\"margin:0;font-size:12px;color:#94A3B8;line-height:1.6;\">" +
                "    Cet email a été envoyé automatiquement par " + companyName + ".<br/>" +
                "    Merci de ne pas répondre directement à cet email." +
                "  </p>" +
                "</div>" +

                "</div>" +  // fin conteneur
                "</body>" +
                "</html>";
    }
}