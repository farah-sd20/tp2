package tn.delice.delijob.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

import java.util.List;

@Configuration
public class CorsConfig {

    @Bean
    public CorsFilter corsFilter() {
        CorsConfiguration config = new CorsConfiguration();

        config.setAllowCredentials(true);

        // ── Origines autorisées ──────────────────────────────────────
        config.setAllowedOriginPatterns(List.of(
                "http://localhost:*",       // App Web React (dev)
                "http://127.0.0.1:*",       // App Web locale
                "http://10.0.2.2:*",        // Émulateur Android (accède au PC via cette IP)
                "http://192.168.*.*:*",     // Téléphone réel sur réseau local
                "http://10.*.*.*:*"         // Autres réseaux locaux
        ));

        // ── Méthodes HTTP autorisées ─────────────────────────────────
        config.setAllowedMethods(List.of(
                "GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"
        ));

        // ── Headers autorisés ────────────────────────────────────────
        config.setAllowedHeaders(List.of(
                "Authorization",
                "Content-Type",
                "Accept",
                "Origin",
                "X-Requested-With"
        ));

        config.setExposedHeaders(List.of("Authorization"));
        config.setMaxAge(3600L);

        UrlBasedCorsConfigurationSource source =
                new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/api/**", config);

        return new CorsFilter(source);
    }
}