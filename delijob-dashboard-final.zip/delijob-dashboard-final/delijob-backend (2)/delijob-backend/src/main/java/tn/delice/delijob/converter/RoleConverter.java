package tn.delice.delijob.converter;

import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;
import tn.delice.delijob.entity.User;

@Converter
public class RoleConverter implements AttributeConverter<User.Role, String> {

    @Override
    public String convertToDatabaseColumn(User.Role role) {
        return role != null ? role.name() : null;
    }

    @Override
    public User.Role convertToEntityAttribute(String value) {
        if (value == null || value.isBlank()) {
            return User.Role.RECRUTEUR;
        }
        try {
            return User.Role.valueOf(value.trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            return User.Role.RECRUTEUR;
        }
    }
}