package tn.delice.delijob.entity;

import jakarta.persistence.*;
import org.hibernate.annotations.UpdateTimestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "offres")
public class Offre {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false, length = 20)
    private String code;

    @Column(nullable = false)
    private String titre;

    @Column(nullable = false)
    private String departement;

    @Column(nullable = false)
    private String typeContrat;

    private String niveauEtudes;
    private String experienceRequise;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Column(nullable = false)
    private Integer nbCandidats = 0;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Statut statut = Statut.OUVERT;

    private LocalDate datePublication;

    @Column(updatable = false)
    private LocalDateTime createdAt;

    // ✅ pour la synchronisation
    @UpdateTimestamp
    private LocalDateTime updatedAt;

    // ✅ soft delete (ne jamais supprimer physiquement)
    @Column(nullable = false)
    private Boolean isDeleted = false;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "createur_id")
    private User createur;

    @PrePersist
    public void onCreate() {
        this.createdAt = LocalDateTime.now();
        this.datePublication = LocalDate.now();
        if (this.isDeleted == null) this.isDeleted = false;
    }



    public enum Statut { OUVERT, FERME, EN_PAUSE }

    public Offre() {}

    public Long getId()                        { return id; }
    public String getCode()                    { return code; }
    public void setCode(String v)              { this.code = v; }
    public String getTitre()                   { return titre; }
    public void setTitre(String v)             { this.titre = v; }
    public String getDepartement()             { return departement; }
    public void setDepartement(String v)       { this.departement = v; }
    public String getTypeContrat()             { return typeContrat; }
    public void setTypeContrat(String v)       { this.typeContrat = v; }
    public String getNiveauEtudes()            { return niveauEtudes; }
    public void setNiveauEtudes(String v)      { this.niveauEtudes = v; }
    public String getExperienceRequise()       { return experienceRequise; }
    public void setExperienceRequise(String v) { this.experienceRequise = v; }
    public String getDescription()             { return description; }
    public void setDescription(String v)       { this.description = v; }
    public Integer getNbCandidats()            { return nbCandidats; }
    public void setNbCandidats(Integer v)      { this.nbCandidats = v; }
    public Statut getStatut()                  { return statut; }
    public void setStatut(Statut v)            { this.statut = v; }
    public LocalDate getDatePublication()      { return datePublication; }
    public LocalDateTime getCreatedAt()        { return createdAt; }
    public LocalDateTime getUpdatedAt()        { return updatedAt; }
    public void setUpdatedAt(LocalDateTime v)  { this.updatedAt = v; } // ✅ SETTER AJOUTÉ
    public Boolean getIsDeleted()              { return isDeleted; }
    public void setIsDeleted(Boolean v)        { this.isDeleted = v; }
    public User getCreateur()                  { return createur; }
    public void setCreateur(User v)            { this.createur = v; }
}