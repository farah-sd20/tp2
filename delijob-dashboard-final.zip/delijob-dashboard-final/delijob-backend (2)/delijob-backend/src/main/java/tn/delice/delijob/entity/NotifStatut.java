package tn.delice.delijob.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "notif_statut")
public class NotifStatut {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // L'utilisateur qui doit recevoir la notif
    @Column(name = "user_id", nullable = false)
    private Long userId;

    // L'offre concernée
    @Column(name = "offre_id")
    private Long offreId;

    @Column(name = "offre_titre")
    private String offreTitre;

    // Nouveau statut : ACCEPTE, REFUSE, ENTRETIEN, etc.
    @Column(name = "nouveau_statut", nullable = false)
    private String nouveauStatut;

    @Column(name = "message")
    private String message;

    @Column(name = "lu", nullable = false)
    private boolean lu = false;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    // ── Constructeurs ────────────────────────────────────────────
    public NotifStatut() {}

    public NotifStatut(Long userId, Long offreId, String offreTitre,
                       String nouveauStatut, String message) {
        this.userId       = userId;
        this.offreId      = offreId;
        this.offreTitre   = offreTitre;
        this.nouveauStatut = nouveauStatut;
        this.message      = message;
        this.lu           = false;
        this.createdAt    = LocalDateTime.now();
    }

    // ── Getters / Setters ────────────────────────────────────────
    public Long getId()                      { return id; }
    public void setId(Long id)               { this.id = id; }

    public Long getUserId()                  { return userId; }
    public void setUserId(Long userId)       { this.userId = userId; }

    public Long getOffreId()                 { return offreId; }
    public void setOffreId(Long offreId)     { this.offreId = offreId; }

    public String getOffreTitre()            { return offreTitre; }
    public void setOffreTitre(String t)      { this.offreTitre = t; }

    public String getNouveauStatut()         { return nouveauStatut; }
    public void setNouveauStatut(String s)   { this.nouveauStatut = s; }

    public String getMessage()               { return message; }
    public void setMessage(String message)   { this.message = message; }

    public boolean isLu()                    { return lu; }
    public void setLu(boolean lu)            { this.lu = lu; }

    public LocalDateTime getCreatedAt()      { return createdAt; }
    public void setCreatedAt(LocalDateTime t){ this.createdAt = t; }
}