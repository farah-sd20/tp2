package tn.delice.delijob.controller;

import jakarta.validation.Valid;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import tn.delice.delijob.dto.OffreDTO;
import tn.delice.delijob.entity.User;
import tn.delice.delijob.repository.UserRepository;
import tn.delice.delijob.service.OffreService;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/offres")
public class OffreController {

    private final OffreService offreService;
    private final UserRepository userRepo;

    public OffreController(OffreService offreService, UserRepository userRepo) {
        this.offreService = offreService;
        this.userRepo = userRepo;
    }

    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> getAll() {
        return ResponseEntity.ok(offreService.getAll());
    }

    @GetMapping("/public")
    @PreAuthorize("hasAnyRole('RECRUTEUR', 'ADMIN')")
    public ResponseEntity<?> getAllForRecruteur() {
        return ResponseEntity.ok(offreService.getAll());
    }

    @GetMapping("/mes-offres")
    @PreAuthorize("hasAnyRole('RECRUTEUR', 'ADMIN')")
    public ResponseEntity<?> getMesOffres(Authentication auth) {
        try {
            String email = auth.getName();
            User createur = userRepo.findByEmail(email)
                    .orElseThrow(() -> new RuntimeException("Utilisateur introuvable."));
            return ResponseEntity.ok(offreService.getMesOffres(createur));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('RECRUTEUR', 'ADMIN')")
    public ResponseEntity<?> create(@Valid @RequestBody OffreDTO dto,
                                    Authentication auth) {
        try {
            String email = auth.getName();
            User createur = userRepo.findByEmail(email)
                    .orElseThrow(() -> new RuntimeException("Utilisateur introuvable."));
            return ResponseEntity.ok(offreService.create(dto, createur));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('RECRUTEUR', 'ADMIN')")
    public ResponseEntity<?> update(@PathVariable Long id,
                                    @RequestBody OffreDTO dto,
                                    Authentication auth) {
        try {
            String email = auth.getName();
            User user = userRepo.findByEmail(email)
                    .orElseThrow(() -> new RuntimeException("Utilisateur introuvable."));
            return ResponseEntity.ok(offreService.update(id, dto, user));
        } catch (SecurityException e) {
            return ResponseEntity.status(403).body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @PatchMapping("/{id}/statut")
    @PreAuthorize("hasAnyRole('RECRUTEUR', 'ADMIN')")
    public ResponseEntity<?> updateStatut(@PathVariable Long id,
                                          @RequestBody Map<String, String> body,
                                          Authentication auth) {
        try {
            String email = auth.getName();
            User user = userRepo.findByEmail(email)
                    .orElseThrow(() -> new RuntimeException("Utilisateur introuvable."));
            return ResponseEntity.ok(offreService.updateStatut(id, body.get("statut"), user));
        } catch (SecurityException e) {
            return ResponseEntity.status(403).body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyRole('RECRUTEUR', 'ADMIN')")
    public ResponseEntity<?> delete(@PathVariable Long id,
                                    Authentication auth) {
        try {
            String email = auth.getName();
            User user = userRepo.findByEmail(email)
                    .orElseThrow(() -> new RuntimeException("Utilisateur introuvable."));
            offreService.delete(id, user);
            return ResponseEntity.ok(Map.of("message", "Offre supprimee."));
        } catch (SecurityException e) {
            return ResponseEntity.status(403).body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @GetMapping("/sync/pull")
    public ResponseEntity<?> syncPull(
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
            LocalDateTime lastSync) {
        List<OffreDTO> data = offreService.getModifiedSince(lastSync);
        return ResponseEntity.ok(Map.of(
                "data", data,
                "sync_time", LocalDateTime.now().toString()
        ));
    }

    @PostMapping("/sync/push")
    public ResponseEntity<?> syncPush(@RequestBody List<OffreDTO> records) {
        try {
            offreService.pushFromAndroid(records);
            return ResponseEntity.ok(Map.of("success", true));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }
}