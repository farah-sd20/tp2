// src/services/notificationService.js
// Toutes les requêtes vers /api/notifications

const BASE = "/api/notifications";

function authHeaders() {
  const token = localStorage.getItem("token");
  return {
    "Content-Type": "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
}

async function handle(res) {
  if (!res.ok) {
    const text = await res.text().catch(() => res.statusText);
    throw new Error(text || `HTTP ${res.status}`);
  }
  // 204 No Content → pas de corps
  if (res.status === 204) return null;
  return res.json();
}

const notificationService = {
  /**
   * Récupère une page de notifications.
   * Retourne { content, totalElements, totalPages, number }
   */
  getPage(page = 0, size = 20) {
    return fetch(`${BASE}?page=${page}&size=${size}`, {
      headers: authHeaders(),
    }).then(handle);
  },

  /** 20 dernières notifs pour le dropdown topbar */
  getRecent() {
    return fetch(`${BASE}/recent`, { headers: authHeaders() }).then(handle);
  },

  /** Nombre de notifs non lues → { count: N } */
  getUnreadCount() {
    return fetch(`${BASE}/unread-count`, { headers: authHeaders() }).then(handle);
  },

  /** Marquer une notif comme lue (survol dans NotifCard) */
  markRead(id) {
    return fetch(`${BASE}/${id}/read`, {
      method: "PATCH",
      headers: authHeaders(),
    }).then(handle);
  },

  /** Marquer toutes comme lues */
  markAllRead() {
    return fetch(`${BASE}/read-all`, {
      method: "PATCH",
      headers: authHeaders(),
    }).then(handle);
  },

  /** Supprimer une notif */
  dismiss(id) {
    return fetch(`${BASE}/${id}`, {
      method: "DELETE",
      headers: authHeaders(),
    }).then(handle);
  },

  /** Effacer toutes les notifs */
  clearAll() {
    return fetch(BASE, {
      method: "DELETE",
      headers: authHeaders(),
    }).then(handle);
  },
};

export default notificationService;