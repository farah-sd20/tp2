router.post("/generate-description", async (req, res) => {
  const { titre, niveau, type, dept, secteur, ton } = req.body;

  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": process.env.ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 1000,
      stream: true,   // ← activer le streaming
      messages: [{ role: "user", content: buildPrompt(titre, niveau, type, dept, secteur, ton) }],
    }),
  });

  // Forwarder le stream SSE tel quel vers le client
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  response.body.pipe(res);   // ← pipe direct, pas besoin de parser
});