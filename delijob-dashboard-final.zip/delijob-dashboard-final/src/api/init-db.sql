-- ============================================================
-- DeliJob · Script d'initialisation MySQL
-- Executer dans MySQL Workbench ou via: mysql -u root -p < init-db.sql
-- ============================================================

CREATE DATABASE IF NOT EXISTS delijob_db
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE delijob_db;

-- Les tables sont créées automatiquement par Spring Boot (ddl-auto=update)
-- Ce script ajoute seulement les données de test

-- Supprimer les données existantes (optionnel)
-- DELETE FROM offres;
-- DELETE FROM users;

-- Données de test (les mots de passe sont hashés avec BCrypt pour "test123")
-- Hash BCrypt de "test123": $2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy

INSERT IGNORE INTO users (prenom, nom, email, password, departement, role, status, created_at, updated_at) VALUES
('Salma',   'Trabelsi',  's.trabelsi@delice.tn',  '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'Ressources Humaines',    'RECRUTEUR', 'APPROVED', NOW(), NOW()),
('Karim',   'Boughanmi', 'k.boughanmi@delice.tn', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'Commercial & Marketing', 'RECRUTEUR', 'PENDING',  NOW(), NOW()),
('Nadia',   'Chaabani',  'n.chaabani@delice.tn',  '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'Production & Qualité',   'RECRUTEUR', 'APPROVED', NOW(), NOW()),
('Youssef', 'Ferchichi', 'y.ferchichi@delice.tn', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'Finance & Comptabilité', 'RECRUTEUR', 'REJECTED', NOW(), NOW());

INSERT IGNORE INTO offres (code, titre, departement, type_contrat, niveau_etudes, experience_requise, nb_candidats, statut, date_publication, created_at) VALUES
('OFF001', 'Responsable RH',          'Ressources Humaines',       'CDI',   'Bac+5', '3-5 ans',  12, 'OUVERT',   CURDATE(), NOW()),
('OFF002', 'Commercial terrain',      'Commercial & Marketing',    'CDI',   'Bac+3', '1-3 ans',  8,  'OUVERT',   CURDATE(), NOW()),
('OFF003', 'Ingenieur Qualite',        'Production & Qualite',      'CDI',   'Bac+5', '3-5 ans',  5,  'FERME',    CURDATE(), NOW()),
('OFF004', 'Comptable Senior',        'Finance & Comptabilite',    'CDD',   'Bac+5', '+5 ans',   3,  'OUVERT',   CURDATE(), NOW()),
('OFF005', 'Developpeur React',       'Informatique & Digital',    'CDI',   'Bac+5', '1-3 ans',  20, 'OUVERT',   CURDATE(), NOW());

SELECT 'Base de données initialisée avec succès !' AS message;
