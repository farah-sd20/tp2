import { api } from "./client.js";

export async function register(form) {
  return api.post("/auth/register", {
    prenom:      form.prenom,
    nom:         form.nom,
    email:       form.email,
    password:    form.pass,
    departement: form.dept,
  });
}

export async function login(email, password) {
  const data = await api.post("/auth/login", { email, password });
  // Persist token
  localStorage.setItem("delijob_token", data.token);
  return data;
}

export function logout() {
  localStorage.removeItem("delijob_token");
}

export function getSavedToken() {
  return localStorage.getItem("delijob_token");
}
