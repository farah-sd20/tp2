import { api } from "./client.js";

// ── CRUD standard ────────────────────────────────────────────────────
export const getOffres         = ()           => api.get("/offres");
export const createOffre       = (dto)        => api.post("/offres", dto);
export const updateOffreStatut = (id, statut) => api.patch(`/offres/${id}/statut`, { statut });
export const deleteOffre       = (id)         => api.delete(`/offres/${id}`);

// ✅ NOUVEAU — Synchronisation ────────────────────────────────────────

/**
 * Récupérer les offres modifiées depuis lastSync
 * @param {string|null} lastSync - ISO datetime ou null pour tout récupérer
 */
export const syncPull = (lastSync = null) => {
    const url = lastSync
        ? `/offres/sync/pull?lastSync=${encodeURIComponent(lastSync)}`
        : `/offres/sync/pull`;
    return api.get(url);
};

/**
 * Envoyer des modifications locales vers le serveur
 * @param {Array} records - Liste de OffreDTO modifiés
 */
export const syncPush = (records) => api.post("/offres/sync/push", records);