import { api } from "./client.js";

export const getUsers        = ()          => api.get("/users");
export const getUsersByStatus= (status)    => api.get(`/users/status/${status}`);
export const updateUserStatus= (id,status) => api.patch(`/users/${id}/status`, { status });
export const deleteUser      = (id)        => api.delete(`/users/${id}`);
export const getMe           = ()          => api.get("/users/me");
