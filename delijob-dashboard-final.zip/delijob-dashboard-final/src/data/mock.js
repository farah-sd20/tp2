export const ADMIN_CREDS = {
  email: "admin@delijob.tn",
  pass:  "Admin2025",
};

export const DEPARTMENTS = [
  "Ressources Humaines",
  "Commercial & Marketing",
  "Production & Qualité",
  "Finance & Comptabilité",
  "Logistique & Supply Chain",
  "Informatique & Digital",
  "Direction Générale",
  "Industrie agroalimentaire",
];

export const SEED_REGISTRATIONS = [
  { id:1, prenom:"Salma",   nom:"Trabelsi",  email:"s.trabelsi@delice.tn",  dept:"Ressources Humaines",    pass:"test123", status:"approved" },
  { id:2, prenom:"Karim",   nom:"Boughanmi", email:"k.boughanmi@delice.tn", dept:"Commercial & Marketing", pass:"test123", status:"pending"  },
  { id:3, prenom:"Nadia",   nom:"Chaabani",  email:"n.chaabani@delice.tn",  dept:"Production & Qualité",   pass:"test123", status:"approved" },
  { id:4, prenom:"Youssef", nom:"Ferchichi", email:"y.ferchichi@delice.tn", dept:"Finance & Comptabilité", pass:"test123", status:"rejected" },
];

export const TYPES_CONTRAT = ["CDI", "CDD", "Stage", "Alternance", "Freelance"];
export const NIVEAUX       = ["Bac", "Bac+2", "Bac+3", "Bac+5", "Doctorat"];
export const EXPERIENCE    = ["Débutant", "1-3 ans", "3-5 ans", "+5 ans"];

export const SEED_OFFERS = [
  { id:1, code:"OFF001", titre:"Responsable RH",           dept:"Ressources Humaines",       type:"CDI",   niveau:"Bac+5", experience:"3-5 ans",  candidats:12, date:"01/06/2025", statut:"Ouvert"   },
  { id:2, code:"OFF002", titre:"Commercial terrain",       dept:"Commercial & Marketing",    type:"CDI",   niveau:"Bac+3", experience:"1-3 ans",  candidats:8,  date:"05/06/2025", statut:"Ouvert"   },
  { id:3, code:"OFF003", titre:"Ingénieur Qualité",        dept:"Production & Qualité",      type:"CDI",   niveau:"Bac+5", experience:"3-5 ans",  candidats:5,  date:"10/06/2025", statut:"Fermé"    },
  { id:4, code:"OFF004", titre:"Comptable Senior",         dept:"Finance & Comptabilité",    type:"CDD",   niveau:"Bac+5", experience:"+5 ans",   candidats:3,  date:"12/06/2025", statut:"Ouvert"   },
  { id:5, code:"OFF005", titre:"Développeur React",        dept:"Informatique & Digital",    type:"CDI",   niveau:"Bac+5", experience:"1-3 ans",  candidats:20, date:"14/06/2025", statut:"Ouvert"   },
  { id:6, code:"OFF006", titre:"Stage Marketing Digital",  dept:"Commercial & Marketing",    type:"Stage", niveau:"Bac+3", experience:"Débutant", candidats:15, date:"15/06/2025", statut:"Ouvert"   },
  { id:7, code:"OFF007", titre:"Chef de Projet SI",        dept:"Informatique & Digital",    type:"CDI",   niveau:"Bac+5", experience:"+5 ans",   candidats:7,  date:"18/06/2025", statut:"En pause" },
  { id:8, code:"OFF008", titre:"Technicien Maintenance",   dept:"Production & Qualité",      type:"CDI",   niveau:"Bac+2", experience:"1-3 ans",  candidats:4,  date:"20/06/2025", statut:"Ouvert"   },
  { id:9, code:"OFF009", titre:"Responsable Logistique",   dept:"Logistique & Supply Chain", type:"CDI",   niveau:"Bac+5", experience:"3-5 ans",  candidats:6,  date:"22/06/2025", statut:"Fermé"    },
];
