import { useTheme } from "./theme-provider.jsx";

export function ModeToggle() {
  const { theme, setTheme } = useTheme();

  return (
    <div style={{ display: "flex", gap: "8px", alignItems: "center" }}>
      <button
        onClick={() => setTheme("light")}
        style={{
          padding: "8px 12px",
          borderRadius: "8px",
          border: theme === "light" ? "2px solid var(--blue)" : "1px solid var(--border-color)",
          background: theme === "light" ? "var(--blue)" : "transparent",
          color: theme === "light" ? "white" : "var(--text-primary)",
          cursor: "pointer",
          transition: "all 0.2s"
        }}
      >
        ☀️ Light
      </button>
      <button
        onClick={() => setTheme("dark")}
        style={{
          padding: "8px 12px",
          borderRadius: "8px",
          border: theme === "dark" ? "2px solid var(--blue)" : "1px solid var(--border-color)",
          background: theme === "dark" ? "var(--blue)" : "transparent",
          color: theme === "dark" ? "white" : "var(--text-primary)",
          cursor: "pointer",
          transition: "all 0.2s"
        }}
      >
        🌙 Dark
      </button>
      <button
        onClick={() => setTheme("system")}
        style={{
          padding: "8px 12px",
          borderRadius: "8px",
          border: theme === "system" ? "2px solid var(--blue)" : "1px solid var(--border-color)",
          background: theme === "system" ? "var(--blue)" : "transparent",
          color: theme === "system" ? "white" : "var(--text-primary)",
          cursor: "pointer",
          transition: "all 0.2s"
        }}
      >
        💻 System
      </button>
    </div>
  );
}