import Logo   from "./logo.jsx";
import Button  from "./button.jsx";
import { useApp } from "../context/appcontext.jsx";

export default function Navbar({ light = false, showActions = true }) {
  const { navigate } = useApp();

  return (
    <nav style={{
      display: "flex", alignItems: "center", justifyContent: "space-between",
      padding: "14px 32px",
      background: light ? "var(--blue)" : "var(--white)",
      borderBottom: `1px solid ${light ? "rgba(255,255,255,.15)" : "var(--border)"}`,
      position: "sticky", top: 0, zIndex: 100,
      boxShadow: light ? "none" : "0 1px 8px rgba(0,0,0,.05)",
    }}>
      <Logo light={light} />

      {showActions && (
        <div style={{ display: "flex", gap: 10 }}>
        
        </div>
      )}
    </nav>
  );
}
