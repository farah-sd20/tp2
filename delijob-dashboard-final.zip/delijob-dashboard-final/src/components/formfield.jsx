export default function FormField({ label, children, hint }) {
  return (
    <div style={{ marginBottom: 15 }}>
      <label style={{
        display: "block",
        fontSize: 13, fontWeight: 600,
        color: "var(--dark)", marginBottom: 6,
      }}>
        {label}
      </label>

      {children}

      {hint && (
        <p style={{ fontSize: 11, color: "var(--muted)", marginTop: 4 }}>
          {hint}
        </p>
      )}
    </div>
  );
}
