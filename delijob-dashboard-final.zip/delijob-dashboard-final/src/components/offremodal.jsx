import { useState } from "react";
import Button    from "./button.jsx";
import FormField from "./formfield.jsx";
import { useApp } from "../context/appcontext.jsx";
import { DEPARTMENTS, TYPES_CONTRAT, NIVEAUX, EXPERIENCE } from "../data/mock.js";

const EMPTY = { code:"", titre:"", dept:"", type:"", niveau:"", experience:"", description:"" };

export default function OffreModal({ onClose }) {
  const { addOffer } = useApp();
  const [form, setForm] = useState(EMPTY);
  const [error, setError] = useState("");

  const set = (k,v) => setForm(f => ({...f,[k]:v}));

  function submit() {
    if (!form.code || !form.titre || !form.dept || !form.type)
      return setError("Veuillez remplir les champs obligatoires (Code, Titre, Département, Type).");
    setError("");
    addOffer(form);
    onClose();
  }

  return (
    <div style={{
      position:"fixed", inset:0, zIndex:1000,
      background:"rgba(0,0,0,0.45)", backdropFilter:"blur(3px)",
      display:"flex", alignItems:"center", justifyContent:"center", padding:20,
    }}>
      <div style={{
        background:"var(--white)", borderRadius:18,
        padding:"36px 40px", width:"100%", maxWidth:560,
        boxShadow:"0 24px 70px rgba(0,0,0,0.2)",
        maxHeight:"90vh", overflowY:"auto",
      }}>
        {/* Header */}
        <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:24 }}>
          <div style={{ display:"flex", alignItems:"center", gap:12 }}>
            <div style={{ width:4, height:28, background:"var(--blue)", borderRadius:2 }}/>
            <h2 style={{ fontFamily:"var(--font-serif)", fontSize:22, fontWeight:800, color:"var(--dark)" }}>
              Nouvelle offre d'emploi
            </h2>
          </div>
          <button onClick={onClose} style={{
            width:32,height:32,borderRadius:8,border:"1px solid var(--border)",
            background:"transparent",cursor:"pointer",fontSize:16,color:"var(--muted)",
          }}>✕</button>
        </div>

        {error && (
          <div style={{ background:"#FDF0EE", border:"1px solid #F0AEA8", borderRadius:9, padding:"10px 14px", fontSize:13, color:"#C0392B", marginBottom:16 }}>
            ⚠ {error}
          </div>
        )}

        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:14 }}>
          <FormField label="Code *">
            <input value={form.code} onChange={e=>set("code",e.target.value)} placeholder="OFF010" />
          </FormField>
          <FormField label="Type de contrat *">
            <select value={form.type} onChange={e=>set("type",e.target.value)}>
              <option value="">— Sélectionner —</option>
              {TYPES_CONTRAT.map(t=><option key={t}>{t}</option>)}
            </select>
          </FormField>
        </div>

        <FormField label="Titre du poste *">
          <input value={form.titre} onChange={e=>set("titre",e.target.value)} placeholder="Ex: Responsable Marketing" />
        </FormField>

        <FormField label="Département *">
          <select value={form.dept} onChange={e=>set("dept",e.target.value)}>
            <option value="">— Sélectionner —</option>
            {DEPARTMENTS.map(d=><option key={d}>{d}</option>)}
          </select>
        </FormField>

        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:14 }}>
          <FormField label="Niveau d'études">
            <select value={form.niveau} onChange={e=>set("niveau",e.target.value)}>
              <option value="">— Sélectionner —</option>
              {NIVEAUX.map(n=><option key={n}>{n}</option>)}
            </select>
          </FormField>
          <FormField label="Expérience requise">
            <select value={form.experience} onChange={e=>set("experience",e.target.value)}>
              <option value="">— Sélectionner —</option>
              {EXPERIENCE.map(e=><option key={e}>{e}</option>)}
            </select>
          </FormField>
        </div>

        <FormField label="Description">
          <textarea
            value={form.description}
            onChange={e=>set("description",e.target.value)}
            placeholder="Décrivez le poste, les responsabilités, les avantages..."
            rows={3}
            style={{
              width:"100%", padding:"12px 15px",
              border:"1.5px solid var(--border)", borderRadius:11,
              fontFamily:"var(--font-sans)", fontSize:14, resize:"vertical",
              outline:"none", transition:"border-color .2s",
            }}
            onFocus={e=>{ e.target.style.borderColor="var(--blue)"; e.target.style.boxShadow="0 0 0 3px rgba(0,61,165,.1)"; }}
            onBlur={e=>{ e.target.style.borderColor="var(--border)"; e.target.style.boxShadow="none"; }}
          />
        </FormField>

        <div style={{ display:"flex", gap:12, justifyContent:"flex-end", marginTop:8 }}>
          <Button variant="secondary" onClick={onClose}>Annuler</Button>
          <Button variant="primary" onClick={submit}>➕ Créer l'offre</Button>
        </div>
      </div>
    </div>
  );
}
