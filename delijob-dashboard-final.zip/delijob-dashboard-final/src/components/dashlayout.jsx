import { useState } from "react";
import { useI18n } from "../i18n/i18nContext.jsx";
import DashSidebar from "./dashsidebar.jsx";
import DashTopbar from "./dashtopbar.jsx";
import DashboardHome from "../pages/dashboardhome.jsx";
import OffresPage from "../pages/offrespage.jsx";
import CandidatsPage from "../pages/candidatspage.jsx";
import EntretienPage from "../pages/entretienpage.jsx";  // ← Import default
import AlertesPage from "../pages/alertespage.jsx";
import ProfilPage from "../pages/profilpage.jsx";
import MessageriePage from "../pages/Messageriepage.jsx";
import ArchivePage from "../pages/archivepage.jsx";
import ParametresPage from "../pages/parametres.jsx";

export default function DashLayout() {
  const [activePage, setActivePage] = useState("dashboard");
  const { t } = useI18n();

  const renderPage = () => {
    switch(activePage) {
      case "dashboard":  
        return <DashboardHome />;
      case "offres":     
        return <OffresPage />;
      case "candidats":  
        return <CandidatsPage />;
      case "planning":   
        return <EntretienPage />;  // ← Utilisation directe
      case "alertes":    
        return <AlertesPage />;
      case "profil":     
        return <ProfilPage />;
      case "messagerie": 
        return <MessageriePage />;
      case "archive":    
        return <ArchivePage />;
      case "parametres": 
        return <ParametresPage />;
      default:           
        return <DashboardHome />;
    }
  };

  return (
    <div style={{ display: "flex", minHeight: "100vh" }}>
      <DashSidebar activePage={activePage} onNavigate={setActivePage} />
      <div style={{ flex: 1, display: "flex", flexDirection: "column" }}>
        <DashTopbar />
        <main style={{
          padding: "24px 32px",
          background: "var(--gray-bg)",
          flex: 1,
          overflowY: "auto"
        }}>
          {renderPage()}
        </main>
      </div>
    </div>
  );
}