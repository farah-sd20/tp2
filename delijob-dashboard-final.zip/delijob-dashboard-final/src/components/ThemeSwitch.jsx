// Composant Switch pour le mode sombre/clair
function ThemeSwitch() {
  const { theme, setTheme } = useTheme();
  const [isDark, setIsDark] = useState(theme === "dark" || (theme === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches));

  useEffect(() => {
    const isDarkMode = theme === "dark" || (theme === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches);
    setIsDark(isDarkMode);
  }, [theme]);

  const toggleTheme = () => {
    if (isDark) {
      setTheme("light");
    } else {
      setTheme("dark");
    }
  };

  return (
    <div className="flex items-center space-x-2" style={{ marginLeft: "20px" }}>
      <button
        onClick={toggleTheme}
        style={{
          position: "relative",
          width: "52px",
          height: "28px",
          borderRadius: "14px",
          background: isDark ? "#1e293b" : "#e2e8f0",
          border: "none",
          cursor: "pointer",
          transition: "all 0.3s ease",
          boxShadow: "inset 0 1px 3px rgba(0,0,0,0.2)"
        }}
      >
        <div
          style={{
            position: "absolute",
            top: "2px",
            left: isDark ? "26px" : "2px",
            width: "24px",
            height: "24px",
            borderRadius: "12px",
            background: "white",
            transition: "left 0.3s ease",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: "12px",
            boxShadow: "0 1px 3px rgba(0,0,0,0.2)"
          }}
        >
          {isDark ? "🌙" : "☀️"}
        </div>
      </button>
      <span style={{ fontSize: "12px", color: "#64748B", fontWeight: 500 }}>
        {isDark ? "Sombre" : "Clair"}
      </span>
    </div>
  );
}