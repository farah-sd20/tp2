import { useState } from "react";
import Button from "./button.jsx";

const STATUS_CONFIG = {
  pending:  { label: "En attente", bg: "#FEF9EC", color: "#9A7D0A" },
  approved: { label: "Approuvé",   bg: "#EBF7EF", color: "#003DA5" },
  rejected: { label: "Refusé",     bg: "#FDF0EE", color: "#C0392B" },
};

const LEFT_COLORS = {
  pending:  "var(--blue)",
  approved: "#16a34a",
  rejected: "var(--red)",
};

export default function RegistrationRow({ reg, onApprove, onReject }) {
  const [hovered, setHovered] = useState(false);

  const initials  = (reg.prenom[0] + reg.nom[0]).toUpperCase();
  const isPending = reg.status === "pending";
  const sc        = STATUS_CONFIG[reg.status];

  return (
    <div
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        background: "var(--white)",
        borderRadius: 14,
        padding: "16px 20px",
        display: "flex", alignItems: "center",
        gap: 14, flexWrap: "wrap",
        border: "1px solid var(--border)",
        borderLeft: `4px solid ${LEFT_COLORS[reg.status]}`,
        boxShadow: hovered ? "var(--shadow-md)" : "var(--shadow-sm)",
        opacity: isPending ? 1 : 0.7,
        transition: "box-shadow .2s, opacity .2s",
      }}
    >
      {/* Avatar */}
      <div style={{
        width: 42, height: 42, borderRadius: 11,
        background: "var(--blue)", color: "white",
        display: "flex", alignItems: "center", justifyContent: "center",
        fontFamily: "var(--font-serif)", fontSize: 16, fontWeight: 700,
        flexShrink: 0,
      }}>
        {initials}
      </div>

      {/* Name & email */}
      <div style={{ flex: 1, minWidth: 140 }}>
        <div style={{ fontSize: 14, fontWeight: 600, color: "var(--dark)" }}>
          {reg.prenom} {reg.nom}
        </div>
        <div style={{ fontSize: 12, color: "var(--muted)", marginTop: 2 }}>
          {reg.email}
        </div>
      </div>

      {/* Department badge */}
      <span style={{
        fontSize: 11, fontWeight: 600,
        padding: "4px 10px", borderRadius: 20,
        background: "var(--blue-light)", color: "var(--blue)",
        whiteSpace: "nowrap",
      }}>
        {reg.dept}
      </span>

      {/* Actions or status badge */}
      {isPending ? (
        <div style={{ display: "flex", gap: 8 }}>
          <Button variant="success" size="sm" onClick={() => onApprove(reg.id)}>
            ✓ Approuver
          </Button>
          <Button variant="danger" size="sm" onClick={() => onReject(reg.id)}>
            ✕ Refuser
          </Button>
        </div>
      ) : (
        <span style={{
          fontSize: 12, fontWeight: 600,
          padding: "5px 12px", borderRadius: 20,
          background: sc.bg, color: sc.color,
          whiteSpace: "nowrap",
        }}>
          {sc.label}
        </span>
      )}
    </div>
  );
}
