import { useState, useEffect, useCallback, useRef } from "react";
import { useI18n } from "../i18n/i18nContext.jsx";
import { useTheme } from "./theme-provider.jsx";

const API_BASE = "http://localhost:8080";

function authHeaders() {
  const token = localStorage.getItem("token");
  return { ...(token ? { Authorization: `Bearer ${token}` } : {}) };
}

/* ── Theme-aware color tokens ── */
function useColors() {
  const { theme } = useTheme();

  const [isDark, setIsDark] = useState(() => {
    if (theme === "dark") return true;
    if (theme === "light") return false;
    return window.matchMedia("(prefers-color-scheme: dark)").matches;
  });

  useEffect(() => {
    if (theme === "dark") { setIsDark(true); return; }
    if (theme === "light") { setIsDark(false); return; }
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    setIsDark(mq.matches);
    const handler = (e) => setIsDark(e.matches);
    mq.addEventListener("change", handler);
    return () => mq.removeEventListener("change", handler);
  }, [theme]);

  return isDark ? {
    // ── DARK ──
    sidebar:       "#0f172a",
    border:        "#1e293b",
    sectionLabel:  "#334155",
    activeBg:      "#1e3a5f",
    activeColor:   "#60a5fa",
    activeBorder:  "#3b82f6",
    inactiveColor: "#475569",
    hoverBg:       "#1e293b",
    hoverColor:    "#94a3b8",
    iconInactive:  "#475569",
    logoBg:        "#1d4ed8",
    logoText:      "#f1f5f9",
    logoAccent:    "#60a5fa",
    logoSub:       "#334155",
    toggleBg:      "#1e293b",
    toggleHover:   "#1e3a5f",
    toggleColor:   "#60a5fa",
    footerColor:   "#334155",
    badge:         "#ef4444",
  } : {
    // ── LIGHT ──
    sidebar:       "#ffffff",
    border:        "#e2e8f0",
    sectionLabel:  "#cbd5e1",
    activeBg:      "#eff6ff",
    activeColor:   "#1a56c4",
    activeBorder:  "#1a56c4",
    inactiveColor: "#64748b",
    hoverBg:       "#f8fafc",
    hoverColor:    "#1e293b",
    iconInactive:  "#94a3b8",
    logoBg:        "#1a56c4",
    logoText:      "#0f172a",
    logoAccent:    "#1a56c4",
    logoSub:       "#94a3b8",
    toggleBg:      "#eff6ff",
    toggleHover:   "#dbeafe",
    toggleColor:   "#1a56c4",
    footerColor:   "#cbd5e1",
    badge:         "#ef4444",
  };
}

export default function DashSidebar({ activePage, onNavigate }) {
  const [collapsed, setCollapsed] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const pollRef = useRef(null);
  const { t } = useI18n();
  const c = useColors();

  const NAV_ITEMS = [
    {
      section: t("nav.sectionRecrutement"),
      items: [
        { id: "dashboard", icon: <IconGrid />,      label: t("nav.dashboard") },
        { id: "offres",    icon: <IconBriefcase />,  label: t("nav.offres") },
        { id: "candidats", icon: <IconUser />,       label: t("nav.candidats") },
      ],
    },
    {
      section: t("nav.sectionGestion"),
      items: [
        { id: "planning", icon: <IconCalendar />, label: t("nav.entretien") },
        { id: "alertes",  icon: <IconBell />,     label: t("nav.alertes") },
      ],
    },
    {
      section: t("nav.sectionCommunication"),
      items: [
        { id: "messagerie", icon: <IconMessage />, label: t("nav.messagerie"), badge: true },
      ],
    },
    {
      section: t("nav.sectionArchive"),
      items: [
        { id: "archive", icon: <IconFolder />, label: t("nav.archive") },
      ],
    },
    {
      section: t("nav.sectionParametres"),
      items: [
        { id: "profil",     icon: <IconUser />,     label: t("nav.profil") },
        { id: "parametres", icon: <IconSettings />, label: t("nav.parametres") },
      ],
    },
  ];

  const fetchUnread = useCallback(async () => {
    try {
      const res = await fetch(`${API_BASE}/api/messages/unread`, { headers: authHeaders() });
      if (!res.ok) return;
      const data = await res.json();
      setUnreadCount(typeof data === "number" ? data : (data.count || 0));
    } catch { }
  }, []);

  useEffect(() => {
    fetchUnread();
    pollRef.current = setInterval(fetchUnread, 30_000);
    return () => clearInterval(pollRef.current);
  }, [fetchUnread]);

  useEffect(() => {
    if (activePage === "messagerie") setUnreadCount(0);
  }, [activePage]);

  return (
    <aside style={{
      width: collapsed ? 64 : 240,
      minHeight: "100vh",
      background: c.sidebar,
      borderRight: `1px solid ${c.border}`,
      display: "flex",
      flexDirection: "column",
      transition: "width .25s ease, background .2s ease, border-color .2s ease",
      flexShrink: 0,
    }}>

      {/* Header */}
      <div style={{
        display: "flex",
        alignItems: "center",
        justifyContent: collapsed ? "center" : "space-between",
        padding: collapsed ? "0 14px" : "0 16px 0 20px",
        height: 60,
        borderBottom: `1px solid ${c.border}`,
        gap: 10,
        transition: "border-color .2s ease",
      }}>
        {!collapsed && (
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{
              width: 34, height: 34, borderRadius: 9,
              background: c.logoBg,
              display: "flex", alignItems: "center", justifyContent: "center",
              color: "white", fontFamily: "Georgia, serif",
              fontSize: 17, fontWeight: 800, flexShrink: 0,
              transition: "background .2s ease",
            }}>D</div>
            <div>
              <div style={{
                fontFamily: "Georgia, serif", fontSize: 15, fontWeight: 800,
                color: c.logoText, lineHeight: 1.1,
                transition: "color .2s ease",
              }}>
                Deli<span style={{ color: c.logoAccent }}>Job</span>
              </div>
              <div style={{
                fontSize: 9, color: c.logoSub,
                letterSpacing: "1.5px", textTransform: "uppercase", marginTop: 1,
                transition: "color .2s ease",
              }}>
                {t("nav.recrutement")}
              </div>
            </div>
          </div>
        )}

        <button
          onClick={() => setCollapsed(prev => !prev)}
          style={{
            width: 26, height: 26, borderRadius: 7,
            background: c.toggleBg,
            border: "none", cursor: "pointer",
            display: "flex", alignItems: "center", justifyContent: "center",
            color: c.toggleColor, fontSize: 13, fontWeight: 700,
            flexShrink: 0, transition: "background .15s, color .2s ease",
          }}
          onMouseEnter={e => e.currentTarget.style.background = c.toggleHover}
          onMouseLeave={e => e.currentTarget.style.background = c.toggleBg}
        >
          {collapsed ? "›" : "‹"}
        </button>
      </div>

      {/* Nav */}
      <nav style={{ flex: 1, padding: "8px 0", overflowY: "auto" }}>
        {NAV_ITEMS.map(group => (
          <div key={group.section} style={{ marginBottom: 4 }}>

            {!collapsed && (
              <div style={{
                fontSize: 10, fontWeight: 700,
                letterSpacing: "1.4px", textTransform: "uppercase",
                color: c.sectionLabel, padding: "12px 20px 4px",
                transition: "color .2s ease",
              }}>
                {group.section}
              </div>
            )}

            {group.items.map(item => {
              const active = activePage === item.id;
              const showBadge = item.badge && unreadCount > 0;

              return (
                <button
                  key={item.id}
                  onClick={() => onNavigate(item.id)}
                  title={collapsed ? item.label : ""}
                  style={{
                    width: "100%",
                    display: "flex", alignItems: "center",
                    gap: 10,
                    padding: collapsed ? "9px 0" : "9px 16px 9px 18px",
                    justifyContent: collapsed ? "center" : "flex-start",
                    border: "none", cursor: "pointer",
                    background: active ? c.activeBg : "transparent",
                    color: active ? c.activeColor : c.inactiveColor,
                    fontFamily: "system-ui, -apple-system, sans-serif",
                    fontSize: 13,
                    fontWeight: active ? 600 : 400,
                    borderLeft: active ? `3px solid ${c.activeBorder}` : "3px solid transparent",
                    borderRadius: "0 8px 8px 0",
                    marginRight: 8,
                    transition: "all .15s",
                    textAlign: "left",
                    position: "relative",
                  }}
                  onMouseEnter={e => {
                    if (!active) {
                      e.currentTarget.style.background = c.hoverBg;
                      e.currentTarget.style.color = c.hoverColor;
                    }
                  }}
                  onMouseLeave={e => {
                    if (!active) {
                      e.currentTarget.style.background = "transparent";
                      e.currentTarget.style.color = c.inactiveColor;
                    }
                  }}
                >
                  <span style={{
                    width: 22, height: 22, display: "flex",
                    alignItems: "center", justifyContent: "center",
                    flexShrink: 0, position: "relative",
                    color: active ? c.activeColor : c.iconInactive,
                    transition: "color .2s ease",
                  }}>
                    {item.icon}
                    {collapsed && showBadge && (
                      <span style={{
                        position: "absolute", top: -4, right: -5,
                        width: 8, height: 8, borderRadius: "50%",
                        background: c.badge, border: `1.5px solid ${c.sidebar}`,
                      }} />
                    )}
                  </span>

                  {!collapsed && (
                    <span style={{ flex: 1, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                      {item.label}
                    </span>
                  )}

                  {!collapsed && showBadge && (
                    <span style={{
                      background: c.badge, color: "white",
                      borderRadius: 100, padding: "1px 7px",
                      fontSize: 10, fontWeight: 700, flexShrink: 0,
                    }}>
                      {unreadCount}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        ))}
      </nav>

      {/* Footer */}
      {!collapsed && (
        <div style={{
          padding: "12px 16px",
          borderTop: `1px solid ${c.border}`,
          fontSize: 10, color: c.footerColor,
          textAlign: "center", letterSpacing: "0.5px",
          transition: "color .2s ease, border-color .2s ease",
        }}>
          © 2025 DeliJob — Délice Danone
        </div>
      )}
    </aside>
  );
}

/* ── SVG Icon components ── */

function IconGrid() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/>
      <rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/>
    </svg>
  );
}

function IconBriefcase() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="2" y="7" width="20" height="14" rx="2"/>
      <path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2"/>
      <line x1="12" y1="12" x2="12" y2="12"/>
    </svg>
  );
}

function IconUser() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
      <circle cx="12" cy="7" r="4"/>
    </svg>
  );
}

function IconCalendar() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="4" width="18" height="18" rx="2"/>
      <line x1="16" y1="2" x2="16" y2="6"/>
      <line x1="8" y1="2" x2="8" y2="6"/>
      <line x1="3" y1="10" x2="21" y2="10"/>
    </svg>
  );
}

function IconBell() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
      <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
    </svg>
  );
}

function IconMessage() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
    </svg>
  );
}

function IconFolder() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>
    </svg>
  );
}

function IconSettings() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="3"/>
      <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>
    </svg>
  );
}