import { useState } from "react";
import { useApp } from "../context/appcontext.jsx";
import { useI18n } from "../i18n/i18nContext.jsx";

export default function DashTopbar() {
  const { currentUser, logout, notifs, navigate } = useApp();
  const { t } = useI18n();
  const [notifOpen, setNotifOpen] = useState(false);

  const unread = notifs.filter(n => !n.lu).length;

  const initials = currentUser
    ? (currentUser.prenom[0] + currentUser.nom[0]).toUpperCase()
    : "?";

  const recent = notifs.slice(0, 5);

  const TYPE_COLORS = {
    candidature: { bg: "#eff6ff", color: "#3b82f6" },
    entretien:   { bg: "#fffbeb", color: "#f59e0b" },
    validation:  { bg: "#f0fdf4", color: "#22c55e" },
    systeme:     { bg: "#f8fafc", color: "#64748b" },
    offre:       { bg: "#f5f3ff", color: "#8b5cf6" },
    messagerie:  { bg: "#fff1f2", color: "#f43f5e" },
  };

  function relTime(ts) {
    const diff = Date.now() - ts;
    const mins = Math.floor(diff / 60000);
    if (mins < 1) return t("notifs.instantané");
    if (mins < 60) return `${mins} min`;
    const h = Math.floor(diff / 3600000);
    if (h < 24) return `${h}h`;
    return `${Math.floor(diff / 86400000)}j`;
  }

  return (
    <header style={{
      height: 64,
      background: "var(--white)",
      borderBottom: "1px solid var(--border)",
      display: "flex",
      alignItems: "center",
      justifyContent: "flex-end",
      padding: "0 24px",
      flexShrink: 0,
      boxShadow: "0 1px 8px rgba(0,0,0,0.05)",
      gap: 12,
      position: "relative",
      zIndex: 100,
    }}>

      {/* Icône notification */}
      <div style={{ position: "relative" }}>
        <button
          onClick={() => setNotifOpen(o => !o)}
          style={{
            background: notifOpen ? "var(--blue-light, #eff6ff)" : "transparent",
            border: `1px solid ${notifOpen ? "var(--blue)" : "var(--border)"}`,
            borderRadius: 10, width: 38, height: 38,
            display: "flex", alignItems: "center", justifyContent: "center",
            cursor: "pointer", transition: "all .15s",
            color: notifOpen ? "var(--blue)" : "var(--muted)",
            position: "relative",
          }}
          onMouseEnter={e => {
            e.currentTarget.style.borderColor = "var(--blue)";
            e.currentTarget.style.color = "var(--blue)";
            e.currentTarget.style.background = "var(--blue-light, #eff6ff)";
          }}
          onMouseLeave={e => {
            if (!notifOpen) {
              e.currentTarget.style.borderColor = "var(--border)";
              e.currentTarget.style.color = "var(--muted)";
              e.currentTarget.style.background = "transparent";
            }
          }}
        >
          <svg width="17" height="17" viewBox="0 0 24 24" fill="none"
            stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
            <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
          </svg>
        </button>

        {unread > 0 && (
          <span style={{
            position: "absolute", top: -5, right: -5,
            background: "#ef4444", color: "#fff",
            borderRadius: "50%", width: 18, height: 18,
            fontSize: 10, fontWeight: 700,
            display: "flex", alignItems: "center", justifyContent: "center",
            pointerEvents: "none", border: "2px solid var(--white)", lineHeight: 1,
          }}>
            {unread > 9 ? "9+" : unread}
          </span>
        )}

        {notifOpen && (
          <>
            <div onClick={() => setNotifOpen(false)} style={{ position: "fixed", inset: 0, zIndex: 90 }} />
            <div style={{
              position: "absolute", top: 46, right: 0,
              background: "var(--white)", border: "1px solid var(--border)",
              borderRadius: 14, boxShadow: "0 12px 40px rgba(0,0,0,0.13)",
              width: 320, zIndex: 100, overflow: "hidden",
            }}>
              {/* Header dropdown */}
              <div style={{
                padding: "14px 16px 12px", borderBottom: "1px solid var(--border)",
                display: "flex", alignItems: "center", justifyContent: "space-between",
              }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <span style={{ fontWeight: 700, fontSize: 13, color: "var(--dark)" }}>
                    {t("notifs.titre")}
                  </span>
                  {unread > 0 && (
                    <span style={{
                      background: "#3b82f6", color: "white",
                      fontSize: 10, fontWeight: 700,
                      padding: "1px 7px", borderRadius: 20,
                    }}>
                      {unread} {t("notifs.nouveau")}
                    </span>
                  )}
                </div>
                <button
                  onClick={() => { setNotifOpen(false); navigate("alertes"); }}
                  style={{
                    background: "transparent", border: "none",
                    fontSize: 11, fontWeight: 600, color: "var(--blue)",
                    cursor: "pointer", padding: 0,
                  }}
                >
                  {t("notifs.voirTout")} →
                </button>
              </div>

              {/* Liste */}
              <div style={{ maxHeight: 340, overflowY: "auto" }}>
                {recent.length === 0 ? (
                  <div style={{
                    padding: "36px 20px", textAlign: "center",
                    color: "var(--muted)", fontSize: 12,
                  }}>
                    <div style={{ fontSize: 28, marginBottom: 8 }}>🔔</div>
                    {t("notifs.aucune")}
                  </div>
                ) : recent.map((n, i) => {
                  const cfg = TYPE_COLORS[n.type] || TYPE_COLORS.systeme;
                  return (
                    <div
                      key={n.id}
                      style={{
                        padding: "11px 16px",
                        borderBottom: i < recent.length - 1 ? "1px solid var(--border)" : "none",
                        display: "flex", alignItems: "flex-start", gap: 10,
                        background: n.lu ? "transparent" : "#fafbff",
                        cursor: "default", transition: "background .12s",
                      }}
                      onMouseEnter={e => e.currentTarget.style.background = "#f8fafc"}
                      onMouseLeave={e => e.currentTarget.style.background = n.lu ? "transparent" : "#fafbff"}
                    >
                      <div style={{ flexShrink: 0, marginTop: 4 }}>
                        <div style={{
                          width: 7, height: 7, borderRadius: "50%",
                          background: n.lu ? "#e2e8f0" : "#3b82f6",
                        }} />
                      </div>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{
                          fontSize: 12, fontWeight: n.lu ? 500 : 700,
                          color: n.lu ? "#64748b" : "#0f172a",
                          marginBottom: 2,
                          whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis",
                        }}>
                          {n.titre}
                        </div>
                        <div style={{
                          fontSize: 11, color: "#94a3b8", lineHeight: 1.4,
                          display: "-webkit-box", WebkitLineClamp: 2,
                          WebkitBoxOrient: "vertical", overflow: "hidden",
                        }}>
                          {n.message}
                        </div>
                        <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 4 }}>
                          <span style={{
                            fontSize: 9, fontWeight: 700, textTransform: "uppercase",
                            letterSpacing: ".5px", padding: "1px 6px", borderRadius: 20,
                            background: cfg.bg, color: cfg.color,
                          }}>
                            {n.type}
                          </span>
                          <span style={{ fontSize: 10, color: "#cbd5e1" }}>
                            {relTime(n.timestamp)}
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {notifs.length > 5 && (
                <div style={{
                  padding: "10px 16px", borderTop: "1px solid var(--border)", textAlign: "center",
                }}>
                  <button
                    onClick={() => { setNotifOpen(false); navigate("alertes"); }}
                    style={{
                      background: "transparent", border: "none",
                      fontSize: 12, fontWeight: 600, color: "var(--blue)", cursor: "pointer",
                    }}
                  >
                    {t("notifs.voirLes")} {notifs.length} {t("notifs.titre").toLowerCase()} →
                  </button>
                </div>
              )}
            </div>
          </>
        )}
      </div>

      {/* Avatar + Déconnexion */}
      <div style={{ display: "flex", alignItems: "center", gap: 10, flexShrink: 0 }}>
        <div style={{
          width: 38, height: 38, borderRadius: "50%",
          border: "2px solid var(--blue)",
          display: "flex", alignItems: "center", justifyContent: "center",
          fontWeight: 700, fontSize: 14,
          color: "var(--blue)", background: "var(--blue-light)", cursor: "pointer",
        }}>
          {initials}
        </div>
        <button
          onClick={logout}
          style={{
            background: "transparent", border: "1px solid var(--border)",
            borderRadius: 8, padding: "5px 12px",
            fontSize: 12, fontWeight: 500, color: "var(--muted)",
            cursor: "pointer", transition: "all .15s",
          }}
          onMouseEnter={e => {
            e.currentTarget.style.borderColor = "var(--blue)";
            e.currentTarget.style.color = "var(--blue)";
          }}
          onMouseLeave={e => {
            e.currentTarget.style.borderColor = "var(--border)";
            e.currentTarget.style.color = "var(--muted)";
          }}
        >
          {t("auth.deconnexion")}
        </button>
      </div>
    </header>
  );
}