export default function FeatureCard({ icon, title, desc, animDelay = "0s" }) {
  return (
    <div style={{
      background: "var(--white)",
      borderRadius: 20,
      padding: "26px 22px",
      border: "1px solid var(--border)",
      boxShadow: "var(--shadow-sm)",
      flex: "1 1 190px",
      maxWidth: 230,
      textAlign: "center",
      animation: `float 3.5s ease-in-out ${animDelay} infinite`,
    }}>
      {/* Icon circle */}
      <div style={{
        width: 52, height: 52, borderRadius: 14,
        background: "var(--blue-light)",
        display: "flex", alignItems: "center", justifyContent: "center",
        fontSize: 24, margin: "0 auto 14px",
      }}>
        {icon}
      </div>

      <div style={{
        fontFamily: "var(--font-serif)",
        fontSize: 15, fontWeight: 700,
        color: "var(--dark)", marginBottom: 6,
      }}>
        {title}
      </div>

      <div style={{ fontSize: 12, color: "var(--muted)", lineHeight: 1.6 }}>
        {desc}
      </div>
    </div>
  );
}
