import { useState } from "react";

const SIZES = {
  sm: { padding: "7px 16px",  fontSize: 13, borderRadius: 9  },
  md: { padding: "10px 22px", fontSize: 14, borderRadius: 11 },
  lg: { padding: "14px 34px", fontSize: 15, borderRadius: 13 },
  xl: { padding: "14px",      fontSize: 15, borderRadius: 11 },
};

const VARIANTS = {
  primary: {
    normal: { background:"var(--blue)",      color:"white", border:"none",                              boxShadow:"0 4px 14px rgba(0,61,165,.28)" },
    hover:  { background:"var(--blue-dark)", color:"white", border:"none", transform:"translateY(-1px)", boxShadow:"0 7px 22px rgba(0,61,165,.38)" },
  },
  secondary: {
    normal: { background:"var(--white)", color:"var(--dark)", border:"1.5px solid var(--border)", boxShadow:"var(--shadow-sm)" },
    hover:  { background:"#F0EDE8",      color:"var(--dark)", border:"1.5px solid #CCC9C3",       boxShadow:"var(--shadow-md)" },
  },
  outline: {
    normal: { background:"transparent", color:"var(--blue)",      border:"1.5px solid var(--blue)"      },
    hover:  { background:"var(--blue-light)", color:"var(--blue-dark)", border:"1.5px solid var(--blue-dark)" },
  },
  ghost: {
    normal: { background:"transparent",           color:"rgba(255,255,255,.65)", border:"1px solid rgba(255,255,255,.2)"  },
    hover:  { background:"rgba(255,255,255,.12)", color:"white",                 border:"1px solid rgba(255,255,255,.4)"  },
  },
  success: {
    normal: { background:"rgba(22,163,74,.09)", color:"var(--approve-green)", border:"1.5px solid rgba(22,163,74,.25)" },
    hover:  { background:"var(--approve-green)",        color:"white",        border:"1.5px solid var(--blue)"        },
  },
  danger: {
    normal: { background:"rgba(192,57,43,.08)", color:"var(--red)", border:"1.5px solid rgba(192,57,43,.22)" },
    hover:  { background:"var(--red)",          color:"white",       border:"1.5px solid var(--red)"          },
  },
};

export default function Button({
  children,
  variant   = "primary",
  size      = "md",
  onClick,
  disabled  = false,
  fullWidth = false,
  style: extraStyle = {},
}) {
  const [hovered, setHovered] = useState(false);

  const v  = VARIANTS[variant] || VARIANTS.primary;
  const vStyle = hovered && !disabled ? v.hover : v.normal;

  return (
    <button
      onClick={disabled ? undefined : onClick}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        display: "inline-flex", alignItems: "center",
        justifyContent: "center", gap: 8,
        fontFamily: "var(--font-sans)", fontWeight: 600,
        cursor: disabled ? "not-allowed" : "pointer",
        opacity: disabled ? 0.55 : 1,
        transition: "all .2s ease",
        width: fullWidth ? "100%" : undefined,
        outline: "none",
        ...SIZES[size],
        ...vStyle,
        ...extraStyle,
      }}
    >
      {children}
    </button>
  );
}
