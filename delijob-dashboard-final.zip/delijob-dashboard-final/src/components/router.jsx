import { useApp }      from "../context/appcontext.jsx";
import HomePage        from "../pages/homepage.jsx";
import RegisterPage    from "../pages/registerpage.jsx";
import PendingPage     from "../pages/pendingpage.jsx";
import LoginPage       from "../pages/loginpage.jsx";
import AdminPage       from "../pages/adminpage.jsx";
import DashboardPage   from "../pages/dashboardpage.jsx";

const ROUTES = {
  home:      HomePage,
  register:  RegisterPage,
  pending:   PendingPage,
  login:     LoginPage,
  admin:     AdminPage,
  dashboard: DashboardPage,
};

export default function Router() {
  const { page } = useApp();
  const Page = ROUTES[page] || HomePage;
  return <Page />;
}
