import { useApp } from "../context/appcontext.jsx";

export default function Logo({ light = false }) {
  const { navigate } = useApp();

  return (
    <div
      onClick={() => navigate("home")}
      style={{ display:"flex", alignItems:"center", gap:10, cursor:"pointer" }}
    >
      {/* Icon */}
      <div style={{
        width: 40, height: 40,
        borderRadius: 10,
        background: light ? "rgba(255,255,255,0.2)" : "var(--blue)",
        display: "flex", alignItems: "center", justifyContent: "center",
        fontFamily: "var(--font-serif)",
        color: "white", fontSize: 20, fontWeight: 800,
        boxShadow: "0 3px 10px rgba(0,61,165,0.3)",
        flexShrink: 0,
        border: light ? "1px solid rgba(255,255,255,0.3)" : "none",
      }}>
        D
      </div>

      {/* Text */}
      <div>
        <div style={{
          fontFamily: "var(--font-serif)",
          fontSize: 19, fontWeight: 800,
          color: light ? "white" : "var(--dark)",
          lineHeight: 1.1, letterSpacing: "-0.3px",
        }}>
          DeliJob
        </div>
        <div style={{
          fontSize: 9, fontWeight: 600,
          letterSpacing: "1.8px", textTransform: "uppercase",
          color: light ? "rgba(255,255,255,0.5)" : "var(--muted)",
          marginTop: 1,
        }}>
          By Délice Danone
        </div>
      </div>
    </div>
  );
}
