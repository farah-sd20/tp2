export default function PageHeader({ title, subtitle, action }) {
  return (
    <div style={{
      background: "linear-gradient(135deg, var(--blue) 0%, #1a56db 100%)",
      borderRadius: 14,
      padding: "24px 32px",
      marginBottom: 24,
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      boxShadow: "0 4px 20px rgba(0,61,165,0.25)",
    }}>
      <div>
        <h1 style={{
          fontFamily: "var(--font-serif)",
          fontSize: 24, fontWeight: 800,
          color: "white", marginBottom: 4,
        }}>{title}</h1>
        <p style={{ fontSize:13, color:"rgba(255,255,255,0.75)" }}>{subtitle}</p>
      </div>
      {action && (
        <div>{action}</div>
      )}
    </div>
  );
}
