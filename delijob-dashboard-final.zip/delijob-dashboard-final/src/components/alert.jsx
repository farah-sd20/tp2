const CONFIG = {
  success: { bg:"#EBF7EF", color:"#003DA5", border:"#A8D5B8", icon:"✓" },
  error:   { bg:"#FDF0EE", color:"#C0392B", border:"#F0AEA8", icon:"✕" },
  warning: { bg:"#FEF9EC", color:"#9A7D0A", border:"#F0D88A", icon:"⚠" },
};

export default function Alert({ type, message }) {
  if (!message) return null;

  const c = CONFIG[type] || CONFIG.error;

  return (
    <div
      className="fade-in"
      style={{
        display: "flex", alignItems: "center", gap: 10,
        padding: "11px 14px", borderRadius: 10,
        fontSize: 13, fontWeight: 500,
        marginBottom: 16,
        background: c.bg, color: c.color,
        border: `1px solid ${c.border}`,
      }}
    >
      <span style={{
        width: 20, height: 20, borderRadius: "50%",
        background: c.color, color: "white",
        display: "flex", alignItems: "center", justifyContent: "center",
        fontSize: 11, fontWeight: 700, flexShrink: 0,
      }}>
        {c.icon}
      </span>
      {message}
    </div>
  );
}
