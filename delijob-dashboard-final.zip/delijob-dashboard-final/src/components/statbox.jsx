export default function StatBox({ num, label, color = "var(--dark)" }) {
  return (
    <div style={{
      background: "var(--white)",
      borderRadius: 16,
      padding: "22px 20px",
      textAlign: "center",
      border: "1px solid var(--border)",
      boxShadow: "var(--shadow-sm)",
    }}>
      <div style={{
        fontFamily: "var(--font-serif)",
        fontSize: 38, fontWeight: 800,
        color, lineHeight: 1,
      }}>
        {num}
      </div>
      <div style={{
        fontSize: 11, color: "var(--muted)",
        fontWeight: 600, marginTop: 7,
        textTransform: "uppercase", letterSpacing: "0.8px",
      }}>
        {label}
      </div>
    </div>
  );
}
