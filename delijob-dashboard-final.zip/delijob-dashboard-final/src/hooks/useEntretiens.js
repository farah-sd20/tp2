import { useState, useCallback } from "react";

const BASE = "http://localhost:8080/api/entretiens";

function authHeaders() {
  const token = localStorage.getItem("token");
  const h = { "Content-Type": "application/json" };
  if (token) h["Authorization"] = "Bearer " + token;
  console.log("Authorization:", h["Authorization"]?.substring(0, 40));
  return h;
}

async function handleResponse(res) {
  if (!res.ok) { 
    const t = await res.text(); 
    console.error("Response error:", res.status, t);
    throw new Error(t || "HTTP " + res.status); 
  }
  if (res.status === 204) return null;
  return res.json();
}

export function useEntretiens() {
  const [entretiens, setEntretiens] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const fetchAll = useCallback(async (q = "") => {
    if (!localStorage.getItem("token")) return;
    setLoading(true); 
    setError(null);
    try {
      const url = q ? BASE + "?q=" + encodeURIComponent(q) : BASE;
      console.log("🔍 Fetching all entretiens:", url);
      const data = await handleResponse(await fetch(url, { headers: authHeaders() }));
      setEntretiens(Array.isArray(data) ? data : []);
      console.log("✅ Fetched entretiens:", data?.length || 0);
    } catch(e) { 
      console.error("❌ Fetch all error:", e);
      setError(e.message); 
    } finally { 
      setLoading(false); 
    }
  }, []);

  const fetchByMonth = useCallback(async (year, month) => {
    if (!localStorage.getItem("token")) return;
    setLoading(true); 
    setError(null);
    try {
      const url = BASE + "/month?year=" + year + "&month=" + month;
      console.log("📅 Fetching by month:", url);
      const data = await handleResponse(await fetch(url, { headers: authHeaders() }));
      setEntretiens(Array.isArray(data) ? data : []);
      console.log("✅ Fetched entretiens for month:", data?.length || 0);
    } catch(e) { 
      console.error("❌ Fetch by month error:", e);
      setError(e.message); 
    } finally { 
      setLoading(false); 
    }
  }, []);

  const create = useCallback(async (dto) => {
    console.log("📝 Creating entretien with DTO:", JSON.stringify(dto, null, 2));
    
    try {
        const response = await fetch(BASE, { 
            method: "POST", 
            headers: authHeaders(), 
            body: JSON.stringify(dto) 
        });
        
        console.log("📊 Response status:", response.status);
        
        if (!response.ok) {
            const errorText = await response.text();
            console.error("❌ Error response:", errorText);
            throw new Error(errorText || "HTTP " + response.status);
        }
        
        const data = await response.json();
        console.log("✅ Success:", data);
        setEntretiens(prev => [...prev, data]);
        return data;
    } catch (error) {
        console.error("❌ Create failed:", error);
        throw error;
    }
  }, []);

  const update = useCallback(async (id, dto) => {
    console.log("✏️ Updating entretien:", id, dto);
    
    try {
      const response = await fetch(BASE + "/" + id, { 
        method: "PUT", 
        headers: authHeaders(), 
        body: JSON.stringify(dto) 
      });
      
      console.log("📊 Update response status:", response.status);
      
      if (!response.ok) {
        const errorText = await response.text();
        console.error("❌ Update error response:", errorText);
        throw new Error(errorText || "HTTP " + response.status);
      }
      
      const data = await response.json();
      console.log("✅ Update success:", data);
      setEntretiens(prev => prev.map(e => e.id === id ? data : e));
      return data;
    } catch (error) {
      console.error("❌ Update failed:", error);
      throw error;
    }
  }, []);

  const remove = useCallback(async (id) => {
    console.log("🗑️ Deleting entretien:", id);
    
    try {
      const response = await fetch(BASE + "/" + id, { 
        method: "DELETE", 
        headers: authHeaders() 
      });
      
      console.log("📊 Delete response status:", response.status);
      
      if (!response.ok) {
        const errorText = await response.text();
        console.error("❌ Delete error response:", errorText);
        throw new Error(errorText || "HTTP " + response.status);
      }
      
      console.log("✅ Delete success");
      setEntretiens(prev => prev.filter(e => e.id !== id));
    } catch (error) {
      console.error("❌ Delete failed:", error);
      throw error;
    }
  }, []);

  return { 
    entretiens, 
    loading, 
    error, 
    fetchAll, 
    fetchByMonth, 
    create, 
    update, 
    remove 
  };
}