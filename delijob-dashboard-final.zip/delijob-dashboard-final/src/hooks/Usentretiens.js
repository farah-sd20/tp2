// hooks/useEntretiens.js
import { useState, useCallback } from "react";

const BASE = "http://localhost:8080/api/entretiens";

function authHeaders() {
  const token = localStorage.getItem("token");
  return {
    "Content-Type": "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
}

async function handleResponse(res) {
  if (!res.ok) {
    const text = await res.text();
    throw new Error(text || `HTTP ${res.status}`);
  }
  if (res.status === 204) return null;
  return res.json();
}

export function useEntretiens() {
  const [entretiens, setEntretiens] = useState([]);
  const [loading,    setLoading]    = useState(false);
  const [error,      setError]      = useState(null);

  const fetchAll = useCallback(async (q = "") => {
    const token = localStorage.getItem("token");
    if (!token) return;
    setLoading(true);
    setError(null);
    try {
      const url = q ? `${BASE}?q=${encodeURIComponent(q)}` : BASE;
      const data = await handleResponse(await fetch(url, { headers: authHeaders() }));
      setEntretiens(data);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchByMonth = useCallback(async (year, month) => {
    const token = localStorage.getItem("token");
    if (!token) return;
    setLoading(true);
    setError(null);
    try {
      const url = `${BASE}/month?year=${year}&month=${month}`;
      const data = await handleResponse(await fetch(url, { headers: authHeaders() }));
      setEntretiens(data);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, []);

  const create = useCallback(async (dto) => {
    const data = await handleResponse(
      await fetch(BASE, {
        method: "POST",
        headers: authHeaders(),
        body: JSON.stringify(dto),
      })
    );
    setEntretiens((prev) => [...prev, data]);
    return data;
  }, []);

  const update = useCallback(async (id, dto) => {
    const data = await handleResponse(
      await fetch(`${BASE}/${id}`, {
        method: "PUT",
        headers: authHeaders(),
        body: JSON.stringify(dto),
      })
    );
    setEntretiens((prev) => prev.map((e) => (e.id === id ? data : e)));
    return data;
  }, []);

  const remove = useCallback(async (id) => {
    await handleResponse(
      await fetch(`${BASE}/${id}`, {
        method: "DELETE",
        headers: authHeaders(),
      })
    );
    setEntretiens((prev) => prev.filter((e) => e.id !== id));
  }, []);

  return { entretiens, loading, error, fetchAll, fetchByMonth, create, update, remove };
}