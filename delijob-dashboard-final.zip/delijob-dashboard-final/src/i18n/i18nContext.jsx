import { createContext, useContext, useState, useEffect } from "react";
import { translations } from "./translations.js";

const I18nContext = createContext(null);

function loadLang() {
  try {
    const prefs = JSON.parse(localStorage.getItem("prefs"));
    return prefs?.langue || "fr";
  } catch {
    return "fr";
  }
}

function applyDir(lang) {
  document.documentElement.setAttribute("dir", lang === "ar" ? "rtl" : "ltr");
  document.documentElement.setAttribute("lang", lang);
}

export function I18nProvider({ children }) {
  const [langue, setLangueState] = useState(loadLang);

  useEffect(() => {
    applyDir(langue);
  }, [langue]);

  function setLangue(lang) {
    setLangueState(lang);
    applyDir(lang);
    // Sync avec les prefs existantes
    try {
      const prefs = JSON.parse(localStorage.getItem("prefs")) || {};
      localStorage.setItem("prefs", JSON.stringify({ ...prefs, langue: lang }));
    } catch {
      localStorage.setItem("prefs", JSON.stringify({ langue: lang }));
    }
  }

  // t("nav.dashboard") → traduit la clé avec notation pointée
  function t(key) {
    const parts = key.split(".");
    let val = translations[langue];
    for (const part of parts) {
      val = val?.[part];
    }
    // Fallback sur le français si clé manquante
    if (val === undefined) {
      let fallback = translations["fr"];
      for (const part of parts) fallback = fallback?.[part];
      return fallback ?? key;
    }
    return val;
  }

  return (
    <I18nContext.Provider value={{ langue, setLangue, t }}>
      {children}
    </I18nContext.Provider>
  );
}

export function useI18n() {
  return useContext(I18nContext);
}