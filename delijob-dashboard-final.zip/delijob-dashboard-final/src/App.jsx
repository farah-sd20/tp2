import "./styles/globals.css";
import { AppProvider } from "./context/appcontext.jsx";
import { ThemeProvider } from "./components/theme-provider.jsx";
import { I18nProvider } from "./i18n/i18nContext.jsx"; // ← nouveau
import Router from "./components/router.jsx";

export default function App() {
  return (
    <ThemeProvider defaultTheme="system" storageKey="app-theme">
      <I18nProvider>            {/* ← entoure AppProvider */}
        <AppProvider>
          <Router />
        </AppProvider>
      </I18nProvider>
    </ThemeProvider>
  );
}