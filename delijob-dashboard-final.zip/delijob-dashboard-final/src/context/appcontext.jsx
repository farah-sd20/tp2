import { createContext, useContext, useState, useEffect, useRef, useCallback } from "react";
import { SEED_REGISTRATIONS } from "../data/mock.js";

export const AppContext = createContext(null);

const API_BASE = "http://localhost:8080";

function authHeaders() {
  const token = localStorage.getItem("token");
  return {
    "Content-Type": "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
}

const BACK_TO_FRONT = {
  "OUVERT":     "Ouvert",
  "FERME":      "Fermé",
  "EN_PAUSE":   "En pause",
  "EN_ATTENTE": "En attente",
};
const FRONT_TO_BACK = {
  "Ouvert":     "OUVERT",
  "Fermé":      "FERME",
  "En pause":   "EN_PAUSE",
  "En attente": "EN_ATTENTE",
};

function toFrontStatut(s) { return BACK_TO_FRONT[s] ?? s; }
function toBackStatut(s)  { return FRONT_TO_BACK[s] ?? s.toUpperCase(); }

// ✅ id forcé en Number
const mapOffre = (o) => ({
  id:          Number(o.id),
  code:        o.code,
  titre:       o.titre,
  dept:        o.departement,
  type:        o.typeContrat,
  niveau:      o.niveauEtudes  || null,
  description: o.description  || null,
  candidats:   o.nbCandidats,
  statut:      toFrontStatut(o.statut),
  createdAt:   o.datePublication,
  createdBy:   o.createurEmail,
});

function decodeToken(token) {
  try {
    const payload = JSON.parse(atob(token.split(".")[1]));
    if (payload.exp && payload.exp * 1000 < Date.now()) {
      console.warn("⚠️ Token expiré");
      return null;
    }
    return payload;
  } catch {
    console.warn("⚠️ Token invalide");
    return null;
  }
}

function buildUserFromStorage() {
  const token = localStorage.getItem("token");
  if (!token) return null;
  const payload = decodeToken(token);
  if (!payload) {
    ["token", "prenom", "nom", "email", "role"].forEach(k => localStorage.removeItem(k));
    return null;
  }
  return {
    token,
    role:   payload.role,
    email:  payload.sub,
    prenom: localStorage.getItem("prenom") || "",
    nom:    localStorage.getItem("nom")    || "",
    id:     payload.sub,
  };
}

function loadOffersFromCache() {
  try {
    const raw = localStorage.getItem("app_offers_cache");
    if (raw) return JSON.parse(raw);
  } catch {}
  return [];
}
function saveOffersToCache(offers) {
  try { localStorage.setItem("app_offers_cache", JSON.stringify(offers)); } catch {}
}

function normaliseNotif(n) {
  return {
    id:        n.id,
    type:      n.type      || "systeme",
    titre:     n.titre     || "",
    message:   n.message   || "",
    lu:        n.lu        ?? false,
    timestamp: typeof n.timestamp === "string"
      ? new Date(n.timestamp).getTime()
      : (n.timestamp ?? Date.now()),
    avatar:    n.avatar    ?? null,
    avatarBg:  n.avatarBg  ?? null,
    action:    n.action    ?? null,
  };
}

function loadNotifsFromStorage() {
  const saved = localStorage.getItem("app_notifications");
  if (saved) {
    try { return JSON.parse(saved).map(normaliseNotif); } catch {}
  }
  return [{
    id: 1, type: "systeme",
    titre: "🎉 Bienvenue sur Alertes RH",
    message: "Vous recevrez ici toutes les notifications importantes",
    lu: false, timestamp: Date.now(),
  }];
}

function getInitialPage() {
  const user = buildUserFromStorage();
  if (!user) return "home";
  return user.role?.toUpperCase() === "ADMIN" ? "admin" : "dashboard";
}

export function AppProvider({ children }) {
  const [page, setPage]               = useState(getInitialPage);
  const [regs, setRegs]               = useState(SEED_REGISTRATIONS);
  const [nid,  setNid]                = useState(5);

  const [offers, setOffers]               = useState(loadOffersFromCache);
  const [offersLoading, setOffersLoading] = useState(() => loadOffersFromCache().length === 0);

  const [currentUser, setCurrentUser] = useState(() => buildUserFromStorage());
  const [notifs, setNotifs]           = useState(loadNotifsFromStorage);
  const [nextId, setNextId]           = useState(() => {
    const saved = localStorage.getItem("app_notifications");
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        return Math.max(...parsed.map(n => n.id), 0) + 1;
      } catch {}
    }
    return 2;
  });
  const [backendAvailable, setBackendAvailable] = useState(true);

  const pollingRef      = useRef(null);
  const retryTimeoutRef = useRef(null);

  useEffect(() => {
    localStorage.setItem("app_notifications", JSON.stringify(notifs));
  }, [notifs]);

  // ── Fetch offres ──────────────────────────────────────────────────────────
  const fetchOffers = useCallback(async () => {
    const token = localStorage.getItem("token");
    if (!token || !currentUser) return;

    if (loadOffersFromCache().length === 0) setOffersLoading(true);

    try {
      const isAdmin = currentUser?.role?.toUpperCase() === "ADMIN";
      const endpoint = isAdmin ? "/api/offres" : "/api/offres/public";

      const res = await fetch(`${API_BASE}${endpoint}`, { headers: authHeaders() });

      if (!res.ok) {
        const errorBody = await res.text().catch(() => "");
        console.error(`❌ HTTP ${res.status} sur ${endpoint}:`, errorBody);
        throw new Error(`HTTP ${res.status}`);
      }

      const data = await res.json();
      const mapped = data.map(mapOffre);

      setOffers(mapped);
      saveOffersToCache(mapped);

    } catch (err) {
      console.error("Erreur chargement offres:", err);
    } finally {
      setOffersLoading(false);
    }
  }, [currentUser]);

  useEffect(() => {
    if (currentUser) fetchOffers();
    else {
      setOffers([]);
      saveOffersToCache([]);
    }
  }, [currentUser, fetchOffers]);

  // ── CRUD offres ───────────────────────────────────────────────────────────
  async function addOffer(form) {
    const body = {
      code:              form.code,
      titre:             form.titre,
      departement:       form.dept,
      typeContrat:       form.type,
      niveauEtudes:      form.niveau      || null,
      experienceRequise: form.experience  || null,
      description:       form.description || null,
    };
    const res = await fetch(`${API_BASE}/api/offres`, {
      method:  "POST",
      headers: authHeaders(),
      body:    JSON.stringify(body),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error ?? `HTTP ${res.status}`);
    }
    await fetchOffers();
    addNotif({
      type:    "offre",
      titre:   "📢 Offre publiée",
      message: `Offre « ${form.titre} » publiée avec succès`,
    });
  }

  // ✅ updateOffer corrigé — id forcé en Number, champs null au lieu de ""
  async function updateOffer(id, form) {
    const numericId = Number(id);
    const body = {
      titre:        form.titre        || null,
      departement:  form.dept         || null,
      typeContrat:  form.type         || null,
      niveauEtudes: form.niveau       || null,
      description:  form.description  || null,
    };
    const res = await fetch(`${API_BASE}/api/offres/${numericId}`, {
      method:  "PUT",
      headers: authHeaders(),
      body:    JSON.stringify(body),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error ?? `HTTP ${res.status}`);
    }
    await fetchOffers();
    addNotif({
      type:    "offre",
      titre:   "✏️ Offre modifiée",
      message: `Offre « ${form.titre} » mise à jour`,
    });
  }

  async function updateOfferStatus(id, frontStatut) {
    // ✅ Mise à jour optimiste
    setOffers(prev => {
      const updated = prev.map(o => o.id === id ? { ...o, statut: frontStatut } : o);
      saveOffersToCache(updated);
      return updated;
    });
    try {
      const res = await fetch(`${API_BASE}/api/offres/${Number(id)}/statut`, {
        method:  "PATCH",
        headers: authHeaders(),
        body:    JSON.stringify({ statut: toBackStatut(frontStatut) }),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      await fetchOffers();
      const offer = offers.find(o => o.id === id);
      const msgs = {
        "Ouvert":     { titre: "✅ Offre publiée",    message: `Offre « ${offer?.titre} » publiée` },
        "Fermé":      { titre: "🔒 Offre clôturée",   message: `Offre « ${offer?.titre} » clôturée` },
        "En pause":   { titre: "⏸️ Offre en pause",   message: `Offre « ${offer?.titre} » en pause` },
        "En attente": { titre: "⏳ Offre en révision", message: `Offre « ${offer?.titre} » en révision` },
      };
      if (msgs[frontStatut]) addNotif({ type: "offre", ...msgs[frontStatut] });
    } catch (err) {
      console.error("Erreur updateOfferStatus:", err);
      await fetchOffers();
    }
  }

  async function deleteOffer(id) {
    const offer = offers.find(o => o.id === id);
    // ✅ Suppression optimiste
    setOffers(prev => {
      const updated = prev.filter(o => o.id !== id);
      saveOffersToCache(updated);
      return updated;
    });
    try {
      const res = await fetch(`${API_BASE}/api/offres/${Number(id)}`, {
        method:  "DELETE",
        headers: authHeaders(),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      if (offer) addNotif({
        type:    "offre",
        titre:   "🗑️ Offre supprimée",
        message: `Offre « ${offer.titre} » supprimée`,
      });
    } catch (err) {
      console.error("Erreur deleteOffer:", err);
      await fetchOffers();
    }
  }

  // ── Notifications ─────────────────────────────────────────────────────────
  function addNotif({ type = "systeme", titre, message, avatar = null, avatarBg = null, action = null }) {
    const newNotif = normaliseNotif({
      id: nextId, type, titre, message, lu: false,
      timestamp: Date.now(), avatar, avatarBg, action,
    });
    setNotifs(prev => [newNotif, ...prev]);
    setNextId(prev => prev + 1);
    const token = localStorage.getItem("token");
    if (token && backendAvailable) {
      fetch(`${API_BASE}/api/notifications`, {
        method: "POST",
        headers: authHeaders(),
        body: JSON.stringify({ type, titre, message, avatar, avatarBg, action }),
      }).catch(() => setBackendAvailable(false));
    }
    return newNotif.id;
  }

  async function fetchNotifs() {
    const token = localStorage.getItem("token");
    if (!token) return;
    try {
      const res = await fetch(`${API_BASE}/api/notifications/recent`, {
        headers: authHeaders(),
        signal: AbortSignal.timeout(5000),
      });
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data) && data.length > 0) {
          setNotifs(data.map(normaliseNotif));
          setBackendAvailable(true);
        }
      }
    } catch {
      setBackendAvailable(false);
      if (retryTimeoutRef.current) clearTimeout(retryTimeoutRef.current);
      retryTimeoutRef.current = setTimeout(() => {
        setBackendAvailable(true);
        fetchNotifs();
      }, 30000);
    }
  }

  useEffect(() => {
    if (pollingRef.current)      clearInterval(pollingRef.current);
    if (retryTimeoutRef.current) clearTimeout(retryTimeoutRef.current);
    if (!currentUser) return;
    fetchNotifs();
    if (backendAvailable) {
      pollingRef.current = setInterval(fetchNotifs, 30000);
    }
    return () => {
      clearInterval(pollingRef.current);
      clearTimeout(retryTimeoutRef.current);
    };
  }, [currentUser, backendAvailable]);

  function markNotifRead(id) {
    setNotifs(prev => prev.map(n => n.id === id ? { ...n, lu: true } : n));
    if (backendAvailable) {
      fetch(`${API_BASE}/api/notifications/${id}/read`, {
        method: "PATCH", headers: authHeaders(),
      }).catch(() => {});
    }
  }

  function markAllNotifsRead() {
    setNotifs(prev => prev.map(n => ({ ...n, lu: true })));
    if (backendAvailable) {
      fetch(`${API_BASE}/api/notifications/read-all`, {
        method: "PATCH", headers: authHeaders(),
      }).catch(() => {});
    }
  }

  function dismissNotif(id) {
    setNotifs(prev => prev.filter(n => n.id !== id));
    if (backendAvailable) {
      fetch(`${API_BASE}/api/notifications/${id}`, {
        method: "DELETE", headers: authHeaders(),
      }).catch(() => {});
    }
  }

  function clearAllNotifs() {
    setNotifs([]);
    if (backendAvailable) {
      fetch(`${API_BASE}/api/notifications`, {
        method: "DELETE", headers: authHeaders(),
      }).catch(() => {});
    }
  }

  // ── Auth / Nav / Candidatures ─────────────────────────────────────────────
  function navigate(p) { setPage(p); window.scrollTo(0, 0); }

  function addReg(form) {
    setRegs(prev => [...prev, { id: nid, ...form, status: "pending" }]);
    setNid(n => n + 1);
    addNotif({
      type:    "candidature",
      titre:   "📄 Nouvelle candidature",
      message: `${form.prenom} ${form.nom} a postulé`,
      action:  { label: "Voir", url: "#" },
    });
    navigate("pending");
  }

  function updateStatus(id, status) {
    const registration = regs.find(r => r.id === id);
    setRegs(prev => prev.map(r => r.id === id ? { ...r, status } : r));
    if (!registration) return;
    const msgs = {
      approved: { titre: "✅ Candidature acceptée", message: `${registration.prenom} ${registration.nom} a été accepté` },
      rejected: { titre: "❌ Candidature refusée",  message: `${registration.prenom} ${registration.nom} a été refusé` },
      pending:  { titre: "⏳ En attente",            message: `${registration.prenom} ${registration.nom} est en attente` },
    };
    if (msgs[status]) addNotif({ type: "validation", ...msgs[status] });
  }

  function loginUser(userData) {
    const { token } = userData;
    const payload = decodeToken(token);
    if (!payload) { console.error("❌ Token invalide"); return; }

    localStorage.setItem("token",  token);
    localStorage.setItem("role",   payload.role  || "");
    localStorage.setItem("prenom", userData.prenom || "");
    localStorage.setItem("nom",    userData.nom    || "");
    localStorage.setItem("email",  payload.sub     || "");

    const user = {
      token,
      role:   payload.role,
      email:  payload.sub,
      prenom: userData.prenom || "",
      nom:    userData.nom    || "",
      id:     payload.sub,
    };

    setCurrentUser(user);

    addNotif({
      type:    "systeme",
      titre:   "✅ Connexion réussie",
      message: `Bienvenue ${userData.prenom || "utilisateur"} !`,
    });

    navigate(payload.role?.toUpperCase() === "ADMIN" ? "admin" : "dashboard");
  }

  function logout() {
    ["token", "prenom", "nom", "email", "role"].forEach(k => localStorage.removeItem(k));
    localStorage.removeItem("app_offers_cache");
    setCurrentUser(null);
    setOffers([]);
    navigate("home");
  }

  const currentUserId = currentUser?.id   ?? null;
  const userRole      = currentUser?.role ?? null;

  const value = {
    page, navigate,
    regs, addReg, updateStatus,
    currentUser, setCurrentUser, loginUser, logout,
    currentUserId, userRole,
    offers, offersLoading, fetchOffers,
    addOffer, updateOffer, updateOfferStatus, deleteOffer,
    notifs, fetchNotifs, addNotif,
    markNotifRead, markAllNotifsRead, dismissNotif, clearAllNotifs,
    backendAvailable,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error("useApp must be used within an AppProvider");
  return context;
};