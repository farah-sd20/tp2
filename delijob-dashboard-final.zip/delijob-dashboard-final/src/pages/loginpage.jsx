import { useState } from "react";
import Navbar        from "../components/navbar.jsx";
import Button        from "../components/button.jsx";
import Alert         from "../components/Alert.jsx";
import FormField     from "../components/FormField.jsx";
import { useApp }    from "../context/appcontext.jsx";
import { useI18n }   from "../i18n/i18nContext.jsx";

const API_BASE = "http://localhost:8080";

function EyeIcon({ visible }) {
  return visible ? (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
         stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
      <circle cx="12" cy="12" r="3"/>
    </svg>
  ) : (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
         stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/>
      <line x1="1" y1="1" x2="23" y2="23"/>
    </svg>
  );
}

function LoginView({ onForgot, loginRole }) {
  const { loginUser, navigate } = useApp();
  const { t } = useI18n();

  const [email,   setEmail]   = useState("");
  const [pass,    setPass]    = useState("");
  const [showPw,  setShowPw]  = useState(false);
  const [alert,   setAlert]   = useState(null);
  const [loading, setLoading] = useState(false);

  const isAdmin = loginRole === "admin";

  async function submit() {
    if (!email || !pass) {
      setAlert({ type: "error", message: "Veuillez renseigner vos identifiants." });
      return;
    }
    setAlert(null);
    setLoading(true);
    try {
      const res = await fetch(`${API_BASE}/api/auth/login`, {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password: pass }),
      });

      let data = {};
      try { data = await res.json(); } catch { /* corps vide */ }

      if (res.status === 403) {
        if (data.error === "PENDING") {
          setAlert({ type: "warning", message: "Votre compte est en attente de validation par l'administrateur." });
        } else if (data.error === "REJECTED") {
          setAlert({ type: "error", message: "Votre demande a été refusée. Contactez l'administration." });
        } else {
          setAlert({ type: "error", message: data.message || "Accès refusé." });
        }
        return;
      }

      if (res.status === 401) {
        setAlert({ type: "error", message: "Email ou mot de passe incorrect." });
        return;
      }

      if (!res.ok) {
        setAlert({ type: "error", message: data.error || `Erreur serveur (${res.status}).` });
        return;
      }

      // ✅ FIX : Sauvegarder le token sous la clé "token" utilisée partout dans l'app
      //          (CandidatsPage.jsx → getToken() lit "token" depuis localStorage)
      if (data.token) {
        localStorage.setItem("token", data.token);
      } else if (data.accessToken) {
        // Certains backends renvoient "accessToken" — on normalise
        localStorage.setItem("token", data.accessToken);
        data.token = data.accessToken;
      }

      // loginUser gère le contexte + la navigation
      loginUser(data);

    } catch (err) {
      console.error("Login error:", err);
      setAlert({ type: "error", message: "Impossible de contacter le serveur. Vérifiez que le backend est démarré." });
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <div style={{
        display: "inline-flex", alignItems: "center", gap: 6,
        background: "var(--blue-light)",
        border: "1px solid rgba(0,61,165,.15)",
        color: "var(--blue)",
        padding: "5px 14px", borderRadius: 100,
        fontSize: 11, fontWeight: 700, letterSpacing: "0.4px",
        marginBottom: 16, textTransform: "uppercase",
      }}>
        {isAdmin ? "🛡️" : "👤"} {isAdmin ? "Admin" : "Recruteur"}
      </div>

      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 6 }}>
        <div style={{ width: 4, height: 30, background: "var(--blue)", borderRadius: 2 }} />
        <h2 style={{ fontFamily: "var(--font-serif)", fontSize: 25, fontWeight: 800, color: "var(--dark)" }}>
          {isAdmin ? t("auth.connexionAdmin") : t("connexionRecruteur")}
        </h2>
      </div>
      <p style={{ fontSize: 13, color: "var(--muted)", paddingLeft: 16, marginBottom: 24 }}>
        {isAdmin ? t("auth.gererPlateforme") : t("espaceRecruteur")}
      </p>

      <Alert {...(alert || {})} />

      <FormField label={t("auth.email")}>
        <input
          type="email"
          value={email}
          onChange={e => setEmail(e.target.value)}
          onKeyDown={e => e.key === "Enter" && !loading && submit()}
          placeholder={t("auth.emailPlaceholder")}
          disabled={loading}
        />
      </FormField>

      <FormField label={
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <span>{t("auth.motDePasse")}</span>
          <span
            onClick={onForgot}
            style={{ fontSize: 12, color: "var(--blue)", fontWeight: 600, cursor: "pointer", userSelect: "none" }}
          >
            {t("auth.motDePasseOublie")}
          </span>
        </div>
      }>
        <div style={{ position: "relative" }}>
          <input
            type={showPw ? "text" : "password"}
            value={pass}
            onChange={e => setPass(e.target.value)}
            onKeyDown={e => e.key === "Enter" && !loading && submit()}
            placeholder="••••••••"
            disabled={loading}
            style={{ paddingRight: 36, width: "100%", boxSizing: "border-box" }}
          />
          <button
            type="button"
            onClick={() => setShowPw(v => !v)}
            tabIndex={-1}
            style={{
              position: "absolute", right: 10, top: "50%",
              transform: "translateY(-50%)",
              background: "none", border: "none", cursor: "pointer",
              padding: 0, color: "var(--muted)", display: "flex", alignItems: "center",
            }}
          >
            <EyeIcon visible={showPw} />
          </button>
        </div>
      </FormField>

      <Button
        variant="primary" fullWidth size="xl"
        disabled={loading} onClick={submit}
        style={{ marginTop: 8 }}
      >
        {loading && (
          <span style={{
            width: 14, height: 14,
            border: "2px solid rgba(255,255,255,.35)",
            borderTopColor: "white", borderRadius: "50%",
            animation: "spin .8s linear infinite",
            display: "inline-block", marginRight: 8,
          }} />
        )}
        {loading ? t("auth.connexionEnCours") : t("auth.seConnecter")}
      </Button>

      <div style={{
        display: "flex", alignItems: "center", gap: 10,
        margin: "20px 0", color: "#D5CFC8", fontSize: 11,
      }}>
        <div style={{ flex: 1, height: 1, background: "var(--border)" }} />
        compte de démonstration
        <div style={{ flex: 1, height: 1, background: "var(--border)" }} />
      </div>

      {!isAdmin && (
        <p style={{ textAlign: "center", fontSize: 13, color: "var(--muted)", marginTop: 18 }}>
          Pas encore inscrit ?{" "}
          {/* ✅ FIX : useApp() ne peut pas être appelé en dehors d'un composant React.
                       On utilise le navigate déjà extrait en haut du composant. */}
          <span
            onClick={() => navigate("register")}
            style={{ color: "var(--blue)", fontWeight: 600, cursor: "pointer" }}
          >
            {t("register.titre")}
          </span>
        </p>
      )}
    </>
  );
}

function ForgotView({ onBack }) {
  const { t } = useI18n();
  const [email,   setEmail]   = useState("");
  const [alert,   setAlert]   = useState(null);
  const [loading, setLoading] = useState(false);
  const [sent,    setSent]    = useState(false);

  async function submit() {
    if (!email) {
      setAlert({ type: "error", message: "Veuillez saisir votre adresse email." });
      return;
    }
    if (!/\S+@\S+\.\S+/.test(email)) {
      setAlert({ type: "error", message: "Adresse email invalide." });
      return;
    }
    setAlert(null);
    setLoading(true);
    try {
      const res = await fetch(`${API_BASE}/api/auth/forgot-password`, {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      let data = {};
      try { data = await res.json(); } catch {}
      if (!res.ok) {
        setAlert({ type: "error", message: data.error || data.message || `Erreur serveur (${res.status}).` });
        return;
      }
      setSent(true);
    } catch {
      setAlert({ type: "error", message: "Impossible de contacter le serveur." });
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 6 }}>
        <button type="button" onClick={onBack} style={{
          background: "none", border: "none", cursor: "pointer",
          padding: 4, color: "var(--muted)", display: "flex", alignItems: "center",
        }}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none"
               stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="15 18 9 12 15 6"/>
          </svg>
        </button>
        <div style={{ width: 4, height: 30, background: "var(--blue)", borderRadius: 2 }} />
        <h2 style={{ fontFamily: "var(--font-serif)", fontSize: 25, fontWeight: 800, color: "var(--dark)" }}>
          {t("auth.motDePasseOublieTitle")}
        </h2>
      </div>

      {!sent ? (
        <>
          <p style={{ fontSize: 13, color: "var(--muted)", paddingLeft: 52, marginBottom: 24, lineHeight: 1.6 }}>
            {t("auth.motDePasseOublieDesc")}
          </p>
          <Alert {...(alert || {})} />
          <FormField label={t("auth.emailProfessionnel")}>
            <input
              type="email" value={email}
              onChange={e => setEmail(e.target.value)}
              onKeyDown={e => e.key === "Enter" && !loading && submit()}
              placeholder={t("auth.emailPlaceholder")}
              disabled={loading}
            />
          </FormField>
          <Button variant="primary" fullWidth size="xl"
            disabled={loading} onClick={submit} style={{ marginTop: 8 }}>
            {loading && (
              <span style={{
                width: 14, height: 14,
                border: "2px solid rgba(255,255,255,.35)",
                borderTopColor: "white", borderRadius: "50%",
                animation: "spin .8s linear infinite",
                display: "inline-block", marginRight: 8,
              }} />
            )}
            {loading ? t("auth.envoiEnCours") : t("envoyer")}
          </Button>
        </>
      ) : (
        <div style={{ paddingLeft: 52 }}>
          <div style={{
            background: "#EAF3DE", border: "1px solid #C0DD97",
            borderRadius: 12, padding: "20px",
            display: "flex", flexDirection: "column", alignItems: "center",
            gap: 12, marginTop: 16, textAlign: "center",
          }}>
            <div style={{
              width: 48, height: 48, borderRadius: "50%", background: "#C0DD97",
              display: "flex", alignItems: "center", justifyContent: "center",
            }}>
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none"
                   stroke="#3B6D11" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
                <polyline points="22,6 12,13 2,6"/>
              </svg>
            </div>
            <p style={{ fontSize: 14, fontWeight: 700, color: "#27500A", margin: 0 }}>{t("auth.emailEnvoye")}</p>
            <p style={{ fontSize: 13, color: "#3B6D11", margin: 0, lineHeight: 1.6 }}>
              {t("auth.emailEnvoyeDesc")}
            </p>
            <p style={{ fontSize: 12, color: "#639922", margin: 0 }}>{t("auth.verifierSpams")}</p>
          </div>
          <button type="button" onClick={onBack} style={{
            background: "none", border: "none", cursor: "pointer",
            color: "var(--blue)", fontWeight: 600, fontSize: 13,
            marginTop: 20, padding: 0, display: "block", width: "100%", textAlign: "center",
          }}>
            {t("auth.retourConnexion")}
          </button>
        </div>
      )}
    </>
  );
}

export default function LoginPage() {
  const [view, setView] = useState("login");
  const loginRole = localStorage.getItem("loginRole") || "recruteur";

  return (
    <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column", background: "var(--warm)" }}>
      <Navbar showActions={false} />
      <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", padding: "40px 20px" }}>
        <div className="fade-up" style={{
          background: "var(--white)", borderRadius: 22,
          padding: "40px 44px", width: "100%", maxWidth: 420,
          boxShadow: "var(--shadow-lg)", border: "1px solid var(--border)",
        }}>
          {view === "login"
            ? <LoginView onForgot={() => setView("forgot")} loginRole={loginRole} />
            : <ForgotView onBack={() => setView("login")} />}
        </div>
      </div>
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}