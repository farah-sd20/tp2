import { useState, useEffect } from "react";
import { useApp } from "../context/appcontext.jsx";
import { useI18n } from "../i18n/i18nContext.jsx";

/* ─── Config par type ───────────────────────────────────────────────── */
const TYPE_CONFIG = {
  candidature: {
    label: "Candidature",
    iconBg: "#eff6ff", iconColor: "#3b82f6",
    icon: () => (
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2">
        <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>
      </svg>
    ),
  },
  entretien: {
    label: "Entretien",
    iconBg: "#fffbeb", iconColor: "#f59e0b",
    icon: () => (
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2">
        <rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>
      </svg>
    ),
  },
  validation: {
    label: "Validation",
    iconBg: "#f0fdf4", iconColor: "#22c55e",
    icon: () => (
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
        <polyline points="20 6 9 17 4 12"/>
      </svg>
    ),
  },
  systeme: {
    label: "Système",
    iconBg: "#f8fafc", iconColor: "#64748b",
    icon: () => (
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2">
        <circle cx="12" cy="12" r="3"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14M4.93 4.93a10 10 0 0 0 0 14.14"/>
      </svg>
    ),
  },
  offre: {
    label: "Offre",
    iconBg: "#f5f3ff", iconColor: "#8b5cf6",
    icon: () => (
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2">
        <rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2"/>
      </svg>
    ),
  },
  messagerie: {
    label: "Messagerie",
    iconBg: "#fff1f2", iconColor: "#f43f5e",
    icon: () => (
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2">
        <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
      </svg>
    ),
  },
};

/* ─── Relative time ─────────────────────────────────────────────────── */
function relativeTime(timestamp) {
  const diff = Date.now() - timestamp;
  const mins = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);
  const days = Math.floor(diff / 86400000);
  if (mins < 1) return "à l'instant";
  if (mins < 60) return `il y a ${mins} min`;
  if (hours < 24) return `il y a ${hours}h`;
  if (days === 1) return "hier";
  return `il y a ${days} jours`;
}

/* ─── Regrouper par jour ────────────────────────────────────────────── */
function groupByDay(alertes) {
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const yesterday = today - 86400000;

  const groups = {};
  alertes.forEach(a => {
    const d = new Date(a.timestamp);
    const dayStart = new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
    let label;
    if (dayStart >= today) label = "Aujourd'hui";
    else if (dayStart >= yesterday) label = "Hier";
    else label = d.toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long" });
    if (!groups[label]) groups[label] = [];
    groups[label].push(a);
  });
  return groups;
}

/* ─── Composant notification ────────────────────────────────────────── */
function NotifCard({ notif, onDismiss, onRead }) {
  const { t } = useI18n();
  const cfg = TYPE_CONFIG[notif.type] || TYPE_CONFIG.systeme;
  const [hovered, setHovered] = useState(false);
  const [leaving, setLeaving] = useState(false);

  function handleDismiss() {
    setLeaving(true);
    setTimeout(() => onDismiss(notif.id), 280);
  }

  const IconComponent = cfg.icon;
  const isLu = notif.lu;

  return (
    <div
      onMouseEnter={() => { setHovered(true); if (!isLu) onRead(notif.id); }}
      onMouseLeave={() => setHovered(false)}
      style={{
        display: "flex",
        gap: 14,
        alignItems: "flex-start",
        padding: "16px 18px",
        borderRadius: 14,
        background: isLu ? "white" : "#fafbff",
        border: `1px solid ${isLu ? "#f1f5f9" : "#e0e7ff"}`,
        boxShadow: hovered ? "0 4px 20px rgba(0,61,165,0.10)" : (isLu ? "none" : "0 1px 6px rgba(99,102,241,0.07)"),
        transition: "all .22s ease",
        opacity: leaving ? 0 : 1,
        transform: leaving ? "translateX(20px)" : "translateX(0)",
        position: "relative",
        cursor: "default",
      }}
    >
      {!isLu && (
        <div style={{
          position: "absolute",
          left: 0,
          top: 12,
          bottom: 12,
          width: 3,
          borderRadius: "0 3px 3px 0",
          background: "linear-gradient(180deg, #3b82f6, #6366f1)",
        }} />
      )}

      <div style={{ flexShrink: 0, position: "relative" }}>
        {notif.avatar ? (
          <div style={{
            width: 42,
            height: 42,
            borderRadius: "50%",
            background: notif.avatarBg || "#6366f1",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: 13,
            fontWeight: 800,
            color: "white",
          }}>
            {notif.avatar}
          </div>
        ) : (
          <div style={{
            width: 42,
            height: 42,
            borderRadius: "50%",
            background: cfg.iconBg,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            color: cfg.iconColor,
          }}>
            <IconComponent />
          </div>
        )}
        {notif.avatar && (
          <div style={{
            position: "absolute",
            bottom: -2,
            right: -2,
            width: 18,
            height: 18,
            borderRadius: "50%",
            background: cfg.iconBg,
            border: "2px solid white",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            color: cfg.iconColor,
          }}>
            <div style={{ transform: "scale(0.7)" }}><IconComponent /></div>
          </div>
        )}
      </div>

      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 8, marginBottom: 3 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <span style={{
              fontSize: 14,
              fontWeight: isLu ? 500 : 700,
              color: isLu ? "#475569" : "#0f172a",
            }}>
              {notif.titre}
            </span>
            {!isLu && (
              <span style={{
                width: 7,
                height: 7,
                borderRadius: "50%",
                background: "#3b82f6",
                display: "inline-block",
              }} />
            )}
          </div>
          <span style={{ fontSize: 11, color: "#94a3b8", whiteSpace: "nowrap" }}>
            {relativeTime(notif.timestamp)}
          </span>
        </div>

        <p style={{
          margin: "0 0 10px",
          fontSize: 13,
          color: isLu ? "#94a3b8" : "#475569",
          lineHeight: 1.5,
        }}>
          {notif.message}
        </p>

        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <span style={{
            fontSize: 10,
            fontWeight: 700,
            textTransform: "uppercase",
            letterSpacing: ".7px",
            padding: "2px 8px",
            borderRadius: 20,
            background: cfg.iconBg,
            color: cfg.iconColor,
          }}>
            {t(`alertes.type${cfg.label}`)}
          </span>

          {notif.action && (
            <button
              onClick={e => e.stopPropagation()}
              style={{
                fontSize: 12,
                fontWeight: 600,
                color: "#3b82f6",
                background: "transparent",
                border: "none",
                cursor: "pointer",
                padding: 0,
                display: "flex",
                alignItems: "center",
                gap: 4,
                opacity: hovered ? 1 : 0.7,
              }}
            >
              {notif.action.label}
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/>
              </svg>
            </button>
          )}
        </div>
      </div>

      <button
        onClick={handleDismiss}
        style={{
          background: hovered ? "#f1f5f9" : "transparent",
          border: "none",
          cursor: "pointer",
          width: 28,
          height: 28,
          borderRadius: 8,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          color: "#94a3b8",
          opacity: hovered ? 1 : 0,
          transition: "all .15s",
        }}
        title={t("alertes.supprimer")}
      >
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
          <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
        </svg>
      </button>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════════
   PAGE PRINCIPALE
═══════════════════════════════════════════════════════════════════ */
export default function AlertesPage() {
  const { notifs, markNotifRead, markAllNotifsRead, dismissNotif, clearAllNotifs } = useApp();
  const { t } = useI18n();
  const [filter, setFilter] = useState("toutes");
  const [typeFilter, setTypeFilter] = useState("tous");

  const unread = notifs.filter(a => !a.lu).length;

  const afterLu = filter === "non-lues" ? notifs.filter(a => !a.lu) : notifs;
  const afterType = typeFilter === "tous" ? afterLu : afterLu.filter(a => a.type === typeFilter);
  const groups = groupByDay(afterType);

  const tabFilters = [
    { key: "toutes", label: t("alertes.toutes"), count: notifs.length },
    { key: "non-lues", label: t("alertes.nonLues"), count: unread },
  ];

  const typeFilters = [
    { key: "tous", label: t("alertes.typeTout") },
    { key: "candidature", label: t("alertes.typeCandidatures") },
    { key: "entretien", label: t("alertes.typeEntretiens") },
    { key: "offre", label: t("alertes.typeOffres") },
    { key: "validation", label: t("alertes.typeValidations") },
    { key: "messagerie", label: t("alertes.typeMessagerie") },
    { key: "systeme", label: t("alertes.typeSysteme") },
  ];

  return (
    <div style={{ padding: "36px 24px 60px", maxWidth: 720, margin: "0 auto" }}>
      <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: 28 }}>
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 4 }}>
            <h2 style={{ fontSize: 26, fontWeight: 800, color: "#0f172a", margin: 0 }}>
              {t("alertes.titre")}
            </h2>
            {unread > 0 && (
              <span style={{
                background: "#3b82f6",
                color: "white",
                fontSize: 12,
                fontWeight: 700,
                padding: "2px 9px",
                borderRadius: 20,
              }}>
                {unread} {t("alertes.nouvelle", { count: unread })}
              </span>
            )}
          </div>
          <p style={{ color: "#94a3b8", fontSize: 13, margin: 0 }}>
            {unread > 0
              ? t("alertes.descriptionNonLues", { count: unread })
              : notifs.length === 0
                ? t("alertes.aucuneActivite")
                : t("alertes.toutEstAJour")}
          </p>
        </div>

        <div style={{ display: "flex", gap: 8 }}>
          {unread > 0 && (
            <button
              onClick={markAllNotifsRead}
              style={{
                fontSize: 12,
                fontWeight: 600,
                color: "#3b82f6",
                background: "#eff6ff",
                border: "1px solid #bfdbfe",
                borderRadius: 8,
                padding: "7px 14px",
                cursor: "pointer",
              }}
            >
              {t("alertes.toutLire")}
            </button>
          )}
          {notifs.length > 0 && (
            <button
              onClick={clearAllNotifs}
              style={{
                fontSize: 12,
                fontWeight: 600,
                color: "#94a3b8",
                background: "transparent",
                border: "1px solid #e2e8f0",
                borderRadius: 8,
                padding: "7px 14px",
                cursor: "pointer",
              }}
            >
              {t("alertes.toutEffacer")}
            </button>
          )}
        </div>
      </div>

      <div style={{
        display: "flex",
        gap: 4,
        marginBottom: 16,
        background: "#f1f5f9",
        borderRadius: 10,
        padding: 4,
        width: "fit-content",
      }}>
        {tabFilters.map(f => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            style={{
              padding: "6px 18px",
              borderRadius: 8,
              fontSize: 13,
              fontWeight: 600,
              border: "none",
              cursor: "pointer",
              background: filter === f.key ? "white" : "transparent",
              color: filter === f.key ? "#0f172a" : "#64748b",
              boxShadow: filter === f.key ? "0 1px 4px rgba(0,0,0,0.10)" : "none",
            }}
          >
            {f.label}
            {f.count > 0 && (
              <span style={{
                marginLeft: 6,
                fontSize: 11,
                background: filter === f.key ? "#3b82f6" : "#cbd5e1",
                color: filter === f.key ? "white" : "#64748b",
                padding: "1px 6px",
                borderRadius: 10,
                fontWeight: 700,
              }}>
                {f.count}
              </span>
            )}
          </button>
        ))}
      </div>

      <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 28 }}>
        {typeFilters.map(f => {
          const cfg = f.key !== "tous" ? TYPE_CONFIG[f.key] : null;
          const active = typeFilter === f.key;
          const IconComp = cfg?.icon;
          return (
            <button
              key={f.key}
              onClick={() => setTypeFilter(f.key)}
              style={{
                padding: "5px 14px",
                borderRadius: 20,
                fontSize: 12,
                fontWeight: 600,
                border: `1px solid ${active ? (cfg?.iconColor || "#3b82f6") : "#e2e8f0"}`,
                background: active ? (cfg?.iconBg || "#eff6ff") : "white",
                color: active ? (cfg?.iconColor || "#3b82f6") : "#64748b",
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                gap: 5,
              }}
            >
              {cfg && IconComp && <IconComp />}
              {f.label}
            </button>
          );
        })}
      </div>

      {Object.keys(groups).length === 0 ? (
        <div style={{
          textAlign: "center",
          padding: "72px 0",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: 12,
        }}>
          <div style={{
            width: 56,
            height: 56,
            borderRadius: "50%",
            background: "#f1f5f9",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#94a3b8" strokeWidth="1.8">
              <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
              <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
            </svg>
          </div>
          <p style={{ color: "#94a3b8", fontSize: 14, margin: 0, fontWeight: 500 }}>
            {notifs.length === 0 ? t("alertes.aucuneNotification") : t("alertes.aucuneDansFiltre")}
          </p>
        </div>
      ) : (
        Object.entries(groups).map(([day, notifList]) => (
          <div key={day} style={{ marginBottom: 28 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 12 }}>
              <span style={{ fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: "1px", color: "#94a3b8" }}>
                {day}
              </span>
              <div style={{ flex: 1, height: 1, background: "#f1f5f9" }} />
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {notifList.map(n => (
                <NotifCard
                  key={n.id}
                  notif={n}
                  onDismiss={dismissNotif}
                  onRead={markNotifRead}
                />
              ))}
            </div>
          </div>
        ))
      )}
    </div>
  );
}