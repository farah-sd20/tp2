import Navbar   from "../components/navbar.jsx";
import Button   from "../components/button.jsx";
import { useApp } from "../context/appcontext.jsx";

export default function PendingPage() {
  const { navigate } = useApp();

  return (
    <div style={{ minHeight:"100vh", display:"flex", flexDirection:"column", background:"var(--warm)" }}>
      <Navbar showActions={false} />

      <div style={{ flex:1, display:"flex", alignItems:"center", justifyContent:"center", padding:"40px 20px" }}>
        <div className="fade-up" style={{
          textAlign: "center",
          background: "var(--white)", borderRadius: 22,
          padding: "60px 48px", maxWidth: 450,
          boxShadow: "var(--shadow-lg)", border: "1px solid var(--border)",
        }}>
          {/* Icon */}
          <div style={{
            width: 80, height: 80, borderRadius: "50%",
            background: "var(--blue-light)",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 36, margin: "0 auto 22px",
          }}>
            ⏳
          </div>

          <h2 style={{
            fontFamily: "var(--font-serif)", fontSize: 26,
            fontWeight: 800, color: "var(--dark)", marginBottom: 14,
          }}>
            Demande envoyée !
          </h2>

          <p style={{ fontSize: 14, color: "var(--muted)", lineHeight: 1.7, marginBottom: 8 }}>
            Votre demande a bien été reçue. L'administrateur va examiner votre
            dossier et vous notifier par email.
          </p>

          <p style={{ fontSize: 12, color: "#C0BAB2", marginBottom: 32 }}>
            Délai habituel : 24 à 48 heures ouvrables.
          </p>

          <Button variant="outline" onClick={() => navigate("home")}>
            ← Retour à l'accueil
          </Button>
        </div>
      </div>
    </div>
  );
}
