import { useState } from "react";
import Navbar from "../components/navbar.jsx";
import Button from "../components/button.jsx";
import FeatureCard from "../components/featurecard.jsx";
import { useApp } from "../context/appcontext.jsx";
import { useI18n } from "../i18n/i18nContext.jsx";
// ❌ PAS d'import useNavigate from react-router-dom

function ChevronRight({ color = "currentColor" }) {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
         stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="9 18 15 12 9 6"/>
    </svg>
  );
}

function RoleModal({ onClose, onSelect }) {
  const { t } = useI18n();
  return (
    <div onClick={onClose} style={{
      position: "fixed", inset: 0, zIndex: 999,
      background: "rgba(0,0,0,0.45)",
      display: "flex", alignItems: "center", justifyContent: "center",
      padding: "20px",
    }}>
      <div onClick={e => e.stopPropagation()} className="fade-up" style={{
        background: "var(--white)", borderRadius: 22,
        padding: "36px 40px", width: "100%", maxWidth: 400,
        boxShadow: "var(--shadow-lg)", border: "1px solid var(--border)",
        textAlign: "center",
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 6, justifyContent: "center" }}>
          <div style={{ width: 4, height: 30, background: "var(--blue)", borderRadius: 2 }} />
          <h2 style={{ fontFamily: "var(--font-serif)", fontSize: 22, fontWeight: 800, color: "var(--dark)", margin: 0 }}>
            {t("home.accederDeliJob")}
          </h2>
        </div>
        <p style={{ fontSize: 13, color: "var(--muted)", marginBottom: 28, marginTop: 6 }}>
          {t("home.selectionnerConnexion")}
        </p>

        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          {/* ── Recruteur ── */}
          <button
            onClick={() => onSelect("recruteur")}
            style={{
              padding: "15px 18px", borderRadius: 14,
              border: "1px solid var(--border)", background: "white",
              cursor: "pointer", textAlign: "left",
              display: "flex", alignItems: "center", gap: 14,
              transition: "border-color .15s, box-shadow .15s",
            }}
            onMouseEnter={e => {
              e.currentTarget.style.borderColor = "var(--blue)";
              e.currentTarget.style.boxShadow = "0 0 0 3px rgba(0,61,165,0.08)";
            }}
            onMouseLeave={e => {
              e.currentTarget.style.borderColor = "var(--border)";
              e.currentTarget.style.boxShadow = "none";
            }}
          >
            <div style={{
              width: 44, height: 44, borderRadius: "50%",
              background: "var(--blue-light)",
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 20, flexShrink: 0,
            }}>👤</div>
            <div style={{ flex: 1, textAlign: "left" }}>
              <div style={{ fontSize: 14, fontWeight: 700, color: "var(--dark)", marginBottom: 2 }}>
                {t("connexionRecruteur")}
              </div>
              <div style={{ fontSize: 12, color: "var(--muted)" }}>
                {t("espaceRecruteur")}
              </div>
            </div>
            <ChevronRight color="var(--blue)" />
          </button>

          {/* ── Admin ── */}
          <button
            onClick={() => onSelect("admin")}
            style={{
              padding: "15px 18px", borderRadius: 14,
              border: "1px solid var(--border)", background: "white",
              cursor: "pointer", textAlign: "left",
              display: "flex", alignItems: "center", gap: 14,
              transition: "border-color .15s, box-shadow .15s",
            }}
            onMouseEnter={e => {
              e.currentTarget.style.borderColor = "#E6A817";
              e.currentTarget.style.boxShadow = "0 0 0 3px rgba(230,168,23,0.1)";
            }}
            onMouseLeave={e => {
              e.currentTarget.style.borderColor = "var(--border)";
              e.currentTarget.style.boxShadow = "none";
            }}
          >
            <div style={{
              width: 44, height: 44, borderRadius: "50%",
              background: "#FFF3CD",
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 20, flexShrink: 0,
            }}>🛡️</div>
            <div style={{ flex: 1, textAlign: "left" }}>
              <div style={{ fontSize: 14, fontWeight: 700, color: "var(--dark)", marginBottom: 2 }}>
                {t("home.connexionAdmin")}
              </div>
              <div style={{ fontSize: 12, color: "var(--muted)" }}>
                {t("home.gererPlateforme")}
              </div>
            </div>
            <ChevronRight color="#856404" />
          </button>
        </div>

        <button onClick={onClose} style={{
          marginTop: 20, background: "none", border: "none",
          fontSize: 12, color: "var(--muted)", cursor: "pointer",
        }}>
          {t("home.annuler")}
        </button>
      </div>
    </div>
  );
}

export default function HomePage() {
  const { navigate } = useApp(); // ✅ navigate depuis appcontext
  const [showModal, setShowModal] = useState(false);
  const { t } = useI18n();

  const FEATURES = [
    { icon: "📋", title: t("home.feature1Titre"), desc: t("home.feature1Desc"), delay: "0s" },
    { icon: "✅", title: t("home.feature2Titre"), desc: t("home.feature2Desc"), delay: "0.3s" },
    { icon: "🎯", title: t("home.feature3Titre"), desc: t("home.feature3Desc"), delay: "0.6s" },
  ];

  function handleRoleSelect(role) {
    setShowModal(false);
    localStorage.setItem("loginRole", role);
    navigate("login"); // ✅ fonctionne
  }

  return (
    <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column" }}>
      <Navbar />

      {showModal && (
        <RoleModal
          onClose={() => setShowModal(false)}
          onSelect={handleRoleSelect}
        />
      )}

      <main style={{
        flex: 1,
        display: "flex", flexDirection: "column", alignItems: "center",
        padding: "64px 24px 56px",
        textAlign: "center",
        background: "linear-gradient(180deg, #FFFFFF 0%, #EEF3FC 100%)",
      }}>
        {/* Badge */}
        <div className="fade-up" style={{
          display: "inline-flex", alignItems: "center", gap: 8,
          background: "var(--blue-light)",
          border: "1px solid rgba(0,61,165,0.2)",
          color: "var(--blue)",
          padding: "6px 16px", borderRadius: 100,
          fontSize: 12, fontWeight: 600, letterSpacing: "0.3px",
          marginBottom: 28,
        }}>
          📋 {t("home.badge")}
        </div>

        {/* Title */}
        <h1 className="fade-up-2" style={{
          fontFamily: "var(--font-serif)",
          fontSize: "clamp(32px, 6vw, 56px)",
          fontWeight: 800, lineHeight: 1.12,
          color: "var(--dark)", marginBottom: 18, maxWidth: 600,
        }}>
          {t("home.titre1")}<br />
          <span style={{ color: "var(--blue)", position: "relative", display: "inline-block" }}>
            {t("home.titre2")}
            <svg style={{ position: "absolute", bottom: -6, left: 0, width: "100%" }}
                 height="6" viewBox="0 0 200 6" preserveAspectRatio="none">
              <path d="M0 5 Q50 0 100 3 Q150 6 200 2"
                    stroke="var(--red)" strokeWidth="2.5"
                    fill="none" strokeLinecap="round"/>
            </svg>
          </span>
        </h1>

        {/* Description */}
        <p className="fade-up-3" style={{
          fontSize: 16, color: "var(--mid)", lineHeight: 1.7,
          maxWidth: 520, marginBottom: 40, fontWeight: 300,
        }}>
          {t("home.description")}
        </p>

        {/* CTA */}
        <div className="fade-up-3" style={{
          display: "flex", gap: 14, flexWrap: "wrap",
          justifyContent: "center", marginBottom: 64,
        }}>
          <Button variant="primary" size="lg" onClick={() => navigate("register")}>
            ✦ {t("home.creerCompte")}
          </Button>
          <Button variant="secondary" size="lg" onClick={() => setShowModal(true)}>
            {t("home.seConnecter")} →
          </Button>
        </div>

        {/* Feature cards */}
        <div style={{
          display: "flex", gap: 16,
          flexWrap: "wrap", justifyContent: "center",
          width: "100%", maxWidth: 760,
        }}>
          {FEATURES.map((f, i) => (
            <FeatureCard key={i} {...f} animDelay={f.delay} />
          ))}
        </div>
      </main>

      <footer style={{
        background: "var(--blue)", color: "rgba(255,255,255,0.6)",
        textAlign: "center", padding: "15px",
        fontSize: 12, letterSpacing: "0.3px",
      }}>
        © 2026 <strong style={{ color: "white" }}>DeliJob</strong> — Délice Danone
      </footer>
    </div>
  );
}