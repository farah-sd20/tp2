import { useApp } from "../context/appcontext.jsx";
import { useI18n } from "../i18n/i18nContext.jsx";
import PageHeader from "../components/pageheader.jsx";

function KpiCard({ icon, label, value, color, bg }) {
  return (
    <div style={{
      background:"var(--white)", borderRadius:14,
      padding:"22px 24px",
      border:"1px solid var(--border)",
      boxShadow:"var(--shadow-sm)",
      display:"flex", alignItems:"center", gap:16,
    }}>
      <div style={{
        width:52, height:52, borderRadius:13,
        background:bg,
        display:"flex", alignItems:"center", justifyContent:"center",
        fontSize:24, flexShrink:0,
      }}>{icon}</div>
      <div>
        <div style={{ fontSize:28, fontWeight:800, fontFamily:"var(--font-serif)", color, lineHeight:1 }}>{value}</div>
        <div style={{ fontSize:12, color:"var(--muted)", marginTop:4, fontWeight:500 }}>{label}</div>
      </div>
    </div>
  );
}

function FunnelStep({ label, count, max, barColor }) {
  const pct = max > 0 ? Math.round((count / max) * 100) : 0;
  return (
    <div style={{ display:"flex", alignItems:"center", gap:10 }}>
      <span style={{ fontSize:12, color:"var(--muted)", width:150, flexShrink:0 }}>{label}</span>
      <div style={{ flex:1, background:"#F1F5F9", borderRadius:99, height:20, overflow:"hidden" }}>
        <div style={{
          width:`${pct}%`, height:"100%", borderRadius:99,
          background:barColor, minWidth: count > 0 ? 28 : 0,
          display:"flex", alignItems:"center", paddingLeft:8,
          fontSize:11, fontWeight:700, color:"#fff",
          transition:"width .5s ease",
        }}>{count > 0 ? count : ""}</div>
      </div>
      <span style={{ fontSize:11, color:"var(--muted)", width:34, textAlign:"right" }}>{pct}%</span>
    </div>
  );
}

export default function DashboardHome() {
  const { offers, currentUser } = useApp();
  const { t } = useI18n();

  // ── KPIs : toutes les offres + toutes les candidatures ───────────────────
  const totalOffres    = offers.length;
  const totalCandidats = offers.reduce((s, o) => s + (o.candidats || 0), 0);

  // ── Pipeline : offres publiées uniquement ────────────────────────────────
  const offresPubliees         = offers.filter(o => o.statut === "Ouvert");
  const totalCandidatsPubliees = offresPubliees.reduce((s, o) => s + (o.candidats || 0), 0);

  // funnelMax = la valeur la plus grande pour éviter NaN et avoir des barres cohérentes
const funnelMax = offresPubliees.length > 0 ? offresPubliees.length : 1;

  const funnelSteps = [
    { label: "Offres publiées",     count: offresPubliees.length,  barColor: "#3B82F6" },
    { label: "Candidatures reçues", count: totalCandidatsPubliees, barColor: "#10B981" },
  ];

  return (
    <div>
      <PageHeader
        title={`${t("dashboard.bienvenue")}, ${currentUser?.prenom} 👋`}
        subtitle={t("dashboard.subtitle")}
      />

      {/* KPIs */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(2,1fr)", gap:16, marginBottom:28 }}>
        <KpiCard icon="📋" label={t("dashboard.totalOffres")}  value={totalOffres}    color="var(--blue)" bg="var(--blue-light)" />
        <KpiCard icon="👤" label={t("dashboard.candidatures")} value={totalCandidats} color="#7C3AED"      bg="#F3F0FF"           />
      </div>

      {/* Pipeline */}
      <div style={{
        background:"var(--white)", borderRadius:14,
        border:"1px solid var(--border)", boxShadow:"var(--shadow-sm)",
        padding:"20px 24px", marginBottom:28,
      }}>
        <div style={{ marginBottom:16 }}>
          <h3 style={{ margin:0, fontSize:11, fontWeight:700, color:"var(--muted)", textTransform:"uppercase", letterSpacing:"0.06em" }}>
            Pipeline 
          </h3>
        </div>
        <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
          {funnelSteps.map(s => (
            <FunnelStep key={s.label} {...s} max={funnelMax} />
          ))}
        </div>
      </div>
    </div>
  );
}