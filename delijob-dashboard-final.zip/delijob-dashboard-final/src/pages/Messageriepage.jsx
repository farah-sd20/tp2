import { useState, useEffect, useRef, useCallback } from "react";
import PageHeader from "../components/pageheader.jsx";
import { useApp } from "../context/appcontext.jsx";
import { useI18n } from "../i18n/i18nContext.jsx";

const API_BASE = "http://localhost:8080";

function authHeaders() {
  const token = localStorage.getItem("token");
  return {
    "Content-Type": "application/json",
    "Cache-Control": "no-cache",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
}

function formatTime(date) {
  return new Date(date).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });
}

function formatDate(date) {
  const today = new Date();
  const d = new Date(date);
  if (d.toDateString() === today.toDateString()) return "Aujourd'hui";
  const yesterday = new Date(today);
  yesterday.setDate(yesterday.getDate() - 1);
  if (d.toDateString() === yesterday.toDateString()) return "Hier";
  return d.toLocaleDateString("fr-FR", { day: "numeric", month: "long" });
}

function groupByDate(messages) {
  const groups = [];
  let lastDate = null;
  for (const msg of messages) {
    const d = formatDate(msg.createdAt || msg.time);
    if (d !== lastDate) {
      groups.push({ type: "date", label: d, key: "date-" + d + Math.random() });
      lastDate = d;
    }
    groups.push({ type: "msg", ...msg });
  }
  return groups;
}

function Avatar({ initials, size = 38, bg = "#003DA5" }) {
  return (
    <div style={{
      width: size, height: size, borderRadius: "50%",
      background: `linear-gradient(135deg, ${bg} 0%, #1a56db 100%)`,
      display: "flex", alignItems: "center", justifyContent: "center",
      fontWeight: 700, fontSize: size * 0.35, color: "white",
      flexShrink: 0, boxShadow: `0 2px 8px ${bg}44`,
    }}>{initials}</div>
  );
}

// ─── Message action menu ─────────────────────────────────────────────────────
function MessageActions({ onEdit, onDelete }) {
  const [open, setOpen] = useState(false);
  const menuRef = useRef(null);

  useEffect(() => {
    if (!open) return;
    function handleClick(e) {
      if (menuRef.current && !menuRef.current.contains(e.target)) setOpen(false);
    }
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, [open]);

  return (
    <div ref={menuRef} style={{ position: "relative" }}>
      <button
        onClick={() => setOpen(o => !o)}
        title="Options"
        style={{
          background: open ? "#E8EEFF" : "rgba(255,255,255,0.85)",
          border: "1px solid #E2E8F0",
          borderRadius: 8,
          cursor: "pointer",
          width: 26, height: 26,
          display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: 15, color: "#64748B",
          transition: "all .15s",
          flexShrink: 0,
        }}
        onMouseEnter={e => { if (!open) e.currentTarget.style.background = "#F0F4FF"; e.currentTarget.style.borderColor = "#003DA5"; }}
        onMouseLeave={e => { if (!open) e.currentTarget.style.background = "rgba(255,255,255,0.85)"; e.currentTarget.style.borderColor = "#E2E8F0"; }}
      >
        ···
      </button>
      {open && (
        <div style={{
          position: "absolute", bottom: "calc(100% + 6px)", right: 0,
          background: "white", border: "1px solid #E8EEFF",
          borderRadius: 10, boxShadow: "0 8px 24px rgba(0,61,165,0.12)",
          minWidth: 130, zIndex: 100, overflow: "hidden",
          animation: "fadeUp .12s ease",
        }}>
          <button
            onClick={() => { setOpen(false); onEdit(); }}
            style={{
              width: "100%", padding: "9px 14px", border: "none",
              background: "none", textAlign: "left", fontSize: 13,
              color: "#0F172A", cursor: "pointer", display: "flex",
              alignItems: "center", gap: 8, fontFamily: "var(--font-sans)",
            }}
            onMouseEnter={e => e.currentTarget.style.background = "#F0F4FF"}
            onMouseLeave={e => e.currentTarget.style.background = "none"}
          >
            ✏️ Modifier
          </button>
          <div style={{ height: 1, background: "#F1F5F9" }} />
          <button
            onClick={() => { setOpen(false); onDelete(); }}
            style={{
              width: "100%", padding: "9px 14px", border: "none",
              background: "none", textAlign: "left", fontSize: 13,
              color: "#DC2626", cursor: "pointer", display: "flex",
              alignItems: "center", gap: 8, fontFamily: "var(--font-sans)",
            }}
            onMouseEnter={e => e.currentTarget.style.background = "#FEF2F2"}
            onMouseLeave={e => e.currentTarget.style.background = "none"}
          >
            🗑️ Supprimer
          </button>
        </div>
      )}
    </div>
  );
}

// ─── Delete confirmation toast ────────────────────────────────────────────────
function DeleteConfirm({ onConfirm, onCancel }) {
  return (
    <div style={{
      position: "absolute", bottom: "calc(100% + 8px)", right: 0,
      background: "white", border: "1px solid #FEE2E2",
      borderRadius: 10, boxShadow: "0 8px 24px rgba(220,38,38,0.10)",
      padding: "10px 14px", zIndex: 100, minWidth: 200,
      animation: "fadeUp .12s ease",
    }}>
      <p style={{ margin: "0 0 8px", fontSize: 12, color: "#64748B", lineHeight: 1.5 }}>
        Supprimer ce message ?
      </p>
      <div style={{ display: "flex", gap: 6 }}>
        <button
          onClick={onConfirm}
          style={{
            flex: 1, padding: "5px 0", borderRadius: 7, border: "none",
            background: "#DC2626", color: "white", fontSize: 12,
            fontWeight: 700, cursor: "pointer",
          }}
        >Supprimer</button>
        <button
          onClick={onCancel}
          style={{
            flex: 1, padding: "5px 0", borderRadius: 7,
            border: "1px solid #E2E8F0", background: "white",
            fontSize: 12, color: "#64748B", cursor: "pointer",
          }}
        >Annuler</button>
      </div>
    </div>
  );
}

export default function MessageriePage({ recruiterId: propRecruiterId }) {
  const { currentUser } = useApp();
  const { t } = useI18n();
  const [messages, setMessages] = useState([]);
  const [inputText, setInputText] = useState("");
  const [sending, setSending] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [authError, setAuthError] = useState(false);
  const [lastMessageId, setLastMessageId] = useState(null);

  // ─── Edit / delete state ──────────────────────────────────────────────────
  const [editingId, setEditingId] = useState(null);
  const [editText, setEditText] = useState("");
  const [deletingId, setDeletingId] = useState(null);
  const [hoveredId, setHoveredId] = useState(null);

  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);
  const editInputRef = useRef(null);
  const pollRef = useRef(null);
  const lastCountRef = useRef(0);

  const isAdmin = currentUser?.role === "ADMIN";
  const isRecruteur = currentUser?.role === "RECRUTEUR";

  const resolvedRecruiterId =
    propRecruiterId ||
    new URLSearchParams(window.location.search).get("recruiterId") ||
    null;

  function getMessagesUrl() {
    if (isAdmin) {
      if (!resolvedRecruiterId) return null;
      return `${API_BASE}/api/admin/messages/${resolvedRecruiterId}`;
    }
    return `${API_BASE}/api/messages`;
  }

  function getSendUrl() {
    if (isAdmin) {
      if (!resolvedRecruiterId) return null;
      return `${API_BASE}/api/admin/messages/${resolvedRecruiterId}`;
    }
    return `${API_BASE}/api/messages`;
  }

  // ─── Auth check ──────────────────────────────────────────────────────────
  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token || !currentUser) { setAuthError(true); setError(t("messagerie.sessionExpiree")); return; }
    if (!isAdmin && !isRecruteur) { setError(t("messagerie.accesNonAutorise").replace("{role}", currentUser?.role || "inconnu")); return; }
    if (isAdmin && !resolvedRecruiterId) { setError(t("messagerie.aucunRecruteur")); return; }
    setAuthError(false); setError(null);
  }, [currentUser, resolvedRecruiterId, isAdmin, isRecruteur, t]);

  const recruiterInitials = ((currentUser?.prenom?.[0] || "?") + (currentUser?.nom?.[0] || "?")).toUpperCase();

  // ─── Fetch messages ───────────────────────────────────────────────────────
  const fetchMessages = useCallback(async (silent = false) => {
    const token = localStorage.getItem("token");
    if (!token) { if (!silent) { setError(t("messagerie.sessionExpiree")); setAuthError(true); } return; }
    const url = getMessagesUrl();
    if (!url) return;
    if (!silent) setLoading(true);
    try {
      const res = await fetch(url, { headers: authHeaders(), cache: "no-cache" });
      if (res.status === 401) { localStorage.removeItem("token"); localStorage.removeItem("user"); setAuthError(true); setError(t("messagerie.sessionExpiree")); setTimeout(() => { window.location.href = "/login"; }, 2000); return; }
      if (res.status === 403) { const d = await res.json().catch(() => ({})); setError(d.error || t("messagerie.accesInterdit")); return; }
      if (!res.ok) throw new Error(t("messagerie.erreurHttp").replace("{status}", res.status));
      const data = await res.json();
      const msgs = Array.isArray(data) ? data : (data.messages || []);
      const sortedMsgs = [...msgs].sort((a, b) => new Date(a.createdAt || a.time) - new Date(b.createdAt || b.time));
      const latestMessage = sortedMsgs[sortedMsgs.length - 1];
      const hasNewMessages = lastMessageId !== latestMessage?.id;
      setMessages(prev => {
        if (sortedMsgs.length === prev.length && !hasNewMessages) return prev;
        if (sortedMsgs.length > lastCountRef.current || hasNewMessages) setTimeout(() => messagesEndRef.current?.scrollIntoView({ behavior: "smooth" }), 80);
        lastCountRef.current = sortedMsgs.length;
        if (latestMessage) setLastMessageId(latestMessage.id);
        return sortedMsgs;
      });
      setError(null);
    } catch (e) { if (!silent) setError(t("messagerie.erreurChargement")); }
    finally { if (!silent) setLoading(false); }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lastMessageId, resolvedRecruiterId, isAdmin, t]);

  useEffect(() => { const h = () => fetchMessages(false); window.addEventListener("focus", h); return () => window.removeEventListener("focus", h); }, [fetchMessages]);
  useEffect(() => { const h = () => { if (document.visibilityState === "visible") fetchMessages(false); }; document.addEventListener("visibilitychange", h); return () => document.removeEventListener("visibilitychange", h); }, [fetchMessages]);

  useEffect(() => {
    if (!authError && (isAdmin || isRecruteur) && getMessagesUrl()) { fetchMessages(false); inputRef.current?.focus(); }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fetchMessages, authError, isAdmin, isRecruteur]);

  useEffect(() => {
    if (!authError && (isAdmin || isRecruteur) && getMessagesUrl()) {
      pollRef.current = setInterval(() => fetchMessages(true), 3000);
      return () => { if (pollRef.current) clearInterval(pollRef.current); };
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fetchMessages, authError, isAdmin, isRecruteur]);

  useEffect(() => { messagesEndRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  // Focus edit input when editing starts
  useEffect(() => {
    if (editingId && editInputRef.current) editInputRef.current.focus();
  }, [editingId]);

  // ─── Send message ─────────────────────────────────────────────────────────
  async function sendMessage() {
    if (!inputText.trim() || sending) return;
    const token = localStorage.getItem("token");
    if (!token) { setError(t("messagerie.sessionExpiree")); return; }
    const sendUrl = getSendUrl();
    if (!sendUrl) { setError(t("messagerie.erreurEnvoiRecruteur")); return; }
    const text = inputText.trim();
    setInputText("");
    setSending(true);
    const tempMsg = { id: "temp-" + Date.now(), senderId: currentUser?.id, senderRole: currentUser?.role, content: text, createdAt: new Date().toISOString(), _pending: true };
    setMessages(prev => [...prev, tempMsg]);
    setTimeout(() => messagesEndRef.current?.scrollIntoView({ behavior: "smooth" }), 50);
    try {
      const res = await fetch(sendUrl, { method: "POST", headers: authHeaders(), body: JSON.stringify({ content: text }) });
      if (res.status === 401) { localStorage.removeItem("token"); setAuthError(true); setError(t("messagerie.sessionExpiree")); setTimeout(() => { window.location.href = "/login"; }, 2000); return; }
      if (res.status === 403) { const d = await res.json().catch(() => ({})); throw new Error(d.error || t("messagerie.accesInterdit")); }
      if (!res.ok) throw new Error(t("messagerie.erreurEnvoi"));
      setTimeout(() => fetchMessages(false), 500);
    } catch (e) {
      setError(e.message || t("messagerie.erreurEnvoi"));
      setMessages(prev => prev.map(m => m.id === tempMsg.id ? { ...m, _failed: true, _pending: false } : m));
    } finally { setSending(false); }
  }

  function handleKeyDown(e) {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); }
  }

  function retryMessage(msg) {
    setMessages(prev => prev.filter(m => m.id !== msg.id));
    setInputText(msg.content);
    inputRef.current?.focus();
  }

  // ─── Edit message ─────────────────────────────────────────────────────────
  function startEdit(msg) {
    setEditingId(msg.id);
    setEditText(msg.content);
    setDeletingId(null);
  }

  async function submitEdit(msgId) {
    const newContent = editText.trim();
    if (!newContent) return;
    const prev = messages.find(m => m.id === msgId)?.content;
    if (newContent === prev) { cancelEdit(); return; }

    // Optimistic update
    setMessages(ms => ms.map(m => m.id === msgId ? { ...m, content: newContent, _edited: true } : m));
    setEditingId(null);

    try {
      const res = await fetch(`${API_BASE}/api/messages/${msgId}`, {
        method: "PUT",
        headers: authHeaders(),
        body: JSON.stringify({ content: newContent }),
      });
      if (!res.ok) throw new Error();
      setTimeout(() => fetchMessages(true), 400);
    } catch {
      // Revert
      setMessages(ms => ms.map(m => m.id === msgId ? { ...m, content: prev, _edited: false } : m));
      setError("Erreur lors de la modification.");
    }
  }

  function cancelEdit() {
    setEditingId(null);
    setEditText("");
  }

  function handleEditKeyDown(e, msgId) {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); submitEdit(msgId); }
    if (e.key === "Escape") cancelEdit();
  }

  // ─── Delete message ───────────────────────────────────────────────────────
  async function confirmDelete(msgId) {
    setDeletingId(null);
    // Optimistic remove
    const backup = messages.find(m => m.id === msgId);
    setMessages(ms => ms.filter(m => m.id !== msgId));

    try {
      const res = await fetch(`${API_BASE}/api/messages/${msgId}`, {
        method: "DELETE",
        headers: authHeaders(),
      });
      if (!res.ok) throw new Error();
    } catch {
      // Revert
      if (backup) setMessages(ms => [...ms, backup].sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt)));
      setError("Erreur lors de la suppression.");
    }
  }

  // ─── Auth error screen ────────────────────────────────────────────────────
  if (authError) {
    return (
      <div style={{ height: "calc(100vh - 64px)", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div style={{ textAlign: "center", maxWidth: 400, padding: 32, background: "white", borderRadius: 16, boxShadow: "0 4px 20px rgba(0,0,0,0.1)" }}>
          <div style={{ fontSize: 48, marginBottom: 16 }}>🔒</div>
          <h2 style={{ marginBottom: 12, color: "#1E293B" }}>{t("messagerie.sessionExpiree")}</h2>
          <p style={{ marginBottom: 24, color: "#64748B" }}>{error || t("messagerie.reconnectez")}</p>
          <button onClick={() => { window.location.href = "/login"; }}
            style={{ padding: "10px 24px", background: "linear-gradient(135deg, #003DA5 0%, #1a56db 100%)", color: "white", border: "none", borderRadius: 8, cursor: "pointer", fontWeight: 600 }}>
            {t("messagerie.seReconnecter")}
          </button>
        </div>
      </div>
    );
  }

  const grouped = groupByDate(messages);

  // ─── Render ───────────────────────────────────────────────────────────────
  return (
    <div style={{ height: "calc(100vh - 64px)", display: "flex", flexDirection: "column" }}>
      <PageHeader
        title={t("messagerie.titre")}
        subtitle={isAdmin ? t("messagerie.administration") : t("messagerie.ecrire")}
      />

      {error && (
        <div style={{ margin: "16px 24px 0", padding: "12px 16px", background: "#FEF2F2", border: "1px solid #FEE2E2", borderRadius: 12, color: "#991B1B", fontSize: 13, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <span>⚠️ {error}</span>
          <button onClick={() => setError(null)} style={{ background: "none", border: "none", color: "#991B1B", cursor: "pointer", fontSize: 18, fontWeight: "bold" }}>×</button>
        </div>
      )}

      <div style={{ flex: 1, display: "flex", flexDirection: "column", background: "white", borderRadius: 16, border: "1px solid #E8EEFF", boxShadow: "0 2px 12px rgba(0,61,165,0.06)", overflow: "hidden", minHeight: 0, margin: 24 }}>

        {/* Header */}
        <div style={{ padding: "14px 24px", borderBottom: "1px solid #EEF2FF", display: "flex", alignItems: "center", gap: 14, background: "white", boxShadow: "0 1px 4px rgba(0,61,165,0.04)" }}>
          <div style={{ position: "relative" }}>
            <Avatar initials={isAdmin ? "R" : "A"} size={44} bg="#003DA5" />
            <span style={{ position: "absolute", bottom: 2, right: 2, width: 11, height: 11, borderRadius: "50%", background: "#22C55E", border: "2px solid white" }} />
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 15, fontWeight: 700, color: "#0F172A" }}>
              {isAdmin ? t("messagerie.conversationRecruteur").replace("{id}", resolvedRecruiterId) : t("messagerie.administrationDeliJob")}
            </div>
            <div style={{ fontSize: 11, color: "#22C55E", fontWeight: 600, marginTop: 1 }}>{t("messagerie.enLigne")}</div>
          </div>
          <button onClick={() => fetchMessages(false)}
            style={{ padding: "6px 12px", borderRadius: 8, border: "1px solid #E2E8F0", background: "white", fontSize: 12, cursor: "pointer", display: "flex", alignItems: "center", gap: 4, color: "#64748B" }}
            onMouseEnter={e => { e.currentTarget.style.background = "#F8FAFF"; e.currentTarget.style.borderColor = "#003DA5"; }}
            onMouseLeave={e => { e.currentTarget.style.background = "white"; e.currentTarget.style.borderColor = "#E2E8F0"; }}>
            🔄 {t("messagerie.rafraichir")}
          </button>
          <div style={{ padding: "5px 14px", borderRadius: 100, background: "#EEF2FF", color: "#3730A3", fontSize: 11, fontWeight: 700, display: "flex", alignItems: "center", gap: 6 }}>
            🔒 {t("messagerie.conversationSecurisee")}
          </div>
        </div>

        {/* Messages */}
        <div style={{ flex: 1, overflowY: "auto", padding: "24px 24px 16px", background: "#F8FAFF", display: "flex", flexDirection: "column", gap: 2 }}>
          {loading && messages.length === 0 ? (
            <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 12, color: "#94A3B8" }}>
              <div style={{ fontSize: 32 }}>⏳</div>
              <div style={{ fontSize: 13 }}>{t("messagerie.chargement")}</div>
            </div>
          ) : messages.length === 0 ? (
            <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 10, color: "#94A3B8" }}>
              <div style={{ fontSize: 48 }}>💬</div>
              <div style={{ fontSize: 15, fontWeight: 600, color: "#64748B" }}>{t("messagerie.demarrerConversation")}</div>
              <div style={{ fontSize: 12, textAlign: "center", maxWidth: 280, lineHeight: 1.6 }}>
                {isAdmin ? t("messagerie.repondreRecruteur") : t("messagerie.posezQuestions")}
              </div>
              {!isAdmin && (
                <div style={{ display: "flex", flexDirection: "column", gap: 8, marginTop: 8, width: "100%", maxWidth: 320 }}>
                  {[t("messagerie.suggestion1"), t("messagerie.suggestion2"), t("messagerie.suggestion3")].map(prompt => (
                    <button key={prompt} onClick={() => { setInputText(prompt); inputRef.current?.focus(); }}
                      style={{ padding: "9px 16px", borderRadius: 10, border: "1.5px solid #E2E8F0", background: "white", color: "#64748B", fontSize: 12, cursor: "pointer", textAlign: "left", transition: "all .15s", fontFamily: "var(--font-sans)" }}
                      onMouseEnter={e => { e.currentTarget.style.borderColor = "#003DA5"; e.currentTarget.style.color = "#003DA5"; e.currentTarget.style.background = "#F0F4FF"; }}
                      onMouseLeave={e => { e.currentTarget.style.borderColor = "#E2E8F0"; e.currentTarget.style.color = "#64748B"; e.currentTarget.style.background = "white"; }}>
                      💬 {prompt}
                    </button>
                  ))}
                </div>
              )}
            </div>
          ) : grouped.map((item, idx) => {
            if (item.type === "date") return (
              <div key={item.key} style={{ display: "flex", alignItems: "center", gap: 12, margin: "16px 0 8px" }}>
                <div style={{ flex: 1, height: 1, background: "#E2E8F0" }} />
                <span style={{ fontSize: 11, color: "#94A3B8", fontWeight: 600, padding: "3px 12px", background: "#F1F5F9", borderRadius: 100, whiteSpace: "nowrap" }}>{item.label}</span>
                <div style={{ flex: 1, height: 1, background: "#E2E8F0" }} />
              </div>
            );

            const isMe = isAdmin ? item.senderRole === "ADMIN" : item.senderRole === "RECRUTEUR";
            const isPending = item._pending;
            const isFailed = item._failed;
            const isEditing = editingId === item.id;
            const isConfirmingDelete = deletingId === item.id;
            const isHovered = hoveredId === item.id;

            // Only RECRUTEUR can edit/delete their own messages (not admin, not pending/failed)
            const canModify = isRecruteur && isMe && !isPending && !isFailed && !String(item.id ?? "").startsWith("temp-");

            return (
              <div
                key={item.id || idx}
                style={{ display: "flex", justifyContent: isMe ? "flex-end" : "flex-start", marginBottom: 4, alignItems: "flex-end", gap: 8 }}
                onMouseEnter={() => setHoveredId(item.id)}
                onMouseLeave={() => { if (!isConfirmingDelete) setHoveredId(null); }}
              >
                {!isMe && <Avatar initials={isAdmin ? "R" : "A"} size={30} bg="#003DA5" />}

                <div style={{ maxWidth: "62%", display: "flex", flexDirection: "column", alignItems: isMe ? "flex-end" : "flex-start" }}>
                  {!isMe && (
                    <span style={{ fontSize: 10, color: "#94A3B8", fontWeight: 600, marginBottom: 3, paddingLeft: 4 }}>
                      {isAdmin ? t("messagerie.recruteur") : t("messagerie.administration")}
                    </span>
                  )}

                  {/* Actions button + confirm delete — shown on hover, right of bubble */}
                  <div style={{ display: "flex", alignItems: "flex-end", gap: 6, flexDirection: isMe ? "row-reverse" : "row" }}>

                    {/* Message bubble or edit textarea */}
                    <div style={{ position: "relative" }}>
                      {isEditing ? (
                        /* ── Inline edit ── */
                        <div style={{ display: "flex", flexDirection: "column", gap: 6, minWidth: 220 }}>
                          <textarea
                            ref={editInputRef}
                            value={editText}
                            onChange={e => setEditText(e.target.value)}
                            onKeyDown={e => handleEditKeyDown(e, item.id)}
                            rows={2}
                            style={{
                              padding: "9px 12px", borderRadius: 12, border: "2px solid #003DA5",
                              fontSize: 13, lineHeight: 1.55, fontFamily: "var(--font-sans)",
                              outline: "none", resize: "none", maxHeight: 120, overflowY: "auto",
                              background: "white", color: "#0F172A", boxShadow: "0 0 0 4px rgba(0,61,165,0.08)",
                            }}
                            onInput={e => { e.target.style.height = "auto"; e.target.style.height = Math.min(e.target.scrollHeight, 120) + "px"; }}
                          />
                          <div style={{ display: "flex", gap: 6, justifyContent: "flex-end" }}>
                            <button onClick={cancelEdit}
                              style={{ padding: "4px 12px", borderRadius: 7, border: "1px solid #E2E8F0", background: "white", fontSize: 11, color: "#64748B", cursor: "pointer", fontWeight: 600 }}>
                              Annuler
                            </button>
                            <button onClick={() => submitEdit(item.id)}
                              style={{ padding: "4px 12px", borderRadius: 7, border: "none", background: "linear-gradient(135deg, #003DA5 0%, #1a56db 100%)", fontSize: 11, color: "white", cursor: "pointer", fontWeight: 700 }}>
                              Enregistrer ↵
                            </button>
                          </div>
                        </div>
                      ) : (
                        /* ── Normal bubble ── */
                        <div style={{
                          padding: "10px 14px",
                          borderRadius: isMe ? "16px 16px 4px 16px" : "16px 16px 16px 4px",
                          background: isMe
                            ? (isFailed ? "#FEF2F2" : isPending ? "linear-gradient(135deg, #4B70C0 0%, #6B88D4 100%)" : "linear-gradient(135deg, #003DA5 0%, #1a56db 100%)")
                            : "white",
                          color: isMe ? (isFailed ? "#991B1B" : "white") : "#0F172A",
                          fontSize: 13, lineHeight: 1.55,
                          boxShadow: isMe
                            ? (isFailed ? "0 2px 8px rgba(239,68,68,0.2)" : "0 2px 10px rgba(0,61,165,0.25)")
                            : "0 1px 4px rgba(0,0,0,0.08)",
                          border: isMe ? "none" : "1px solid #E8EEFF",
                          opacity: isPending ? 0.8 : 1,
                          transition: "opacity .3s",
                        }}>
                          {item.content}
                          {item._edited && !isPending && (
                            <span style={{ fontSize: 10, opacity: 0.65, marginLeft: 6, fontStyle: "italic" }}>modifié</span>
                          )}
                        </div>
                      )}

                      {/* Delete confirm popover */}
                      {isConfirmingDelete && (
                        <DeleteConfirm
                          onConfirm={() => confirmDelete(item.id)}
                          onCancel={() => { setDeletingId(null); setHoveredId(null); }}
                        />
                      )}
                    </div>

                    {/* Action menu — only for RECRUTEUR own messages, visible on hover */}
                    {canModify && !isEditing && (isHovered || isConfirmingDelete) && (
                      <MessageActions
                        onEdit={() => startEdit(item)}
                        onDelete={() => setDeletingId(item.id)}
                      />
                    )}
                  </div>

                  <div style={{ fontSize: 10, color: "#94A3B8", marginTop: 3, display: "flex", alignItems: "center", gap: 5, paddingLeft: isMe ? 0 : 4, paddingRight: isMe ? 4 : 0 }}>
                    <span>{formatTime(item.createdAt || new Date())}</span>
                    {isMe && !isFailed && (
                      <span style={{ color: isPending ? "#94A3B8" : "#22C55E" }}>
                        {isPending ? "⏳" : "✓✓"}
                      </span>
                    )}
                    {isFailed && (
                      <button onClick={() => retryMessage(item)} style={{ background: "none", border: "none", color: "#EF4444", fontSize: 10, cursor: "pointer", fontWeight: 600, padding: 0 }}>
                        ↺ {t("messagerie.reessayer")}
                      </button>
                    )}
                  </div>
                </div>

                {isMe && <Avatar initials={recruiterInitials} size={30} bg={isAdmin ? "#003DA5" : "#7C3AED"} />}
              </div>
            );
          })}
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div style={{ padding: "12px 20px", borderTop: "1px solid #EEF2FF", background: "white", display: "flex", gap: 10, alignItems: "flex-end" }}>
          <textarea
            ref={inputRef}
            value={inputText}
            onChange={e => setInputText(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={t("messagerie.ecrire")}
            rows={1}
            disabled={sending || authError}
            style={{ flex: 1, padding: "10px 14px", borderRadius: 12, border: "1.5px solid #E2E8F0", fontSize: 13, fontFamily: "var(--font-sans)", outline: "none", resize: "none", lineHeight: 1.5, maxHeight: 120, overflowY: "auto", transition: "border-color .15s", background: authError ? "#F1F5F9" : "white" }}
            onInput={e => { e.target.style.height = "auto"; e.target.style.height = Math.min(e.target.scrollHeight, 120) + "px"; }}
            onFocus={e => e.target.style.borderColor = "#003DA5"}
            onBlur={e => e.target.style.borderColor = "#E2E8F0"}
          />
          <button
            onClick={sendMessage}
            disabled={!inputText.trim() || sending || authError}
            style={{ padding: "10px 22px", borderRadius: 12, background: inputText.trim() && !sending && !authError ? "linear-gradient(135deg, #003DA5 0%, #1a56db 100%)" : "#E2E8F0", color: inputText.trim() && !sending && !authError ? "white" : "#94A3B8", border: "none", fontSize: 13, fontWeight: 700, cursor: inputText.trim() && !sending && !authError ? "pointer" : "not-allowed", transition: "all .2s", flexShrink: 0, boxShadow: inputText.trim() && !sending && !authError ? "0 4px 14px rgba(0,61,165,0.3)" : "none", display: "flex", alignItems: "center", gap: 6 }}>
            {sending ? (
              <span style={{ display: "inline-flex", gap: 3 }}>
                {[0, 1, 2].map(i => (
                  <span key={i} style={{ width: 5, height: 5, borderRadius: "50%", background: "#94A3B8", display: "inline-block", animation: `dot-bounce 1.2s ease-in-out ${i * 0.2}s infinite` }} />
                ))}
              </span>
            ) : t("messagerie.envoyer") + " ➤"}
          </button>
        </div>
      </div>

      <style>{`
        @keyframes dot-bounce {
          0%, 60%, 100% { transform: translateY(0); opacity: 0.4; }
          30% { transform: translateY(-4px); opacity: 1; }
        }
        @keyframes fadeUp {
          from { opacity: 0; transform: translateY(6px); }
          to   { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
}