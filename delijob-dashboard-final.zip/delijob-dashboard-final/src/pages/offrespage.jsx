import { useState } from "react";
import { useApp } from "../context/appcontext.jsx";
import PageHeader from "../components/pageheader.jsx";
import Button from "../components/button.jsx";
import OffreModal from "../components/offremodal.jsx";

// ─── Statuts ──────────────────────────────────────────────────────────────────
const STATUS_CFG = {
  Ouvert: { bg: "#EBF7EF", color: "#16a34a", border: "#16a34a33", label: "Publiée",  dot: "#16a34a" },
  Fermé:  { bg: "#FDF0EE", color: "#C0392B", border: "#C0392B33", label: "Archivée", dot: "#C0392B" },
};

const BTN_BASE = {
  display: "inline-flex", alignItems: "center", gap: 5,
  padding: "6px 11px", borderRadius: 8, border: "1px solid",
  fontSize: 12, fontWeight: 600, cursor: "pointer",
  whiteSpace: "nowrap", transition: "all .15s", fontFamily: "inherit",
  lineHeight: 1.4,
};

const VARIANTS = {
  publish:   { bg: "#EBF7EF", border: "#16a34a55", color: "#15803d" },
  unpublish: { bg: "#FEF9EC", border: "#9A7D0A55", color: "#92400e" },
  edit:      { bg: "#EFF6FF", border: "#3B82F655", color: "#1d4ed8" },
  archive:   { bg: "#F1F5F9", border: "#64748B55", color: "#334155" },
  delete:    { bg: "#FDF0EE", border: "#C0392B55", color: "#b91c1c" },
};

const I = {
  eye:     <svg width="12" height="12" viewBox="0 0 16 16" fill="none"><path d="M1 8s2.5-5 7-5 7 5 7 5-2.5 5-7 5-7-5-7-5z" stroke="currentColor" strokeWidth="1.5"/><circle cx="8" cy="8" r="2" stroke="currentColor" strokeWidth="1.5"/></svg>,
  eyeOff:  <svg width="12" height="12" viewBox="0 0 16 16" fill="none"><path d="M2 2l12 12M6.5 6.6A3 3 0 0111 10M4.2 4.3C2.6 5.4 1 8 1 8s2.5 5 7 5c1.4 0 2.7-.4 3.8-1M6 3.1C6.6 3 7.3 3 8 3c4.5 0 7 5 7 5s-.7 1.4-1.9 2.7" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>,
  edit:    <svg width="12" height="12" viewBox="0 0 16 16" fill="none"><path d="M11 2l3 3-8 8H3v-3l8-8z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round"/></svg>,
  archive: <svg width="12" height="12" viewBox="0 0 16 16" fill="none"><rect x="1" y="3" width="14" height="3" rx="1" stroke="currentColor" strokeWidth="1.5"/><path d="M2 6v7a1 1 0 001 1h10a1 1 0 001-1V6" stroke="currentColor" strokeWidth="1.5"/><path d="M6 10h4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>,
  trash:   <svg width="12" height="12" viewBox="0 0 16 16" fill="none"><path d="M3 5h10M6 5V3h4v2M7 8v4M9 8v4M4 5l.8 8h6.4L12 5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  user:    <svg width="12" height="12" viewBox="0 0 16 16" fill="none"><circle cx="8" cy="5" r="3" stroke="currentColor" strokeWidth="1.5"/><path d="M2 14c0-3 2.7-5 6-5s6 2 6 5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>,
  clock:   <svg width="12" height="12" viewBox="0 0 16 16" fill="none"><circle cx="8" cy="8" r="6" stroke="currentColor" strokeWidth="1.5"/><path d="M8 5v3.5l2.5 1.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>,
  tag:     <svg width="12" height="12" viewBox="0 0 16 16" fill="none"><path d="M2 2h5l7 7-5 5-7-7V2z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round"/><circle cx="5.5" cy="5.5" r="1" fill="currentColor"/></svg>,
  spark:   <svg width="13" height="13" viewBox="0 0 16 16" fill="none"><path d="M8 1v2M8 13v2M1 8h2M13 8h2M3.2 3.2l1.4 1.4M11.4 11.4l1.4 1.4M3.2 12.8l1.4-1.4M11.4 4.6l1.4-1.4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/><circle cx="8" cy="8" r="2.5" stroke="currentColor" strokeWidth="1.5"/></svg>,
  check:   <svg width="13" height="13" viewBox="0 0 16 16" fill="none"><path d="M3 8l4 4 6-6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  spin:    <svg width="14" height="14" viewBox="0 0 16 16" fill="none" style={{ animation: "spin 1s linear infinite" }}><circle cx="8" cy="8" r="6" stroke="currentColor" strokeWidth="1.5" strokeDasharray="20 18"/></svg>,
};

function generateCode(dept, type) {
  if (!dept.trim()) return "";
  const d = dept.trim().toUpperCase().replace(/\s+/g, "").slice(0, 3);
  const t = { CDI: "CDI", CDD: "CDD", Stage: "STG", Alternance: "ALT", Freelance: "FRL" }[type] ?? "OFF";
  return `${d}-${t}-${Math.floor(1000 + Math.random() * 9000)}`;
}

const SECTOR_LABELS = {
  tech:       "Technologie & IT",
  finance:    "Finance & Comptabilité",
  marketing:  "Marketing & Communication",
  rh:         "Ressources humaines",
  vente:      "Vente & Commerce",
  ingenierie: "Ingénierie & Production",
  Logistique:"Logistique & Supply Chain",
  Production:"Industrie agroalimentaire",

};

const TON_LABELS = {
  pro:       "professionnel et formel",
  dynamique: "dynamique, motivant et engageant",
  startup:   "décontracté, startup-friendly et moderne",
};

const SKILL_KEYWORDS = [
  "JavaScript","TypeScript","Python","Java","React","Vue","Angular","Node.js",
  "SQL","PostgreSQL","MongoDB","Docker","Kubernetes","Git","AWS","Azure","GCP",
  "REST API","GraphQL","CI/CD","Agile","Scrum","Excel","Power BI","Tableau",
  "Figma","SEO","Google Ads","CRM","Salesforce","SAP","Linux","Spring","Django",
  "Laravel","PHP","C++","C#",".NET","Swift","Kotlin","TensorFlow","Machine Learning",
  "Data Science","DevOps","UX/UI","Redis","Elasticsearch","Kafka","Terraform",
];

function extractSkillsFromText(text) {
  return SKILL_KEYWORDS.filter(k =>
    text.toLowerCase().includes(k.toLowerCase())
  ).slice(0, 12);
}

async function callGenerateAPI({ titre, niveau, type, dept }) {
  const res = await fetch("http://localhost:3001/api/generate-description", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ titre, niveau, type, dept }),
  });
  if (!res.ok) throw new Error(`Erreur ${res.status}`);
  const data = await res.json();
  return data.description ?? "";
}

function Btn({ variant, icon, label, onClick, disabled }) {
  const [hov, setHov] = useState(false);
  const v = VARIANTS[variant];
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      onMouseEnter={() => !disabled && setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{
        ...BTN_BASE,
        background: v.bg, borderColor: v.border, color: v.color,
        opacity: disabled ? 0.4 : hov ? 0.8 : 1,
        transform: !disabled && hov ? "translateY(-1px)" : "none",
        cursor: disabled ? "not-allowed" : "pointer",
      }}
    >
      {I[icon]}{label}
    </button>
  );
}

function AIGenerateBtn({ disabled, generating, onClick }) {
  const [hov, setHov] = useState(false);
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled || generating}
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{
        display: "inline-flex", alignItems: "center", gap: 6,
        padding: "5px 13px", borderRadius: 8, fontFamily: "inherit",
        border: "1.5px solid #C7D2FE",
        background: generating ? "#EEF2FF" : hov ? "#C7D2FE" : "#EEF2FF",
        color: "#4338CA", fontSize: 12, fontWeight: 600,
        cursor: disabled || generating ? "not-allowed" : "pointer",
        opacity: disabled ? 0.5 : 1, transition: "all .15s",
      }}
    >
      {generating ? <>{I.spin} Génération…</> : <>{I.spark} Générer avec l'IA</>}
    </button>
  );
}

function SkillTags({ skills }) {
  if (!skills.length) return null;
  return (
    <div style={{ marginTop: 10 }}>
      <div style={{ fontSize: 11, fontWeight: 700, color: "var(--muted)", textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 6 }}>
        Compétences détectées
      </div>
      <div style={{ display: "flex", flexWrap: "wrap", gap: 5 }}>
        {skills.map(s => (
          <span key={s} style={{ display: "inline-flex", alignItems: "center", gap: 4, padding: "3px 10px", borderRadius: 99, fontSize: 11, fontWeight: 600, background: "#EEF2FF", color: "#4338CA", border: "1px solid #C7D2FE" }}>
            {I.tag}{s}
          </span>
        ))}
      </div>
    </div>
  );
}

// ─── Modal de modification ────────────────────────────────────────────────────
function EditModal({ offre, onSave, onClose }) {
  const [form, setForm] = useState({
    titre:       offre.titre       ?? "",
    dept:        offre.dept        ?? "",
    type:        offre.type        ?? "CDI",
    niveau:      offre.niveau      ?? "Junior",
    description: offre.description ?? "",
  });
  const [loading,    setLoading]    = useState(false);
  const [error,      setError]      = useState("");
  const [generating, setGenerating] = useState(false);
  const [aiError,    setAiError]    = useState("");
  const [aiSkills,   setAiSkills]   = useState([]);
  const [secteur,    setSecteur]    = useState("tech");
  const [ton,        setTon]        = useState("pro");

  const inp = {
    width: "100%", padding: "9px 12px", borderRadius: 9, fontSize: 13,
    border: "1.5px solid var(--border)", fontFamily: "var(--font-sans)",
    outline: "none", color: "var(--dark)", background: "var(--white)",
    boxSizing: "border-box",
  };
  const lbl = {
    display: "block", fontSize: 11, fontWeight: 700, color: "var(--muted)",
    textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 5,
  };

  async function generateWithAI() {
    if (!form.titre.trim()) return;
    setGenerating(true); setAiError(""); setAiSkills([]);
    try {
      const description = await callGenerateAPI(form);
      setForm(f => ({ ...f, description }));
      setAiSkills(extractSkillsFromText(description));
    } catch (err) {
      setAiError(err.message);
    } finally {
      setGenerating(false);
    }
  }

  async function save(e) {
    e.preventDefault();
    if (!form.titre.trim() || !form.dept.trim()) return;
    setLoading(true); setError("");
    try { await onSave(offre.id, form); onClose(); }
    catch (err) { setError(err.message ?? "Erreur"); }
    finally { setLoading(false); }
  }

  return (
    <div
      style={{ position: "fixed", inset: 0, zIndex: 1000, background: "rgba(0,0,0,0.45)", display: "flex", alignItems: "center", justifyContent: "center", padding: 16 }}
      onClick={e => e.target === e.currentTarget && onClose()}
    >
      <div style={{ background: "var(--white)", borderRadius: 16, width: "100%", maxWidth: 580, boxShadow: "0 20px 60px rgba(0,0,0,0.2)", overflow: "hidden", maxHeight: "90vh", overflowY: "auto" }}>
        <div style={{ padding: "16px 20px", background: "#3B82F6", display: "flex", justifyContent: "space-between", alignItems: "center", position: "sticky", top: 0, zIndex: 1 }}>
          <div>
            <div style={{ fontWeight: 700, fontSize: 15, color: "#fff" }}>Modifier l'offre</div>
            <div style={{ fontSize: 12, color: "rgba(255,255,255,.7)", marginTop: 2 }}>{offre.code}</div>
          </div>
          <button onClick={onClose} style={{ background: "rgba(255,255,255,.15)", border: "none", borderRadius: 8, color: "#fff", cursor: "pointer", fontSize: 18, width: 32, height: 32, display: "flex", alignItems: "center", justifyContent: "center" }}>✕</button>
        </div>

        <form onSubmit={save} style={{ padding: 20, display: "flex", flexDirection: "column", gap: 14 }}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
            <div>
              <label style={lbl}>Titre *</label>
              <input style={inp} value={form.titre} onChange={e => setForm(f => ({ ...f, titre: e.target.value }))} required />
            </div>
            <div>
              <label style={lbl}>Département *</label>
              <input style={inp} value={form.dept} onChange={e => setForm(f => ({ ...f, dept: e.target.value }))} required />
            </div>
            <div>
              <label style={lbl}>Type de contrat</label>
              <select style={inp} value={form.type} onChange={e => setForm(f => ({ ...f, type: e.target.value }))}>
                {["CDI", "CDD", "Stage", "Alternance", "Freelance"].map(v => <option key={v}>{v}</option>)}
              </select>
            </div>
            <div>
              <label style={lbl}>Niveau</label>
              <select style={inp} value={form.niveau} onChange={e => setForm(f => ({ ...f, niveau: e.target.value }))}>
                {["Junior", "Intermédiaire", "Senior", "Expert"].map(v => <option key={v}>{v}</option>)}
              </select>
            </div>
            <div>
              <label style={lbl}>Secteur</label>
              <select style={inp} value={secteur} onChange={e => setSecteur(e.target.value)}>
                {Object.entries(SECTOR_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
              </select>
            </div>
            <div>
              <label style={lbl}>Ton IA</label>
              <select style={inp} value={ton} onChange={e => setTon(e.target.value)}>
                {Object.entries(TON_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
              </select>
            </div>
          </div>

          <div>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 5 }}>
              <label style={{ ...lbl, margin: 0 }}>Description</label>
              <AIGenerateBtn disabled={!form.titre.trim()} generating={generating} onClick={generateWithAI} />
            </div>
            <textarea
              style={{ ...inp, minHeight: 160, resize: "vertical", lineHeight: 1.6 }}
              value={form.description}
              onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
              placeholder={generating ? "L'IA génère la description…" : "Description du poste…"}
            />
            {generating && (
              <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 6, fontSize: 12, color: "#6366F1" }}>
                {I.spin} Rédaction en cours…
              </div>
            )}
            {!generating && form.description && aiSkills.length > 0 && (
              <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 6, fontSize: 12, color: "#16a34a" }}>
                {I.check} Description générée avec succès
              </div>
            )}
            {aiError && <div style={{ marginTop: 6, fontSize: 12, color: "#b91c1c" }}>⚠ {aiError}</div>}
            <SkillTags skills={aiSkills} />
          </div>

          {error && (
            <div style={{ padding: "8px 14px", borderRadius: 8, background: "#FDF0EE", color: "#b91c1c", fontSize: 12, fontWeight: 600 }}>⚠ {error}</div>
          )}

          <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
            <button type="button" onClick={onClose} style={{ padding: "9px 20px", borderRadius: 9, border: "1.5px solid var(--border)", background: "var(--white)", color: "var(--muted)", cursor: "pointer", fontSize: 13, fontWeight: 600 }}>
              Annuler
            </button>
            <button type="submit" disabled={loading} style={{ padding: "9px 22px", borderRadius: 9, border: "none", background: loading ? "#93C5FD" : "#3B82F6", color: "#fff", cursor: loading ? "not-allowed" : "pointer", fontSize: 13, fontWeight: 700, display: "flex", alignItems: "center", gap: 6 }}>
              {loading ? <>{I.spin} Enregistrement…</> : "Enregistrer"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function StatCard({ label, value, bg, color, icon }) {
  return (
    <div style={{ flex: 1, minWidth: 110, borderRadius: 12, padding: "14px 18px", background: bg, border: `1.5px solid ${color}33`, display: "flex", flexDirection: "column", gap: 4 }}>
      <div style={{ fontSize: 17 }}>{icon}</div>
      <div style={{ fontSize: 22, fontWeight: 800, color }}>{value}</div>
      <div style={{ fontSize: 11, fontWeight: 600, color, opacity: 0.75, textTransform: "uppercase", letterSpacing: "0.5px" }}>{label}</div>
    </div>
  );
}

function OfferCard({ o, isAdmin, currentUserId, updateOfferStatus, deleteOffer, onEdit }) {
  const sc      = STATUS_CFG[o.statut] || STATUS_CFG["Ouvert"];
  const isOpen  = o.statut === "Ouvert";
  const isOwner = String(o.createdBy) === String(currentUserId);
  const canAct  = isAdmin || isOwner;

  return (
    <div
      style={{ borderRadius: 14, border: "1.5px solid var(--border)", background: "var(--white)", boxShadow: "0 2px 12px rgba(0,0,0,0.05)", overflow: "hidden", display: "flex", flexDirection: "column", transition: "box-shadow .2s, transform .2s" }}
      onMouseEnter={e => { e.currentTarget.style.boxShadow = "0 6px 24px rgba(0,0,0,0.10)"; e.currentTarget.style.transform = "translateY(-2px)"; }}
      onMouseLeave={e => { e.currentTarget.style.boxShadow = "0 2px 12px rgba(0,0,0,0.05)"; e.currentTarget.style.transform = "none"; }}
    >
      <div style={{ padding: "14px 18px 12px", borderBottom: "1px solid var(--border)", display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 8 }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: "var(--blue)", textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 4 }}>{o.code}</div>
          <div style={{ fontSize: 15, fontWeight: 700, color: "var(--dark)", lineHeight: 1.3, marginBottom: 3 }}>{o.titre}</div>
          <div style={{ fontSize: 12, color: "var(--muted)" }}>{o.dept}</div>
        </div>
        <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 5 }}>
          <span style={{ fontSize: 11, fontWeight: 700, padding: "4px 10px", borderRadius: 20, flexShrink: 0, background: sc.bg, color: sc.color, border: `1px solid ${sc.border}`, display: "flex", alignItems: "center", gap: 5 }}>
            <span style={{ width: 6, height: 6, borderRadius: "50%", background: sc.dot, display: "inline-block" }} />
            {sc.label}
          </span>
          {!canAct && !isAdmin && (
            <span style={{ fontSize: 10, padding: "2px 8px", borderRadius: 20, background: "#F1F5F9", color: "#64748B", fontWeight: 600, border: "1px solid #E2E8F0" }}>
              👁 Lecture seule
            </span>
          )}
        </div>
      </div>

      <div style={{ padding: "12px 18px", flex: 1, display: "flex", flexDirection: "column", gap: 10 }}>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          <span style={{ display: "inline-flex", alignItems: "center", gap: 4, background: "var(--blue-light)", color: "var(--blue)", padding: "3px 10px", borderRadius: 20, fontWeight: 600, fontSize: 11 }}>{I.tag}{o.type}</span>
          <span style={{ display: "inline-flex", alignItems: "center", gap: 4, background: "#F1F5F9", color: "#475569", padding: "3px 10px", borderRadius: 20, fontWeight: 600, fontSize: 11 }}>{o.niveau}</span>
        </div>
        {o.description && (
          <p style={{ fontSize: 12, color: "var(--muted)", margin: 0, lineHeight: 1.5, display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden" }}>
            {o.description}
          </p>
        )}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: "auto", paddingTop: 4 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 12, color: "var(--muted)" }}>
            {I.user}
            <span><strong style={{ color: "var(--blue)", fontWeight: 700 }}>{o.candidats ?? 0}</strong> candidats</span>
          </div>
          {o.createdAt && (
            <div style={{ display: "flex", alignItems: "center", gap: 4, fontSize: 11, color: "var(--muted)" }}>
              {I.clock}
              {new Date(o.createdAt).toLocaleDateString("fr-FR", { day: "2-digit", month: "short", year: "numeric" })}
            </div>
          )}
        </div>
      </div>

      <div style={{ padding: "10px 14px", borderTop: "1px solid var(--border)", background: "#F8FAFF", display: "flex", gap: 6, flexWrap: "wrap", alignItems: "center" }}>
        <Btn
          variant={isOpen ? "unpublish" : "publish"}
          icon={isOpen ? "eyeOff" : "eye"}
          label={isOpen ? "Dépublier" : "Publier"}
          onClick={() => updateOfferStatus(o.id, isOpen ? "Fermé" : "Ouvert")}
          disabled={!canAct}
        />
        <Btn variant="edit"    icon="edit"    label="Modifier"  onClick={() => onEdit(o)}                          disabled={!canAct} />
        {isOpen && (
          <Btn variant="archive" icon="archive" label="Archiver" onClick={() => updateOfferStatus(o.id, "Fermé")} disabled={!canAct} />
        )}
        <div style={{ marginLeft: "auto" }}>
          <Btn variant="delete" icon="trash" label="Supprimer" onClick={() => deleteOffer(o.id)} disabled={!canAct} />
        </div>
      </div>
    </div>
  );
}

function OffersGrid({ offers, isAdmin, currentUserId, updateOfferStatus, deleteOffer, onEdit, emptyMsg, loading }) {
  if (loading) return (
    <div style={{ textAlign: "center", padding: "48px 24px", color: "var(--muted)", fontSize: 14, display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
      {I.spin} Chargement des offres…
    </div>
  );
  if (offers.length === 0) return (
    <div style={{ textAlign: "center", padding: "48px 24px", color: "var(--muted)", fontSize: 14 }}>{emptyMsg}</div>
  );
  return (
    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: 16, padding: "20px" }}>
      {offers.map(o => (
        <OfferCard
          key={o.id} o={o} isAdmin={isAdmin} currentUserId={currentUserId}
          updateOfferStatus={updateOfferStatus} deleteOffer={deleteOffer} onEdit={onEdit}
        />
      ))}
    </div>
  );
}

function PagBtn({ children, onClick, disabled }) {
  return (
    <button onClick={onClick} disabled={disabled} style={{ width: 30, height: 30, borderRadius: 7, border: "1px solid var(--border)", background: disabled ? "#f5f5f5" : "var(--white)", color: disabled ? "#ccc" : "var(--dark)", cursor: disabled ? "default" : "pointer", fontSize: 13, fontWeight: 600, display: "flex", alignItems: "center", justifyContent: "center" }}>
      {children}
    </button>
  );
}

// ─── Formulaire d'ajout d'offre ───────────────────────────────────────────────
function AddOfferForm({ onSubmit, onCancel }) {
  const [form, setForm]       = useState({ titre: "", code: "", dept: "", type: "CDI", niveau: "Junior", description: "" });
  const [error, setError]     = useState("");
  const [loading, setLoading] = useState(false);
  const [manual, setManual]   = useState(false);
  const [generating, setGenerating] = useState(false);
  const [aiError,    setAiError]    = useState("");
  const [aiSkills,   setAiSkills]   = useState([]);
  const [aiDone,     setAiDone]     = useState(false);
  const [secteur,    setSecteur]    = useState("tech");
  const [ton,        setTon]        = useState("pro");

  function set(k, v) {
    setForm(f => {
      const u = { ...f, [k]: v };
      if ((k === "dept" || k === "type") && !manual) {
        u.code = generateCode(k === "dept" ? v : f.dept, k === "type" ? v : f.type);
      }
      return u;
    });
    if (k === "titre" || k === "niveau") setAiDone(false);
  }

  const inp = {
    width: "100%", padding: "9px 12px", borderRadius: 9, fontSize: 13,
    border: "1.5px solid var(--border)", fontFamily: "var(--font-sans)",
    outline: "none", color: "var(--dark)", background: "var(--white)",
    boxSizing: "border-box",
  };
  const lbl = {
    display: "block", fontSize: 11, fontWeight: 700, color: "var(--muted)",
    textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 5,
  };

  async function generateWithAI() {
    if (!form.titre.trim()) return;
    setGenerating(true); setAiError(""); setAiSkills([]); setAiDone(false);
    try {
      const description = await callGenerateAPI(form);
      setForm(f => ({ ...f, description }));
      setAiSkills(extractSkillsFromText(description));
      setAiDone(true);
    } catch (err) {
      setAiError(err.message);
    } finally {
      setGenerating(false);
    }
  }

  async function submit(e) {
    e.preventDefault();
    if (!form.titre.trim() || !form.code.trim() || !form.dept.trim()) return;
    setError(""); setLoading(true);
    try { await onSubmit(form); }
    catch (err) { setError(err.message ?? "Erreur"); }
    finally { setLoading(false); }
  }

  return (
    <div style={{ margin: "0 0 20px", borderRadius: 14, border: "2px solid #C7D2FE", background: "#F5F3FF", overflow: "hidden", boxShadow: "0 4px 24px rgba(79,70,229,.08)" }}>
      <div style={{ padding: "14px 20px", background: "#4F46E5", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div>
          <div style={{ fontWeight: 700, fontSize: 15, color: "#fff" }}>Nouvelle offre</div>
          <div style={{ fontSize: 12, color: "rgba(255,255,255,.7)", marginTop: 2 }}>Publiée immédiatement · IA disponible</div>
        </div>
        <button onClick={onCancel} style={{ background: "rgba(255,255,255,.15)", border: "none", borderRadius: 8, color: "#fff", cursor: "pointer", fontSize: 18, width: 32, height: 32, display: "flex", alignItems: "center", justifyContent: "center" }}>✕</button>
      </div>

      <form onSubmit={submit} style={{ padding: 20, display: "flex", flexDirection: "column", gap: 14 }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
          <div>
            <label style={lbl}>Titre du poste *</label>
            <input style={inp} value={form.titre} onChange={e => set("titre", e.target.value)} placeholder="Ex: Ingénieur DevOps" required />
          </div>
          <div>
            <label style={lbl}>Département *</label>
            <input style={inp} value={form.dept} onChange={e => set("dept", e.target.value)} placeholder="Ex: Informatique" required />
          </div>
          <div>
            <label style={lbl}>Type de contrat</label>
            <select style={inp} value={form.type} onChange={e => set("type", e.target.value)}>
              {["CDI", "CDD", "Stage", "Alternance", "Freelance"].map(v => <option key={v}>{v}</option>)}
            </select>
          </div>
          <div>
            <label style={{ ...lbl, display: "flex", alignItems: "center", gap: 6 }}>
              Code offre *
              <span style={{ fontSize: 10, fontWeight: 600, color: manual ? "#9A7D0A" : "#16a34a", background: manual ? "#FEF9EC" : "#EBF7EF", padding: "1px 7px", borderRadius: 10 }}>
                {manual ? "✏ Manuel" : "⚡ Auto"}
              </span>
            </label>
            <div style={{ display: "flex", gap: 6 }}>
              <input
                style={{ ...inp, flex: 1, fontFamily: "monospace", fontWeight: 700, color: "#4F46E5", background: manual ? "var(--white)" : "#F0F4FF" }}
                value={form.code}
                onChange={e => { setManual(true); setForm(f => ({ ...f, code: e.target.value })); }}
                placeholder="INF-CDI-4521" required
              />
              <button type="button"
                onClick={() => { setManual(false); setForm(f => ({ ...f, code: generateCode(f.dept, f.type) })); }}
                style={{ padding: "0 12px", borderRadius: 9, border: "1.5px solid #C7D2FE", background: "#EEF2FF", color: "#4F46E5", cursor: "pointer", fontSize: 16, display: "flex", alignItems: "center" }}
                onMouseEnter={e => e.currentTarget.style.background = "#C7D2FE"}
                onMouseLeave={e => e.currentTarget.style.background = "#EEF2FF"}
              >🔄</button>
            </div>
          </div>
          <div>
            <label style={lbl}>Niveau</label>
            <select style={inp} value={form.niveau} onChange={e => set("niveau", e.target.value)}>
              {["Junior", "Intermédiaire", "Senior", "Expert"].map(v => <option key={v}>{v}</option>)}
            </select>
          </div>
          <div>
            <label style={lbl}>Secteur (pour l'IA)</label>
            <select style={inp} value={secteur} onChange={e => setSecteur(e.target.value)}>
              {Object.entries(SECTOR_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
            </select>
          </div>
          <div>
            <label style={lbl}>Ton de la description</label>
            <select style={inp} value={ton} onChange={e => setTon(e.target.value)}>
              {Object.entries(TON_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
            </select>
          </div>
        </div>

        <div>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 5 }}>
            <label style={{ ...lbl, margin: 0 }}>Description du poste</label>
            <AIGenerateBtn disabled={!form.titre.trim()} generating={generating} onClick={generateWithAI} />
          </div>
          <textarea
            style={{ ...inp, minHeight: 180, resize: "vertical", lineHeight: 1.65 }}
            value={form.description}
            onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
            placeholder={generating ? "L'IA rédige votre description…" : "Décris les missions, les prérequis… ou laisse l'IA générer."}
          />
          {generating && (
            <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 6, fontSize: 12, color: "#6366F1" }}>
              {I.spin} L'IA rédige en temps réel…
            </div>
          )}
          {aiDone && !generating && (
            <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 6, fontSize: 12, color: "#16a34a" }}>
              {I.check} Description générée — tu peux la modifier librement.
            </div>
          )}
          {aiError && (
            <div style={{ marginTop: 6, fontSize: 12, color: "#b91c1c" }}>⚠ {aiError}</div>
          )}
          <SkillTags skills={aiSkills} />
        </div>

        {error && (
          <div style={{ padding: "8px 14px", borderRadius: 8, background: "#FDF0EE", color: "#b91c1c", fontSize: 12, fontWeight: 600 }}>⚠ {error}</div>
        )}

        <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
          <button type="button" onClick={onCancel} style={{ padding: "9px 20px", borderRadius: 9, border: "1.5px solid var(--border)", background: "var(--white)", color: "var(--muted)", cursor: "pointer", fontSize: 13, fontWeight: 600 }}>
            Annuler
          </button>
          <button type="submit" disabled={loading} style={{ padding: "9px 22px", borderRadius: 9, border: "none", background: loading ? "#818CF8" : "#4F46E5", color: "#fff", cursor: loading ? "not-allowed" : "pointer", fontSize: 13, fontWeight: 700, boxShadow: "0 3px 12px rgba(79,70,229,.3)", display: "flex", alignItems: "center", gap: 6 }}>
            {loading ? <>{I.spin} Envoi…</> : "Publier →"}
          </button>
        </div>
      </form>
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════════
// PAGE PRINCIPALE
// ════════════════════════════════════════════════════════════════════════════
export default function OffresPage() {
  const {
    offers, offersLoading,
    addOffer, updateOfferStatus, deleteOffer, updateOffer,
    currentUser, currentUserId,
  } = useApp();

  const isAdmin = currentUser?.role?.toUpperCase() === "ADMIN";

  const [showModal,    setShowModal]    = useState(false);
  const [filterStatut, setFilterStatut] = useState("Tous");
  const [search,       setSearch]       = useState("");
  const [currentPage,  setCurrentPage]  = useState(1);
  const [recruiterTab, setRecruiterTab] = useState("en_cours");
  const [showAddForm,  setShowAddForm]  = useState(false);
  const [editingOffer, setEditingOffer] = useState(null);
  const perPage = 9;

  const allOffers      = offers;
  const activeOffers   = allOffers.filter(o => o.statut === "Ouvert");
  const archivedOffers = allOffers.filter(o => o.statut === "Fermé");

  // ── Offres du recruteur connecté uniquement ────────────────────────────────
  const myOffers = allOffers.filter(o => String(o.createdBy) === String(currentUserId));

  const adminFiltered = offers.filter(o => {
    const matchStatus = filterStatut === "Tous" || o.statut === filterStatut;
    const q = search.toLowerCase();
    return matchStatus && (!q || o.titre?.toLowerCase().includes(q) || o.code?.toLowerCase().includes(q) || o.dept?.toLowerCase().includes(q));
  });
  const totalPages = Math.max(1, Math.ceil(adminFiltered.length / perPage));
  const paginated  = adminFiltered.slice((currentPage - 1) * perPage, currentPage * perPage);

  function goPage(p) { setCurrentPage(Math.max(1, Math.min(p, totalPages))); }

  async function handleEditSave(id, form) {
    if (typeof updateOffer === "function") await updateOffer(id, form);
    else console.warn("updateOffer non défini dans AppContext");
  }

  // ── VUE RECRUTEUR ──────────────────────────────────────────────────────────
  if (!isAdmin) {
    const q = search.toLowerCase();

    // Sélection de la base selon l'onglet actif
    const base =
      recruiterTab === "en_cours"   ? activeOffers :
      recruiterTab === "mes_offres" ? myOffers      :
      allOffers;

    const displayed = base.filter(o =>
      !q || o.titre?.toLowerCase().includes(q) || o.code?.toLowerCase().includes(q) || o.dept?.toLowerCase().includes(q)
    );

    return (
      <div>
        <PageHeader
          title="Toutes les offres"
          subtitle="Consultez toutes les offres · Gérez les vôtres"
          action={
            <Button
              variant="secondary"
              onClick={() => setShowAddForm(v => !v)}
              style={{ background: "rgba(255,255,255,0.15)", color: "white", border: "1.5px solid rgba(255,255,255,0.4)" }}
            >
              {showAddForm ? "Annuler" : "+ Nouvelle offre"}
            </Button>
          }
        />

        {showAddForm && (
          <AddOfferForm
            onSubmit={async f => { await addOffer(f); setShowAddForm(false); }}
            onCancel={() => setShowAddForm(false)}
          />
        )}

        {/* Stats */}
        <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginBottom: 20 }}>
          <StatCard label="Publiées"   value={activeOffers.length}   bg="#EBF7EF" color="#16a34a" icon="🟢" />
          <StatCard label="Archivées"  value={archivedOffers.length} bg="#FDF0EE" color="#C0392B" icon="📦" />
          <StatCard label="Total"      value={allOffers.length}      bg="#EEF2FF" color="#4F46E5" icon="📋" />
          <StatCard label="Mes offres" value={myOffers.length}       bg="#F5F3FF" color="#7C3AED" icon="👤" />
        </div>

        <div style={{ background: "var(--white)", borderRadius: 14, border: "2px solid var(--blue)", overflow: "hidden" }}>
          <div style={{ padding: "14px 20px", borderBottom: "1px solid var(--border)", display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12, flexWrap: "wrap" }}>
            <div style={{ display: "flex", gap: 6 }}>
              {[
                { key: "en_cours",   label: "Publiées",   count: activeOffers.length },
                { key: "mes_offres", label: "Mes offres", count: myOffers.length     },
                { key: "toutes",     label: "Toutes",     count: allOffers.length    },
              ].map(tab => (
                <button
                  key={tab.key}
                  onClick={() => setRecruiterTab(tab.key)}
                  style={{
                    padding: "7px 16px", borderRadius: 20, fontSize: 12, fontWeight: 700,
                    cursor: "pointer", border: "1.5px solid",
                    borderColor: recruiterTab === tab.key ? "var(--blue)" : "var(--border)",
                    background:  recruiterTab === tab.key ? "var(--blue)" : "transparent",
                    color:       recruiterTab === tab.key ? "white" : "var(--muted)",
                    display: "flex", alignItems: "center", gap: 6,
                  }}
                >
                  {tab.label}
                  <span style={{
                    background: recruiterTab === tab.key ? "rgba(255,255,255,.25)" : "#EEF2FF",
                    color:      recruiterTab === tab.key ? "#fff" : "var(--blue)",
                    borderRadius: 20, padding: "1px 7px", fontSize: 11, fontWeight: 800,
                  }}>
                    {tab.count}
                  </span>
                </button>
              ))}
            </div>
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Rechercher…"
              style={{ width: 180, padding: "7px 12px", borderRadius: 9, border: "1.5px solid var(--border)", fontSize: 13, outline: "none" }}
            />
          </div>

          {/* Message contextuel pour l'onglet "Mes offres" */}
          {recruiterTab === "mes_offres" && (
            <div style={{ margin: "12px 20px 0", padding: "10px 14px", borderRadius: 9, background: "#F5F3FF", border: "1px solid #C7D2FE", fontSize: 12, color: "#4338CA", display: "flex", alignItems: "center", gap: 8 }}>
              👤 <span>Vous ne voyez ici que vos offres — vous pouvez les modifier, archiver et supprimer.</span>
            </div>
          )}

          <OffersGrid
            offers={displayed}
            isAdmin={false}
            currentUserId={currentUserId}
            updateOfferStatus={updateOfferStatus}
            deleteOffer={deleteOffer}
            onEdit={setEditingOffer}
            loading={offersLoading}
            emptyMsg={
              recruiterTab === "mes_offres"
                ? "Vous n'avez encore créé aucune offre."
                : "Aucune offre"
            }
          />
        </div>

        {editingOffer && (
          <EditModal offre={editingOffer} onSave={handleEditSave} onClose={() => setEditingOffer(null)} />
        )}
      </div>
    );
  }

  // ── VUE ADMIN ──────────────────────────────────────────────────────────────
  return (
    <div>
      <PageHeader
        title="Gestion des offres"
        subtitle="Toutes les offres de la plateforme"
        action={
          <Button
            variant="secondary"
            onClick={() => setShowModal(true)}
            style={{ background: "rgba(255,255,255,0.15)", color: "white", border: "1.5px solid rgba(255,255,255,0.4)" }}
          >
            + Nouvelle offre
          </Button>
        }
      />

      <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginBottom: 20 }}>
        <StatCard label="Total"     value={offers.length}                                    bg="#EEF2FF" color="#4F46E5" icon="📋" />
        <StatCard label="Publiées"  value={offers.filter(o => o.statut === "Ouvert").length} bg="#EBF7EF" color="#16a34a" icon="🟢" />
        <StatCard label="Archivées" value={offers.filter(o => o.statut === "Fermé").length}  bg="#FDF0EE" color="#C0392B" icon="📦" />
      </div>

      <div style={{ background: "var(--white)", borderRadius: 14, border: "2px solid var(--blue)", overflow: "hidden" }}>
        <div style={{ padding: "16px 24px", borderBottom: "1px solid var(--border)", display: "flex", alignItems: "center", justifyContent: "space-between", gap: 16, flexWrap: "wrap" }}>
          <h3 style={{ fontSize: 15, fontWeight: 700, color: "var(--blue)", margin: 0 }}>Liste des offres</h3>
          <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
            <input
              value={search} onChange={e => { setSearch(e.target.value); setCurrentPage(1); }} placeholder="Rechercher…"
              style={{ width: 200, padding: "7px 12px", borderRadius: 9, border: "1.5px solid var(--border)", fontSize: 13, outline: "none" }}
            />
            {[["Tous", "Tous"], ["Ouvert", "Publiées"], ["Fermé", "Archivées"]].map(([val, label]) => (
              <button key={val} onClick={() => { setFilterStatut(val); setCurrentPage(1); }} style={{ padding: "6px 14px", borderRadius: 20, fontSize: 12, fontWeight: 600, cursor: "pointer", border: "1.5px solid", borderColor: filterStatut === val ? "var(--blue)" : "var(--border)", background: filterStatut === val ? "var(--blue)" : "transparent", color: filterStatut === val ? "white" : "var(--muted)" }}>
                {label}
              </button>
            ))}
          </div>
        </div>

        <OffersGrid
          offers={paginated} isAdmin={true} currentUserId={currentUserId}
          updateOfferStatus={updateOfferStatus} deleteOffer={deleteOffer} onEdit={setEditingOffer}
          loading={offersLoading} emptyMsg="Aucune offre trouvée"
        />

        <div style={{ padding: "12px 24px", borderTop: "1px solid var(--border)", display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 12 }}>
          <span style={{ fontSize: 13, color: "var(--muted)" }}>
            {adminFiltered.length === 0 ? "0" : `${Math.min((currentPage - 1) * perPage + 1, adminFiltered.length)}–${Math.min(currentPage * perPage, adminFiltered.length)}`} sur {adminFiltered.length} offres
          </span>
          <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
            <PagBtn onClick={() => goPage(1)}               disabled={currentPage === 1}>|&lt;</PagBtn>
            <PagBtn onClick={() => goPage(currentPage - 1)} disabled={currentPage === 1}>&lt;</PagBtn>
            <span style={{ fontSize: 13, fontWeight: 600, color: "var(--dark)", padding: "0 8px" }}>Page {currentPage} / {totalPages}</span>
            <PagBtn onClick={() => goPage(currentPage + 1)} disabled={currentPage === totalPages}>&gt;</PagBtn>
            <PagBtn onClick={() => goPage(totalPages)}      disabled={currentPage === totalPages}>&gt;|</PagBtn>
          </div>
        </div>
      </div>

      {editingOffer && <EditModal offre={editingOffer} onSave={handleEditSave} onClose={() => setEditingOffer(null)} />}
      {showModal    && <OffreModal onClose={() => setShowModal(false)} />}
    </div>
  );
}