import { useState, useEffect, useCallback } from "react";
import { useApp } from "../context/appcontext.jsx";
import { useI18n } from "../i18n/i18nContext.jsx";

const API_BASE = "http://localhost:8080";

function authHeaders(isJson = true) {
  const token = localStorage.getItem("token");
  const headers = {
    ...(isJson ? { "Content-Type": "application/json" } : {}),
  };
  if (token) {
    headers["Authorization"] = `Bearer ${token}`;
  }
  return headers;
}

function EyeIcon({ visible }) {
  return visible ? (
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
      <circle cx="12" cy="12" r="3"/>
    </svg>
  ) : (
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/>
      <line x1="1" y1="1" x2="23" y2="23"/>
    </svg>
  );
}

function PwInput({ value, onChange, placeholder, disabled }) {
  const [show, setShow] = useState(false);
  return (
    <div style={{ position: "relative" }}>
      <input
        type={show ? "text" : "password"}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        disabled={disabled}
        style={{
          width: "100%", height: 42, padding: "0 40px 0 14px",
          borderRadius: 10, border: "1.5px solid #E2E8F0",
          fontSize: 14, color: "#0F172A", background: "white",
          outline: "none", boxSizing: "border-box",
          fontFamily: "var(--font-sans)",
        }}
        onFocus={e => e.target.style.borderColor = "#003DA5"}
        onBlur={e => e.target.style.borderColor = "#E2E8F0"}
      />
      <button
        type="button"
        onClick={() => setShow(v => !v)}
        tabIndex={-1}
        style={{
          position: "absolute", right: 12, top: "50%", transform: "translateY(-50%)",
          background: "none", border: "none", cursor: "pointer", color: "#94A3B8",
          display: "flex", alignItems: "center", padding: 0
        }}
      >
        <EyeIcon visible={show} />
      </button>
    </div>
  );
}

function PasswordStrength({ value }) {
  if (!value) return null;
  const score = [
    value.length >= 8,
    /[A-Z]/.test(value),
    /[0-9]/.test(value),
    /[^A-Za-z0-9]/.test(value),
  ].filter(Boolean).length;
  const colors = ["#E24B4A", "#EF9F27", "#1D9E75", "#1D9E75"];
  return (
    <div style={{ marginTop: 8 }}>
      <div style={{ display: "flex", gap: 3 }}>
        {[0, 1, 2, 3].map(i => (
          <div
            key={i}
            style={{
              flex: 1, height: 3, borderRadius: 2,
              background: i < score ? colors[score - 1] : "#E2E8F0",
              transition: "background .25s"
            }}
          />
        ))}
      </div>
    </div>
  );
}

function Toast({ msg, type }) {
  if (!msg) return null;
  const ok = type === "success";
  return (
    <div
      style={{
        position: "fixed", bottom: 28, right: 28, zIndex: 2000,
        background: ok ? "#0F172A" : "#DC2626",
        color: "white", padding: "13px 22px", borderRadius: 12,
        fontSize: 13, fontWeight: 600,
        boxShadow: "0 8px 24px rgba(0,0,0,0.25)",
        display: "flex", alignItems: "center", gap: 9,
        animation: "slideUp .25s ease",
      }}
    >
      <span style={{ fontSize: 16 }}>{ok ? "✓" : "✕"}</span>
      {msg}
    </div>
  );
}

function SectionCard({ title, icon, children }) {
  return (
    <div
      style={{
        background: "white", borderRadius: 16,
        border: "1px solid #E8EEFF",
        boxShadow: "0 2px 12px rgba(0,61,165,0.06)",
        overflow: "hidden", marginBottom: 20,
      }}
    >
      <div
        style={{
          padding: "16px 24px", borderBottom: "1px solid #EEF2FF",
          display: "flex", alignItems: "center", gap: 10, background: "#FAFBFF",
        }}
      >
        <span style={{ fontSize: 18 }}>{icon}</span>
        <span style={{ fontSize: 15, fontWeight: 700, color: "#0F172A" }}>{title}</span>
      </div>
      <div style={{ padding: "24px" }}>{children}</div>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div>
      <label
        style={{
          display: "block", fontSize: 11, fontWeight: 700, color: "#94A3B8",
          marginBottom: 6, textTransform: "uppercase", letterSpacing: ".8px"
        }}
      >
        {label}
      </label>
      {children}
    </div>
  );
}

function TextInput({ value, onChange, placeholder, type = "text", disabled, readOnly }) {
  return (
    <input
      type={type}
      value={value}
      onChange={onChange}
      placeholder={placeholder}
      disabled={disabled}
      readOnly={readOnly}
      style={{
        width: "100%", height: 42, padding: "0 14px", borderRadius: 10,
        border: readOnly ? "1.5px solid #F1F5F9" : "1.5px solid #E2E8F0",
        fontSize: 14, color: readOnly ? "#94A3B8" : "#0F172A",
        background: readOnly ? "#F8FAFF" : "white",
        outline: "none", boxSizing: "border-box", transition: "border-color .15s",
        fontFamily: "var(--font-sans)", cursor: readOnly ? "not-allowed" : "text",
      }}
      onFocus={e => { if (!readOnly && !disabled) e.target.style.borderColor = "#003DA5"; }}
      onBlur={e => { if (!readOnly && !disabled) e.target.style.borderColor = "#E2E8F0"; }}
    />
  );
}

export default function ProfilPage() {
  const { currentUser, refreshUser } = useApp();
  const { t } = useI18n();

  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    prenom: "", nom: "", email: "", telephone: "", poste: "", departement: ""
  });
  const [savedPhotoUrl, setSavedPhotoUrl] = useState(null);
  const [savingInfo, setSavingInfo] = useState(false);
  const [savingPw, setSavingPw] = useState(false);
  const [pw, setPw] = useState({ current: "", next: "", confirm: "" });
  const [toast, setToast] = useState(null);

  const showToast = useCallback((msg, type = "success") => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3000);
  }, []);

  // Charger les données depuis currentUser
  useEffect(() => {
    if (currentUser) {
      console.log("📋 Chargement des données depuis currentUser:", currentUser);
      setForm({
        prenom: currentUser.prenom || "",
        nom: currentUser.nom || "",
        email: currentUser.email || "",
        telephone: currentUser.telephone || "",
        poste: currentUser.poste || "",
        departement: currentUser.departement || "",
      });
      
      const photoUrl = currentUser.photoUrl || currentUser.photo;
      if (photoUrl) {
        const fullUrl = photoUrl.startsWith("http") 
          ? photoUrl 
          : `${API_BASE}${photoUrl.startsWith("/") ? "" : "/"}${photoUrl}`;
        setSavedPhotoUrl(`${fullUrl}?_=${Date.now()}`);
      }
    }
  }, [currentUser]);

  // Sauvegarder les informations
  const saveInfo = async () => {
    setSavingInfo(true);
    try {
      const token = localStorage.getItem("token");
      if (!token) {
        showToast("Vous n'êtes pas connecté", "error");
        return;
      }

      const updateData = {
        prenom: form.prenom,
        nom: form.nom,
        telephone: form.telephone,
        poste: form.poste,
        departement: form.departement,
      };

      const response = await fetch(`${API_BASE}/api/recruteur/profil`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify(updateData),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Erreur lors de la mise à jour");
      }

      if (refreshUser) {
        await refreshUser();
      }

      showToast("Profil mis à jour avec succès !");
    } catch (err) {
      console.error("Erreur saveInfo:", err);
      showToast(err.message || "Erreur lors de la mise à jour", "error");
    } finally {
      setSavingInfo(false);
    }
  };

  // Changer le mot de passe
  const savePw = async () => {
    if (!pw.current) {
      showToast("Mot de passe actuel requis", "error");
      return;
    }
    if (pw.next.length < 8) {
      showToast("8 caractères minimum", "error");
      return;
    }
    if (!/[A-Z]/.test(pw.next)) {
      showToast("1 lettre majuscule requise", "error");
      return;
    }
    if (!/[0-9]/.test(pw.next)) {
      showToast("1 chiffre requis", "error");
      return;
    }
    if (!/[^A-Za-z0-9]/.test(pw.next)) {
      showToast("1 caractère spécial requis (!@#)", "error");
      return;
    }
    if (pw.next !== pw.confirm) {
      showToast("Les mots de passe ne correspondent pas", "error");
      return;
    }
    
    setSavingPw(true);
    try {
      const token = localStorage.getItem("token");
      if (!token) {
        showToast("Vous n'êtes pas connecté", "error");
        return;
      }

      const response = await fetch(`${API_BASE}/api/recruteur/change-password`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({ 
          currentPassword: pw.current, 
          newPassword: pw.next 
        }),
      });

      if (!response.ok) {
        let errorMessage = "Erreur lors du changement";
        try {
          const error = await response.json();
          errorMessage = error.message || error.error || errorMessage;
        } catch (e) {
          errorMessage = `Erreur ${response.status}: ${response.statusText}`;
        }
        throw new Error(errorMessage);
      }

      showToast("Mot de passe modifié avec succès !");
      setPw({ current: "", next: "", confirm: "" });
    } catch (err) {
      console.error("Erreur change password:", err);
      if (err.message.includes("current") || err.message.toLowerCase().includes("actuel")) {
        showToast("Mot de passe actuel incorrect", "error");
      } else {
        showToast(err.message || "Erreur lors du changement de mot de passe", "error");
      }
    } finally {
      setSavingPw(false);
    }
  };

  const initials = ((form.prenom?.[0] || "?") + (form.nom?.[0] || "")).toUpperCase();
  const pwMatch = pw.confirm.length > 0 ? pw.next === pw.confirm : null;

  if (loading) {
    return (
      <div style={{ display: "flex", justifyContent: "center", alignItems: "center", height: "60vh" }}>
        <div style={{ textAlign: "center" }}>
          <div style={{
            width: 32, height: 32, border: "3px solid #E2E8F0",
            borderTopColor: "#003DA5", borderRadius: "50%",
            animation: "spin .8s linear infinite", margin: "0 auto 16px"
          }} />
          <p>Chargement du profil...</p>
        </div>
      </div>
    );
  }

  if (!currentUser) {
    return (
      <div style={{ maxWidth: 680, margin: "0 auto", padding: "36px 20px", textAlign: "center" }}>
        <div style={{
          background: "#FEF2F2", border: "1px solid #FEE2E2",
          borderRadius: 12, padding: 24, color: "#DC2626"
        }}>
          <h3>⚠️ Utilisateur non connecté</h3>
          <p>Veuillez vous connecter pour accéder à votre profil.</p>
        </div>
      </div>
    );
  }

  return (
    <div style={{ maxWidth: 680, margin: "0 auto", padding: "36px 20px", fontFamily: "var(--font-sans)" }}>
      <style>{`
        @keyframes spin { to { transform: rotate(360deg) } }
        @keyframes slideUp { from { opacity:0; transform:translateY(12px) } to { opacity:1; transform:translateY(0) } }
      `}</style>

      {/* Hero Section */}
      <div style={{
        background: "linear-gradient(130deg,#003DA5 0%,#1a56db 55%,#2563EB 100%)",
        borderRadius: 20, padding: "28px 32px",
        display: "flex", alignItems: "center", gap: 22,
        marginBottom: 24, boxShadow: "0 8px 32px rgba(0,61,165,0.28)",
        position: "relative", overflow: "hidden",
      }}>
        <div style={{
          position: "absolute", right: -30, top: -30,
          width: 160, height: 160, borderRadius: "50%",
          background: "rgba(255,255,255,0.06)"
        }} />
        <div style={{
          width: 72, height: 72, borderRadius: "50%", flexShrink: 0,
          background: "rgba(255,255,255,0.18)", border: "2.5px solid rgba(255,255,255,0.5)",
          overflow: "hidden", display: "flex", alignItems: "center", justifyContent: "center",
          position: "relative", zIndex: 1,
        }}>
          {savedPhotoUrl ? (
            <img src={savedPhotoUrl} alt="Photo de profil" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
          ) : (
            <span style={{ fontSize: 26, fontWeight: 800, color: "white", fontFamily: "var(--font-serif)" }}>
              {initials}
            </span>
          )}
        </div>
        <div style={{ position: "relative", zIndex: 1 }}>
          <div style={{
            fontSize: 10, fontWeight: 700, letterSpacing: "2px",
            textTransform: "uppercase", color: "rgba(255,255,255,0.5)", marginBottom: 5
          }}>
            {t("profil.recruteur") || "RECRUTEUR"}
          </div>
          <div style={{
            fontSize: 22, fontWeight: 800, color: "white",
            fontFamily: "var(--font-serif)", lineHeight: 1.1
          }}>
            {form.prenom} {form.nom}
          </div>
          <div style={{ fontSize: 13, color: "rgba(255,255,255,0.65)", marginTop: 4 }}>
            {form.email}{form.departement && ` · ${form.departement}`}
          </div>
        </div>
      </div>

      {/* Profile Info Section */}
      <SectionCard title={t("profil.titre") || "Informations personnelles"} icon="👤">
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 16 }}>
          <Field label={t("profil.prenom") || "Prénom"}>
            <TextInput value={form.prenom} onChange={e => setForm(f => ({ ...f, prenom: e.target.value }))} />
          </Field>
          <Field label={t("profil.nom") || "Nom"}>
            <TextInput value={form.nom} onChange={e => setForm(f => ({ ...f, nom: e.target.value }))} />
          </Field>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 16 }}>
          <Field label={t("profil.telephone") || "Téléphone"}>
            <TextInput
              value={form.telephone}
              onChange={e => setForm(f => ({ ...f, telephone: e.target.value }))}
              type="tel"
              placeholder="+216 XX XXX XXX"
            />
          </Field>
          <Field label={t("profil.poste") || "Poste"}>
            <TextInput value={form.poste} onChange={e => setForm(f => ({ ...f, poste: e.target.value }))} />
          </Field>
        </div>
        <div style={{ marginBottom: 24 }}>
          <Field label={t("profil.emailNonModifiable") || "Email (non modifiable)"}>
            <TextInput value={form.email} readOnly />
          </Field>
        </div>
        {form.departement && (
          <div style={{ marginBottom: 24 }}>
            <Field label={t("profil.departementNonModifiable") || "Département (non modifiable)"}>
              <TextInput value={form.departement} readOnly />
            </Field>
          </div>
        )}
        <div style={{ display: "flex", justifyContent: "flex-end" }}>
          <button
            onClick={saveInfo}
            disabled={savingInfo}
            style={{
              padding: "10px 28px", borderRadius: 10, border: "none",
              background: savingInfo ? "#E2E8F0" : "#003DA5",
              color: savingInfo ? "#94A3B8" : "white",
              fontWeight: 700, fontSize: 14,
              cursor: savingInfo ? "not-allowed" : "pointer",
              display: "flex", alignItems: "center", gap: 8,
            }}
          >
            {savingInfo ? "Enregistrement..." : (t("profil.enregistrerModifications") || "Enregistrer")}
          </button>
        </div>
      </SectionCard>

      {/* Password Section */}
      <SectionCard title={t("profil.changerMotDePasse") || "Changer le mot de passe"} icon="🔒">
        <div style={{ marginBottom: 16 }}>
          <Field label={t("profil.motDePasseActuel") || "Mot de passe actuel"}>
            <PwInput
              value={pw.current}
              onChange={e => setPw(p => ({ ...p, current: e.target.value }))}
              placeholder="••••••••"
              disabled={savingPw}
            />
          </Field>
        </div>
        <div style={{ height: 1, background: "#EEF2FF", margin: "20px 0" }} />
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 8 }}>
          <div>
            <Field label={t("profil.nouveauMotDePasse") || "Nouveau mot de passe"}>
              <PwInput
                value={pw.next}
                onChange={e => setPw(p => ({ ...p, next: e.target.value }))}
                placeholder="••••••••"
                disabled={savingPw}
              />
            </Field>
            <PasswordStrength value={pw.next} />
          </div>
          <div>
            <Field label={t("profil.confirmerMotDePasse") || "Confirmer le mot de passe"}>
              <PwInput
                value={pw.confirm}
                onChange={e => setPw(p => ({ ...p, confirm: e.target.value }))}
                placeholder="••••••••"
                disabled={savingPw}
              />
            </Field>
            {pwMatch !== null && (
              <div style={{
                marginTop: 8, fontSize: 11, fontWeight: 600,
                color: pwMatch ? "#1D9E75" : "#E24B4A",
                display: "flex", alignItems: "center", gap: 5
              }}>
                <span style={{
                  width: 6, height: 6, borderRadius: "50%",
                  background: pwMatch ? "#1D9E75" : "#E24B4A", display: "inline-block"
                }} />
                {pwMatch ? "✅ Les mots de passe correspondent" : "❌ Les mots de passe ne correspondent pas"}
              </div>
            )}
          </div>
        </div>

        <div style={{
          background: "#F8FAFF", borderRadius: 10, padding: "12px 16px",
          border: "1px solid #E8EEFF", marginBottom: 20, marginTop: 12
        }}>
          <div style={{
            fontSize: 11, fontWeight: 700, color: "#64748B", marginBottom: 6,
            textTransform: "uppercase", letterSpacing: ".6px"
          }}>
            {t("profil.reglesSecurite") || "Règles de sécurité"}
          </div>
          <div style={{ display: "flex", flexWrap: "wrap", gap: "4px 16px" }}>
            {[
              { ok: pw.next.length >= 8, label: "8 caractères min" },
              { ok: /[A-Z]/.test(pw.next), label: "1 majuscule" },
              { ok: /[0-9]/.test(pw.next), label: "1 chiffre" },
              { ok: /[^A-Za-z0-9]/.test(pw.next), label: "1 spécial !@#" },
            ].map((r, i) => (
              <span key={i} style={{
                fontSize: 11, color: r.ok ? "#1D9E75" : "#94A3B8",
                fontWeight: 600, display: "flex", alignItems: "center", gap: 4
              }}>
                <span style={{
                  width: 6, height: 6, borderRadius: "50%",
                  background: r.ok ? "#1D9E75" : "#CBD5E1", display: "inline-block"
                }} />
                {r.label}
              </span>
            ))}
          </div>
        </div>

        <div style={{ display: "flex", justifyContent: "flex-end" }}>
          <button
            onClick={savePw}
            disabled={savingPw || !pw.current || !pw.next || !pw.confirm}
            style={{
              padding: "10px 28px", borderRadius: 10, border: "none",
              background: (savingPw || !pw.current || !pw.next || !pw.confirm) ? "#E2E8F0" : "#003DA5",
              color: (savingPw || !pw.current || !pw.next || !pw.confirm) ? "#94A3B8" : "white",
              fontWeight: 700, fontSize: 14,
              cursor: (savingPw || !pw.current || !pw.next || !pw.confirm) ? "not-allowed" : "pointer",
            }}
          >
            {savingPw ? "Modification..." : (t("profil.changerMotDePasse") || "Changer le mot de passe")}
          </button>
        </div>
      </SectionCard>

      <Toast msg={toast?.msg} type={toast?.type} />
    </div>
  );
}