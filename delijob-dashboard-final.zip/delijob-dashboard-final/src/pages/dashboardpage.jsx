import { useState }    from "react";
import DashLayout      from "../components/dashlayout.jsx";
import DashboardHome   from "./dashboardhome.jsx";
import OffresPage      from "./offrespage.jsx";
import CandidatsPage   from "./candidatspage.jsx";
import EntretienPage   from "./entretienpage.jsx";
import AlertesPage     from "./alertespage.jsx";
import ProfilPage      from "./profilpage.jsx";
import MessageriePage  from "./Messageriepage.jsx";
import ArchivePage     from "./archivepage.jsx";
import ParametresPage  from "./parametres.jsx";

function renderPage(activePage) {
  if (activePage === "dashboard")  return <DashboardHome />;
  if (activePage === "offres")     return <OffresPage />;
  if (activePage === "candidats")  return <CandidatsPage />;
  if (activePage === "entretien")  return <EntretienPage />;
  if (activePage === "alertes")    return <AlertesPage />;
  if (activePage === "profil")     return <ProfilPage />;
  if (activePage === "messagerie") return <MessageriePage />;
  if (activePage === "archive")    return <ArchivePage />;
  if (activePage === "parametres") return <ParametresPage />;
  return <DashboardHome />;
}

export default function DashboardPage() {
  const [activePage, setActivePage] = useState("dashboard");

  return (
    <DashLayout activePage={activePage} onNavigate={setActivePage}>
      {renderPage(activePage)}
    </DashLayout>
  );
}