import { useState, useEffect, useCallback, useRef } from "react";
import Logo    from "../components/logo.jsx";
import { useApp } from "../context/appcontext.jsx";
import { MessagerieTab } from "./adminmessagerie.jsx";
import { useTheme } from "../components/theme-provider.jsx";
import { useI18n } from "../i18n/i18nContext.jsx";
const API_BASE = "http://localhost:8080";

function authHeaders() {
  const token = localStorage.getItem("token");
  return {
    "Content-Type": "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
}

const LEFT_BAR = { PENDING:"#F59E0B", APPROVED:"#22C55E", REJECTED:"#EF4444" };
const TH_STYLE = {
  padding:"11px 18px", textAlign:"left",
  fontSize:11, fontWeight:700,
  color:"var(--text-muted)",
  textTransform:"uppercase", letterSpacing:"0.8px",
  whiteSpace:"nowrap",
};

const AVATAR_COLORS = ["#003DA5","#7C3AED","#0891B2","#059669","#DC2626","#D97706","#0F766E","#9333EA"];

const LANG_OPTIONS = [
  { code: "fr", label: "Français", flag: "🇫🇷" },
  { code: "en", label: "English",  flag: "🇬🇧" },
  { code: "ar", label: "العربية",  flag: "🇹🇳" },
];

// ── LANGUAGE SWITCHER ─────────────────────────────────────────────────────────
function LanguageSwitcher() {
  const { langue, setLangue } = useI18n();
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    function handleClick(e) {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    }
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, []);

  const current = LANG_OPTIONS.find(l => l.code === langue) || LANG_OPTIONS[0];

  return (
    <div ref={ref} style={{ position: "relative" }}>
      <button
        onClick={() => setOpen(o => !o)}
        title="Changer la langue / Change language / تغيير اللغة"
        style={{
          display: "flex", alignItems: "center", gap: 6,
          padding: "6px 12px", borderRadius: 9,
          border: `1px solid ${open ? "#003DA5" : "var(--border-color)"}`,
          background: open ? "#EEF2FF" : "var(--bg-card)",
          cursor: "pointer", fontSize: 13, fontWeight: 600,
          color: open ? "#003DA5" : "var(--text-secondary)",
          transition: "all .15s", fontFamily: "var(--font-sans)",
        }}
        onMouseEnter={e => { if (!open) { e.currentTarget.style.borderColor="#003DA5"; e.currentTarget.style.color="#003DA5"; }}}
        onMouseLeave={e => { if (!open) { e.currentTarget.style.borderColor="var(--border-color)"; e.currentTarget.style.color="var(--text-secondary)"; }}}
      >
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
          stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ flexShrink:0 }}>
          <circle cx="12" cy="12" r="10"/>
          <line x1="2" y1="12" x2="22" y2="12"/>
          <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>
        </svg>
        <span style={{ fontSize:14 }}>{current.flag}</span>
        <span style={{ fontSize:12 }}>{current.label}</span>
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none"
          stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"
          style={{ transition:"transform .2s", transform: open ? "rotate(180deg)" : "rotate(0deg)" }}>
          <polyline points="6 9 12 15 18 9"/>
        </svg>
      </button>

      {open && (
        <div style={{
          position:"absolute", top:"calc(100% + 8px)", right:0,
          minWidth:160, background:"var(--bg-card)",
          border:"1px solid var(--border-color)", borderRadius:12,
          boxShadow:"0 8px 24px rgba(0,0,0,0.12)", zIndex:500,
          overflow:"hidden", padding:"4px",
        }}>
          {LANG_OPTIONS.map(opt => {
            const isActive = opt.code === langue;
            return (
              <button key={opt.code} onClick={() => { setLangue(opt.code); setOpen(false); }}
                style={{
                  display:"flex", alignItems:"center", gap:10,
                  width:"100%", padding:"9px 12px", borderRadius:8, border:"none",
                  background: isActive ? "#EEF2FF" : "transparent",
                  color: isActive ? "#003DA5" : "var(--text-primary)",
                  fontSize:13, fontWeight: isActive ? 700 : 500,
                  cursor:"pointer", textAlign:"left", transition:"background .12s",
                  fontFamily:"var(--font-sans)",
                }}
                onMouseEnter={e => { if (!isActive) e.currentTarget.style.background="var(--bg-secondary)"; }}
                onMouseLeave={e => { if (!isActive) e.currentTarget.style.background="transparent"; }}
              >
                <span style={{ fontSize:18 }}>{opt.flag}</span>
                <span>{opt.label}</span>
                {isActive && (
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
                    stroke="#003DA5" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"
                    style={{ marginLeft:"auto" }}>
                    <polyline points="20 6 9 17 4 12"/>
                  </svg>
                )}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}

function ThemeSwitch() {
  const { theme, setTheme } = useTheme();
  const { t } = useI18n();
  const [isDark, setIsDark] = useState(theme === "dark" || (theme === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches));

  useEffect(() => {
    const isDarkMode = theme === "dark" || (theme === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches);
    setIsDark(isDarkMode);
  }, [theme]);

  const toggleTheme = () => { if (isDark) setTheme("light"); else setTheme("dark"); };

  return (
    <div className="flex items-center space-x-2" style={{ marginLeft:"20px" }}>
      <button onClick={toggleTheme} style={{
        position:"relative", width:"52px", height:"28px", borderRadius:"14px",
        background: isDark ? "#1e293b" : "#e2e8f0", border:"none", cursor:"pointer",
        transition:"all 0.3s ease", boxShadow:"inset 0 1px 3px rgba(0,0,0,0.2)"
      }}>
        <div style={{
          position:"absolute", top:"2px", left: isDark ? "26px" : "2px",
          width:"24px", height:"24px", borderRadius:"12px", background:"white",
          transition:"left 0.3s ease", display:"flex", alignItems:"center",
          justifyContent:"center", fontSize:"12px", boxShadow:"0 1px 3px rgba(0,0,0,0.2)"
        }}>
          {isDark ? "🌙" : "☀️"}
        </div>
      </button>
      <span style={{ fontSize:"12px", color:"var(--text-secondary)", fontWeight:500 }}>
        {isDark ? t("parametres.sombre") : t("parametres.clair")}
      </span>
    </div>
  );
}

function Avatar({ initials, size=38, bg="#003DA5" }) {
  return (
    <div style={{
      width:size, height:size, borderRadius:"50%",
      background:`linear-gradient(135deg, ${bg} 0%, #1a56db 100%)`,
      display:"flex", alignItems:"center", justifyContent:"center",
      fontWeight:700, fontSize:size*0.35, color:"white",
      fontFamily:"var(--font-serif)", flexShrink:0,
      boxShadow:`0 2px 8px ${bg}44`,
    }}>{initials}</div>
  );
}

function StatusPill({ status }) {
  const { t } = useI18n();
  const STATUS_CFG = {
    PENDING:  { label: t("admin.enAttente"), dot:"#F59E0B", bg:"#FFF7ED", text:"#92650A", border:"#FED7AA" },
    APPROVED: { label: t("admin.approuves"), dot:"#22C55E", bg:"#F0FDF4", text:"#166534", border:"#BBF7D0" },
    REJECTED: { label: t("admin.refuses"),   dot:"#EF4444", bg:"#FEF2F2", text:"#991B1B", border:"#FECACA" },
  };
  const c = STATUS_CFG[status] || STATUS_CFG.PENDING;
  return (
    <span style={{
      display:"inline-flex", alignItems:"center", gap:6,
      padding:"4px 12px", borderRadius:100,
      background:c.bg, color:c.text, border:`1px solid ${c.border}`,
      fontSize:11, fontWeight:700,
    }}>
      <span style={{ width:6, height:6, borderRadius:"50%", background:c.dot }}/>
      {c.label}
    </span>
  );
}

function InlineBtn({ label, bg, color, hoverBg, onClick, disabled }) {
  return (
    <button onClick={onClick} disabled={disabled}
      onMouseEnter={e=>{ if(!disabled){ e.currentTarget.style.background=hoverBg; e.currentTarget.style.color="white"; }}}
      onMouseLeave={e=>{ if(!disabled){ e.currentTarget.style.background=bg; e.currentTarget.style.color=color; }}}
      style={{
        padding:"5px 13px", borderRadius:8,
        background:bg, color, border:`1px solid ${color}44`,
        fontSize:12, fontWeight:600, cursor:disabled?"not-allowed":"pointer",
        transition:"all .15s", opacity:disabled?0.5:1,
      }}
    >{label}</button>
  );
}

function KpiCard({ num, label, icon, color, bg }) {
  return (
    <div style={{
      background:"var(--bg-card)", borderRadius:16, padding:"22px 20px",
      border:"1px solid var(--border-color)", boxShadow:"0 2px 12px rgba(0,61,165,0.06)",
      display:"flex", alignItems:"center", gap:16,
      transition:"box-shadow .2s, transform .2s",
    }}
      onMouseEnter={e=>{ e.currentTarget.style.boxShadow="0 8px 28px rgba(0,61,165,0.14)"; e.currentTarget.style.transform="translateY(-2px)"; }}
      onMouseLeave={e=>{ e.currentTarget.style.boxShadow="0 2px 12px rgba(0,61,165,0.06)"; e.currentTarget.style.transform="translateY(0)"; }}
    >
      <div style={{ width:50, height:50, borderRadius:14, background:bg, display:"flex", alignItems:"center", justifyContent:"center", fontSize:22, flexShrink:0 }}>{icon}</div>
      <div>
        <div style={{ fontSize:30, fontWeight:800, fontFamily:"var(--font-serif)", color, lineHeight:1 }}>{num}</div>
        <div style={{ fontSize:11, color:"var(--text-muted)", fontWeight:600, marginTop:4, textTransform:"uppercase", letterSpacing:"0.8px" }}>{label}</div>
      </div>
    </div>
  );
}

// ── TAB 1 — INSCRIPTIONS ──────────────────────────────────────────────────────
function InscriptionsTab({ users, updateStatus, loading }) {
  const { t } = useI18n();
  const [filter, setFilter] = useState("Tous");
  const pending  = users.filter(r => r.status === "PENDING").length;
  const approved = users.filter(r => r.status === "APPROVED").length;
  const rejected = users.filter(r => r.status === "REJECTED").length;

  const filtered = filter === "Tous"     ? users
    : filter === "PENDING"  ? users.filter(r => r.status === "PENDING")
    : filter === "APPROVED" ? users.filter(r => r.status === "APPROVED")
    : users.filter(r => r.status === "REJECTED");

  const sorted = [...filtered].sort((a,b) => {
    const O = { PENDING:0, APPROVED:1, REJECTED:2 };
    return O[a.status] - O[b.status];
  });

  const filterOptions = [
    { val:"Tous",     lbl: t("admin.toutesDemandesTotal") },
    { val:"PENDING",  lbl: t("admin.enAttente") },
    { val:"APPROVED", lbl: t("admin.approuves") },
    { val:"REJECTED", lbl: t("admin.refuses") },
  ];

  return (
    <div>
      <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:16, marginBottom:24 }}>
        <KpiCard num={pending}  label={t("admin.enAttente")} icon="⏳" color="#F59E0B" bg="#FFF7ED" />
        <KpiCard num={approved} label={t("admin.approuves")} icon="✅" color="#22C55E" bg="#F0FDF4" />
        <KpiCard num={rejected} label={t("admin.refuses")}   icon="❌" color="#EF4444" bg="#FEF2F2" />
      </div>

      <div style={{ background:"var(--bg-card)", borderRadius:16, border:"1px solid var(--border-color)", boxShadow:"0 2px 12px rgba(0,61,165,0.06)", overflow:"hidden" }}>
        <div style={{ padding:"16px 24px", borderBottom:"1px solid var(--border-color)", display:"flex", alignItems:"center", justifyContent:"space-between", flexWrap:"wrap", gap:12 }}>
          <div style={{ display:"flex", alignItems:"center", gap:10 }}>
            <span style={{ fontSize:15, fontWeight:700, color:"var(--text-primary)" }}>{t("admin.toutesDemandesTotal")}</span>
            <span style={{ background:"var(--bg-secondary)", color:"#3730A3", padding:"2px 10px", borderRadius:100, fontSize:12, fontWeight:700 }}>{users.length}</span>
          </div>
          <div style={{ display:"flex", gap:6 }}>
            {filterOptions.map(({ val, lbl }) => (
              <button key={val} onClick={()=>setFilter(val)} style={{
                padding:"5px 14px", borderRadius:100, fontSize:12, fontWeight:600,
                border:`1.5px solid ${filter===val ? "#003DA5" : "var(--border-color)"}`,
                background:filter===val ? "#003DA5" : "var(--bg-card)",
                color:filter===val ? "white" : "var(--text-secondary)",
                cursor:"pointer", transition:"all .15s",
              }}>{lbl}</button>
            ))}
          </div>
        </div>

        <div style={{ overflowX:"auto" }}>
          {loading ? (
            <div style={{ textAlign:"center", padding:"60px", color:"var(--text-muted)" }}>
              <div style={{ fontSize:32, marginBottom:10 }}>⏳</div>{t("common.chargement")}
            </div>
          ) : (
            <table style={{ width:"100%", borderCollapse:"collapse" }}>
              <thead>
                <tr style={{ background:"var(--bg-secondary)", borderBottom:"2px solid var(--border-color)" }}>
                  <th style={{ width:4, padding:0 }}/>
                  <th style={{ width:52, padding:0 }}/>
                  {[t("candidats.nom"), t("offres.departement"), t("offres.statut"), t("offres.actions")].map(h=>(
                    <th key={h} style={TH_STYLE}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {sorted.length === 0 ? (
                  <tr>
                    <td colSpan={6} style={{ textAlign:"center", padding:"60px", color:"var(--text-muted)" }}>
                      <div style={{ fontSize:40, marginBottom:10 }}>📭</div>
                      {t("admin.aucuneTrouvee")}
                    </td>
                  </tr>
                ) : (
                  sorted.map(r => {
                    const isPending = r.status === "PENDING";
                    const initials  = ((r.prenom?.[0] || "?") + (r.nom?.[0] || "?")).toUpperCase();
                    return (
                      <tr key={r.id}
                        style={{ borderBottom:"1px solid var(--border-color)" }}
                        onMouseEnter={e=>e.currentTarget.style.background="var(--bg-secondary)"}
                        onMouseLeave={e=>e.currentTarget.style.background="transparent"}
                      >
                        <td style={{ width:4, padding:0, background:LEFT_BAR[r.status] }}/>
                        <td style={{ padding:"13px 12px 13px 20px" }}><Avatar initials={initials} size={38} /></td>
                        <td style={{ padding:"13px 0" }}>
                          <div style={{ fontSize:14, fontWeight:600, color:"var(--text-primary)" }}>{r.prenom} {r.nom}</div>
                          <div style={{ fontSize:12, color:"var(--text-muted)", marginTop:2 }}>{r.email}</div>
                        </td>
                        <td style={{ padding:"13px 18px" }}>
                          <span style={{ fontSize:11, fontWeight:600, padding:"4px 12px", borderRadius:100, background:"var(--bg-secondary)", color:"#3730A3", whiteSpace:"nowrap" }}>{r.departement}</span>
                        </td>
                        <td style={{ padding:"13px 18px" }}><StatusPill status={r.status}/></td>
                        <td style={{ padding:"13px 24px 13px 12px", textAlign:"right" }}>
                          {isPending ? (
                            <div style={{ display:"flex", gap:8, justifyContent:"flex-end" }}>
                              <InlineBtn label={t("admin.approuver")} bg="#F0FDF4" color="#16a34a" hoverBg="#16a34a" onClick={()=>updateStatus(r.id,"APPROVED")}/>
                              <InlineBtn label={t("admin.refuser")}   bg="#FEF2F2" color="#C0392B" hoverBg="#C0392B" onClick={()=>updateStatus(r.id,"REJECTED")}/>
                            </div>
                          ) : (
                            <span style={{ fontSize:12, color:"var(--text-muted)", fontStyle:"italic" }}>
                              {r.status === "APPROVED" ? t("admin.accesAccorde") : t("admin.accesRefuse")}
                            </span>
                          )}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          )}
        </div>

        <div style={{ padding:"12px 24px", borderTop:"1px solid var(--border-color)", fontSize:12, color:"var(--text-muted)", display:"flex", justifyContent:"space-between", background:"var(--bg-secondary)" }}>
          <span>{users.length} {t("admin.toutesDemandesTotal").toLowerCase()}</span>
          <div style={{ display:"flex", gap:14 }}>
            <span style={{ color:"#22C55E", fontWeight:600 }}>● {approved} {t("admin.approuves")}</span>
            <span style={{ color:"#F59E0B", fontWeight:600 }}>● {pending} {t("admin.enAttente")}</span>
            <span style={{ color:"#EF4444", fontWeight:600 }}>● {rejected} {t("admin.refuses")}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── TAB 2 — RECRUTEURS ───────────────────────────────────────────────────────
function RecruteursTab({ users, updateStatus, loading, addNotif }) {
  const { t } = useI18n();
  const [search,   setSearch]   = useState("");
  const [deptFilt, setDeptFilt] = useState("Tous");
  const [viewFilt, setViewFilt] = useState("actifs");
  const [confirm,  setConfirm]  = useState(null);

  const recruiters = users.filter(r => r.status === "APPROVED" || r.status === "REJECTED");
  const active     = recruiters.filter(r => r.status === "APPROVED");
  const suspended  = recruiters.filter(r => r.status === "REJECTED");

  const depts = ["Tous", ...new Set(recruiters.map(r => r.departement).filter(Boolean))];

  const pool = viewFilt === "actifs"    ? active
             : viewFilt === "suspendus" ? suspended
             : recruiters;

  const filtered = pool.filter(r => {
    const matchDept   = deptFilt === "Tous" || r.departement === deptFilt;
    const matchSearch = (r.prenom+" "+r.nom+" "+r.email).toLowerCase().includes(search.toLowerCase());
    return matchDept && matchSearch;
  });

  function openConfirm(id, action) { setConfirm({ id, action }); }

  function confirmAction() {
    const newStatus = confirm.action === "suspend" ? "REJECTED" : "APPROVED";
    const user = users.find(u => u.id === confirm.id);
    updateStatus(confirm.id, newStatus);
    if (user && addNotif) {
      const notifMsgs = {
        suspend:    { titre: t("admin.suspendre"),  message:`${user.prenom} ${user.nom} (${user.departement})` },
        reactivate: { titre: t("admin.reactiver"),  message:`${user.prenom} ${user.nom} (${user.departement})` },
      };
      addNotif({ type:"validation", ...notifMsgs[confirm.action] });
    }
    setConfirm(null);
  }

  const isSuspendModal = confirm?.action === "suspend";

  const viewOptions = [
    { val:"actifs",    lbl: t("admin.actif"),    count: active.length },
    { val:"suspendus", lbl: t("admin.suspendu"), count: suspended.length },
    { val:"tous",      lbl: t("admin.toutesDemandesTotal"), count: recruiters.length },
  ];

  return (
    <div>
      <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:16, marginBottom:24 }}>
        <KpiCard num={active.length}    label={t("admin.recruteursActifs")} icon="👥" color="#003DA5" bg="#EEF2FF" />
        <KpiCard num={new Set(active.map(r=>r.departement)).size} label={t("admin.departements")} icon="🏢" color="#7C3AED" bg="#F5F3FF" />
        <KpiCard num={suspended.length} label={t("admin.suspendus")}       icon="🔒" color="#EF4444" bg="#FEF2F2" />
      </div>

      <div style={{ background:"var(--bg-card)", borderRadius:16, border:"1px solid var(--border-color)", boxShadow:"0 2px 12px rgba(0,61,165,0.06)", overflow:"hidden" }}>
        <div style={{ padding:"16px 24px", borderBottom:"1px solid var(--border-color)", display:"flex", alignItems:"center", justifyContent:"space-between", flexWrap:"wrap", gap:12 }}>
          <div style={{ display:"flex", alignItems:"center", gap:10 }}>
            <span style={{ fontSize:15, fontWeight:700, color:"var(--text-primary)" }}>{t("admin.gestionRecruteurs")}</span>
            <span style={{ background:"var(--bg-secondary)", color:"#3730A3", padding:"2px 10px", borderRadius:100, fontSize:12, fontWeight:700 }}>{recruiters.length}</span>
          </div>
          <div style={{ display:"flex", gap:6 }}>
            {viewOptions.map(({ val, lbl, count }) => (
              <button key={val} onClick={()=>setViewFilt(val)} style={{
                padding:"5px 14px", borderRadius:100, fontSize:12, fontWeight:600,
                border:`1.5px solid ${viewFilt===val ? "#003DA5" : "var(--border-color)"}`,
                background:viewFilt===val ? "#003DA5" : "var(--bg-card)",
                color:viewFilt===val ? "white" : "var(--text-secondary)",
                cursor:"pointer", transition:"all .15s",
                display:"flex", alignItems:"center", gap:6,
              }}>
                {lbl}
                <span style={{ background: viewFilt===val ? "rgba(255,255,255,0.25)" : "var(--bg-secondary)", color: viewFilt===val ? "white" : "#3730A3", borderRadius:100, padding:"1px 7px", fontSize:11, fontWeight:700 }}>{count}</span>
              </button>
            ))}
          </div>
          <div style={{ display:"flex", gap:10, alignItems:"center", flexWrap:"wrap" }}>
            <input value={search} onChange={e=>setSearch(e.target.value)} placeholder={t("admin.rechercherRecruteur")}
              style={{ padding:"7px 14px", borderRadius:9, border:"1.5px solid var(--border-color)", fontSize:13, fontFamily:"var(--font-sans)", outline:"none", width:210, background:"var(--bg-card)", color:"var(--text-primary)" }}
              onFocus={e=>e.target.style.borderColor="#003DA5"}
              onBlur={e=>e.target.style.borderColor="var(--border-color)"}
            />
            <select value={deptFilt} onChange={e=>setDeptFilt(e.target.value)}
              style={{ padding:"7px 12px", borderRadius:9, border:"1.5px solid var(--border-color)", fontSize:13, fontFamily:"var(--font-sans)", outline:"none", background:"var(--bg-card)", color:"var(--text-primary)" }}>
              {depts.map(d=><option key={d}>{d}</option>)}
            </select>
          </div>
        </div>

        <div style={{ overflowX:"auto" }}>
          {loading ? (
            <div style={{ textAlign:"center", padding:"60px", color:"var(--text-muted)" }}>⏳ {t("common.chargement")}</div>
          ) : (
            <table style={{ width:"100%", borderCollapse:"collapse" }}>
              <thead>
                <tr style={{ background:"var(--bg-secondary)", borderBottom:"2px solid var(--border-color)" }}>
                  <th style={TH_STYLE}></th>
                  <th style={TH_STYLE}>{t("admin.recruteurs")}</th>
                  <th style={TH_STYLE}>{t("offres.departement")}</th>
                  <th style={TH_STYLE}>{t("profil.email")}</th>
                  <th style={TH_STYLE}>{t("offres.statut")}</th>
                  <th style={TH_STYLE}>{t("offres.actions")}</th>
                </tr>
              </thead>
              <tbody>
                {filtered.length === 0 ? (
                  <tr>
                    <td colSpan={6} style={{ textAlign:"center", padding:"60px", color:"var(--text-muted)" }}>
                      <div style={{ fontSize:40, marginBottom:10 }}>🔍</div>{t("admin.aucuneTrouvee")}
                    </td>
                  </tr>
                ) : (
                  filtered.map((r, i) => {
                    const isActive = r.status === "APPROVED";
                    const initials = ((r.prenom?.[0]||"?")+(r.nom?.[0]||"?")).toUpperCase();
                    const avatarBg = isActive ? AVATAR_COLORS[i % AVATAR_COLORS.length] : "#94A3B8";
                    return (
                      <tr key={r.id}
                        style={{ borderBottom:"1px solid var(--border-color)", opacity: isActive ? 1 : 0.7 }}
                        onMouseEnter={e=>e.currentTarget.style.background="var(--bg-secondary)"}
                        onMouseLeave={e=>e.currentTarget.style.background="transparent"}
                      >
                        <td style={{ width:4, padding:0, background: isActive ? "#22C55E" : "#EF4444" }}/>
                        <td style={{ padding:"13px 12px 13px 20px", width:52 }}>
                          <Avatar initials={initials} size={38} bg={avatarBg} />
                        </td>
                        <td style={{ padding:"13px 0" }}>
                          <div style={{ fontSize:14, fontWeight:600, color:"var(--text-primary)" }}>{r.prenom} {r.nom}</div>
                          <div style={{ fontSize:11, color:"var(--text-muted)", marginTop:2 }}>ID #{String(r.id).padStart(4,"0")}</div>
                        </td>
                        <td style={{ padding:"13px 18px" }}>
                          <span style={{ fontSize:11, fontWeight:600, padding:"4px 12px", borderRadius:100, background:"var(--bg-secondary)", color:"#3730A3", whiteSpace:"nowrap" }}>{r.departement}</span>
                        </td>
                        <td style={{ padding:"13px 18px", fontSize:12, color:"var(--text-secondary)" }}>{r.email}</td>
                        <td style={{ padding:"13px 18px" }}>
                          {isActive ? (
                            <span style={{ display:"inline-flex", alignItems:"center", gap:6, padding:"4px 12px", borderRadius:100, background:"#F0FDF4", color:"#166534", border:"1px solid #BBF7D0", fontSize:11, fontWeight:700 }}>
                              <span style={{ width:6, height:6, borderRadius:"50%", background:"#22C55E" }}/>{t("admin.actif")}
                            </span>
                          ) : (
                            <span style={{ display:"inline-flex", alignItems:"center", gap:6, padding:"4px 12px", borderRadius:100, background:"#FEF2F2", color:"#991B1B", border:"1px solid #FECACA", fontSize:11, fontWeight:700 }}>
                              <span style={{ width:6, height:6, borderRadius:"50%", background:"#EF4444" }}/>{t("admin.suspendu")}
                            </span>
                          )}
                        </td>
                        <td style={{ padding:"13px 24px 13px 12px" }}>
                          {isActive ? (
                            <button onClick={() => openConfirm(r.id, "suspend")}
                              onMouseEnter={e=>{ e.currentTarget.style.background="#F59E0B"; e.currentTarget.style.color="white"; e.currentTarget.style.borderColor="#F59E0B"; }}
                              onMouseLeave={e=>{ e.currentTarget.style.background="#FFF7ED"; e.currentTarget.style.color="#92650A"; e.currentTarget.style.borderColor="#FED7AA"; }}
                              style={{ padding:"5px 12px", borderRadius:8, background:"#FFF7ED", border:"1px solid #FED7AA", fontSize:12, fontWeight:600, color:"#92650A", cursor:"pointer", transition:"all .15s" }}
                            >{t("admin.suspendre")}</button>
                          ) : (
                            <button onClick={() => openConfirm(r.id, "reactivate")}
                              onMouseEnter={e=>{ e.currentTarget.style.background="#16a34a"; e.currentTarget.style.color="white"; e.currentTarget.style.borderColor="#16a34a"; }}
                              onMouseLeave={e=>{ e.currentTarget.style.background="#F0FDF4"; e.currentTarget.style.color="#166534"; e.currentTarget.style.borderColor="#BBF7D0"; }}
                              style={{ padding:"5px 12px", borderRadius:8, background:"#F0FDF4", border:"1px solid #BBF7D0", fontSize:12, fontWeight:600, color:"#166534", cursor:"pointer", transition:"all .15s" }}
                            >{t("admin.reactiver")}</button>
                          )}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          )}
        </div>

        <div style={{ padding:"12px 24px", borderTop:"1px solid var(--border-color)", fontSize:12, color:"var(--text-muted)", background:"var(--bg-secondary)" }}>
          {filtered.length} {t("admin.recruteurs").toLowerCase()} · <span style={{ color:"#22C55E", fontWeight:600 }}>● {active.length} {t("admin.actif")}</span> · <span style={{ color:"#EF4444", fontWeight:600 }}>● {suspended.length} {t("admin.suspendu")}</span>
        </div>
      </div>

      {confirm && (
        <div style={{ position:"fixed", inset:0, zIndex:1000, background:"rgba(0,0,0,0.45)", backdropFilter:"blur(4px)", display:"flex", alignItems:"center", justifyContent:"center" }}>
          <div style={{ background:"var(--bg-card)", borderRadius:20, padding:"36px 40px", maxWidth:420, width:"100%", margin:"0 20px", boxShadow:"0 24px 60px rgba(0,0,0,0.2)" }}>
            <div style={{ fontSize:40, marginBottom:16, textAlign:"center" }}>{isSuspendModal ? "⚠️" : "✅"}</div>
            <h3 style={{ fontFamily:"var(--font-serif)", fontSize:20, fontWeight:800, color:"var(--text-primary)", marginBottom:8, textAlign:"center" }}>
              {isSuspendModal ? t("admin.suspendreConfirm") : t("admin.reactiverConfirm")}
            </h3>
            <p style={{ fontSize:13, color:"var(--text-secondary)", textAlign:"center", marginBottom:28, lineHeight:1.6 }}>
              {isSuspendModal ? t("admin.suspendreDesc") : t("admin.reactiverDesc")}
            </p>
            <div style={{ display:"flex", gap:12, justifyContent:"center" }}>
              <button onClick={()=>setConfirm(null)} style={{ padding:"10px 24px", borderRadius:10, border:"1.5px solid var(--border-color)", background:"var(--bg-card)", fontSize:13, fontWeight:600, color:"var(--text-secondary)", cursor:"pointer" }}>{t("admin.annuler")}</button>
              <button onClick={confirmAction} style={{ padding:"10px 24px", borderRadius:10, border:"none", background: isSuspendModal ? "#F59E0B" : "#16a34a", color:"white", fontSize:13, fontWeight:700, cursor:"pointer" }}>
                {isSuspendModal ? t("admin.suspendre") : t("admin.reactiver")}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ── MAIN PAGE ─────────────────────────────────────────────────────────────────
export default function AdminPage() {
  const { navigate, addNotif } = useApp();
  const { t } = useI18n();
  const [activeTab, setActiveTab] = useState("inscriptions");
  const [users,     setUsers]     = useState([]);
  const [loading,   setLoading]   = useState(true);
  const [error,     setError]     = useState(null);

  const fetchUsers = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const token = localStorage.getItem("token");
      if (!token) { navigate("login"); return; }

      const res = await fetch(`${API_BASE}/api/admin/users`, {
        headers: { "Content-Type": "application/json", "Authorization": `Bearer ${token}` }
      });

      if (res.status === 401) {
        localStorage.removeItem("token");
        localStorage.removeItem("role");
        navigate("login");
        return;
      }
      if (res.status === 403) {
        setError("Accès refusé (403). Vérifiez que votre compte a le rôle ADMIN.");
        setLoading(false);
        return;
      }
      if (!res.ok) throw new Error(`Erreur ${res.status}`);

      const data = await res.json();
      setUsers(Array.isArray(data) ? data : []);
    } catch (e) {
      setError(e.message || "Impossible de charger les données.");
    } finally {
      setLoading(false);
    }
  }, [navigate]);

  useEffect(() => { fetchUsers(); }, [fetchUsers]);

  async function updateStatus(id, newStatus) {
    try {
      const res = await fetch(`${API_BASE}/api/admin/users/${id}/status?status=${newStatus}`, {
        method:"PATCH", headers: authHeaders(),
      });
      if (!res.ok) throw new Error(`Erreur ${res.status}`);
      const user = users.find(u => u.id === id);
      setUsers(prev => prev.map(u => u.id === id ? { ...u, status:newStatus } : u));
      if (user) {
        const msgs = {
          APPROVED: { titre: t("admin.approuver"), message:`${user.prenom} ${user.nom} (${user.departement})` },
          REJECTED: { titre: t("admin.refuser"),   message:`${user.prenom} ${user.nom} (${user.departement})` },
        };
        if (msgs[newStatus]) addNotif({ type:"validation", ...msgs[newStatus] });
      }
    } catch (e) {
      alert("Erreur lors de la mise à jour : " + e.message);
    }
  }

  function logout() {
    localStorage.removeItem("token");
    localStorage.removeItem("role");
    localStorage.removeItem("prenom");
    localStorage.removeItem("nom");
    localStorage.removeItem("email");
    navigate("login");
  }

  const pending  = users.filter(r => r.status === "PENDING").length;
  const approved = users.filter(r => r.status === "APPROVED").length;

  const TABS = [
    { id:"inscriptions", label: t("admin.inscriptions"), icon:"📋", badge: pending > 0 ? pending : null },
    { id:"recruteurs",   label: t("admin.recruteurs"),   icon:"👥", badge: approved > 0 ? approved : null },
    { id:"messagerie",   label: t("admin.messagerie"),   icon:"💬", badge: null },
  ];

  return (
    <div style={{ minHeight:"100vh", background:"var(--bg-primary)", fontFamily:"var(--font-sans)" }}>

      {/* TOPBAR */}
      <header style={{
        background:"var(--bg-card)", borderBottom:"1px solid var(--border-color)",
        height:64, padding:"0 32px",
        display:"flex", alignItems:"center", justifyContent:"space-between",
        position:"sticky", top:0, zIndex:200,
        boxShadow:"0 1px 16px rgba(0,61,165,0.07)",
      }}>
        <div style={{ display:"flex", alignItems:"center", gap:18 }}>
          <Logo />
          <div style={{ width:1, height:30, background:"var(--border-color)" }}/>
          <div>
            <div style={{ fontSize:13, fontWeight:700, color:"var(--text-primary)" }}>{t("admin.espaceAdmin")}</div>
            <div style={{ fontSize:11, color:"var(--text-muted)" }}>{t("admin.plateformeDelice")}</div>
          </div>
          {pending > 0 && (
            <div style={{ display:"flex", alignItems:"center", gap:7, background:"#FFF7ED", border:"1px solid #FED7AA", borderRadius:100, padding:"5px 13px", fontSize:12, fontWeight:600, color:"#9A3412" }}>
              <span style={{ width:8, height:8, borderRadius:"50%", background:"#F97316", display:"inline-block" }}/>
              {pending} {t("admin.demandesEnAttente")}
            </div>
          )}
        </div>
        <div style={{ display:"flex", alignItems:"center", gap:12 }}>
          <div style={{ textAlign:"right" }}>
            <div style={{ fontSize:13, fontWeight:600, color:"var(--text-primary)" }}>{t("admin.administrateur")}</div>
            <div style={{ fontSize:11, color:"var(--text-muted)" }}>admin@delijob.tn</div>
          </div>
          <Avatar initials="A" size={38} />
          <LanguageSwitcher />
          <ThemeSwitch />
          <button onClick={logout}
            style={{ padding:"7px 18px", borderRadius:9, border:"1px solid var(--border-color)", background:"var(--bg-card)", cursor:"pointer", fontSize:12, fontWeight:600, color:"var(--text-secondary)", transition:"all .15s" }}
            onMouseEnter={e=>{ e.currentTarget.style.borderColor="#003DA5"; e.currentTarget.style.color="#003DA5"; }}
            onMouseLeave={e=>{ e.currentTarget.style.borderColor="var(--border-color)"; e.currentTarget.style.color="var(--text-secondary)"; }}
          >{t("admin.deconnexion")}</button>
        </div>
      </header>

      <main style={{ maxWidth:1200, margin:"0 auto", padding:"32px 28px" }}>
        {/* HERO */}
        <div style={{
          background:"linear-gradient(130deg, #003DA5 0%, #1a56db 55%, #2563EB 100%)",
          borderRadius:20, padding:"30px 40px",
          display:"flex", alignItems:"center", justifyContent:"space-between",
          marginBottom:28, boxShadow:"0 8px 32px rgba(0,61,165,0.3)",
          position:"relative", overflow:"hidden",
        }}>
          <div style={{ position:"relative" }}>
            <div style={{ fontSize:10, fontWeight:700, letterSpacing:"2.5px", textTransform:"uppercase", color:"rgba(255,255,255,0.55)", marginBottom:8 }}>DeliJob · Délice Danone</div>
            <h1 style={{ fontFamily:"var(--font-serif)", fontSize:26, fontWeight:800, color:"white", marginBottom:6 }}>{t("admin.titre")}</h1>
            <p style={{ fontSize:13, color:"rgba(255,255,255,0.65)" }}>{t("admin.subtitle")}</p>
          </div>
          <div style={{ display:"flex", gap:0, position:"relative" }}>
            {[
  
      
              { n:approved,     l: t("admin.recruteurs"), c:"#4ADE80" },
            ].map((s,i) => (
              <div key={i} style={{ padding:"14px 24px", textAlign:"center", borderRight:i<2?"1px solid rgba(255,255,255,0.15)":"none" }}>
                <div style={{ fontSize:28, fontWeight:800, fontFamily:"var(--font-serif)", color:s.c, lineHeight:1 }}>{s.n}</div>
                <div style={{ fontSize:10, color:"rgba(255,255,255,0.55)", textTransform:"uppercase", letterSpacing:"1px", marginTop:4 }}>{s.l}</div>
              </div>
            ))}
          </div>
        </div>

        {/* ERROR */}
        {error && (
          <div style={{ background:"#FEF2F2", border:"1px solid #FECACA", borderRadius:12, padding:"14px 20px", marginBottom:20, color:"#991B1B", fontSize:13, display:"flex", alignItems:"center", gap:10 }}>
            ⚠️ {error}
            <button onClick={fetchUsers} style={{ marginLeft:"auto", padding:"4px 12px", borderRadius:8, border:"1px solid #FECACA", background:"white", color:"#991B1B", fontSize:12, cursor:"pointer", fontWeight:600 }}>Réessayer</button>
          </div>
        )}

        {/* TABS */}
        <div style={{ display:"flex", gap:4, marginBottom:24, background:"var(--bg-card)", padding:6, borderRadius:14, border:"1px solid var(--border-color)", width:"fit-content" }}>
          {TABS.map(tab => (
            <button key={tab.id} onClick={()=>setActiveTab(tab.id)} style={{
              display:"flex", alignItems:"center", gap:8,
              padding:"10px 24px", borderRadius:10, border:"none",
              background: activeTab===tab.id ? "#003DA5" : "transparent",
              color: activeTab===tab.id ? "white" : "var(--text-secondary)",
              fontSize:13, fontWeight:600, cursor:"pointer", transition:"all .2s",
            }}>
              <span>{tab.icon}</span>
              <span>{tab.label}</span>
              {tab.badge && (
                <span style={{
                  background: activeTab===tab.id ? "rgba(255,255,255,0.25)" : "var(--bg-secondary)",
                  color: activeTab===tab.id ? "white" : "#3730A3",
                  borderRadius:100, padding:"1px 8px", fontSize:11, fontWeight:700,
                }}>{tab.badge}</span>
              )}
            </button>
          ))}
        </div>

        {/* CONTENT */}
        <div>
          {activeTab === "inscriptions" && <InscriptionsTab users={users} updateStatus={updateStatus} loading={loading} />}
          {activeTab === "recruteurs"   && <RecruteursTab   users={users} updateStatus={updateStatus} loading={loading} addNotif={addNotif} />}
          {activeTab === "messagerie"   && <MessagerieTab   users={users} />}
        </div>
      </main>
    </div>
  );
}