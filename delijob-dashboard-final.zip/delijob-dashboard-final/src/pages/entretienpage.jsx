import { useState, useMemo, useCallback, memo, useEffect } from "react";
import { useApp }  from "../context/appcontext.jsx";
import { useI18n } from "../i18n/i18nContext.jsx";
import { useEntretiens } from "../hooks/useEntretiens.js";

/* ─── Design tokens ─────────────────────────────────────────────────────── */
const C = {
  bg:"#F8FAFC", surface:"#FFFFFF", border:"#E2E8F0", borderL:"#F1F5F9",
  text:"#0F172A", textMid:"#475569", textSub:"#94A3B8",
  accent:"#0EA5E9", accentDk:"#0284C7", accentBg:"#EFF6FF",
  green:"#10B981", greenBg:"#ECFDF5", greenText:"#065F46", greenBorder:"#A7F3D0",
  amber:"#F59E0B", amberBg:"#FFFBEB", amberText:"#92400E", amberBorder:"#FDE68A",
  rose:"#F43F5E",  roseBg:"#FFF1F2",  roseText:"#9F1239",  roseBorder:"#FECDD3",
  skyBg:"#F0F9FF", skyText:"#0C4A6E",
  violetBg:"#F5F3FF", violetText:"#4C1D95",
  tealBg:"#F0FDFA",   tealText:"#134E4A",
};

const STATUT = {
  "confirmé":   { dot:C.green, bg:C.greenBg,  text:C.greenText,  border:C.greenBorder },
  "en attente": { dot:C.amber, bg:C.amberBg,  text:C.amberText,  border:C.amberBorder },
  "annulé":     { dot:C.rose,  bg:C.roseBg,   text:C.roseText,   border:C.roseBorder  },
};

const TYPE = {
  Technique:{ bg:C.skyBg,    text:C.skyText    },
  RH:       { bg:C.violetBg, text:C.violetText },
  Métier:   { bg:C.tealBg,   text:C.tealText   },
};

const MONTHS = ["Janvier","Février","Mars","Avril","Mai","Juin","Juillet","Août","Septembre","Octobre","Novembre","Décembre"];
const WDAYS  = ["Lun","Mar","Mer","Jeu","Ven","Sam","Dim"];

const daysInMonth = (y,m) => new Date(y,m+1,0).getDate();
const startOffset = (y,m) => { const d=new Date(y,m,1).getDay(); return d===0?6:d-1; };
const toStr       = (y,m,d) => `${y}-${String(m+1).padStart(2,"0")}-${String(d).padStart(2,"0")}`;
const todayCheck  = (y,m,d) => { const t=new Date(); return t.getFullYear()===y&&t.getMonth()===m&&t.getDate()===d; };
const fmtDate     = s => new Date(s).toLocaleDateString("fr-FR",{weekday:"long",day:"numeric",month:"long",year:"numeric"});

/* ─── Validation date/heure ──────────────────────────────────────────────── */
const validateDateTime = (dateStr, heureStr) => {
  let dateError = null, heureError = null, dateWarning = null;
  if (!dateStr) return { dateError, heureError, dateWarning };

  const ISO_RE = /^\d{4}-\d{2}-\d{2}$/;
  if (!ISO_RE.test(dateStr))
    return { dateError:"Format de date invalide.", heureError:null, dateWarning:null };

  const [y,m,d] = dateStr.split("-").map(Number);
  if (m < 1 || m > 12)
    return { dateError:"Mois invalide (01 – 12).", heureError:null, dateWarning:null };

  const maxDay = new Date(y,m,0).getDate();
  if (d < 1 || d > maxDay)
    return { dateError:`Jour invalide pour ${MONTHS[m-1]} ${y} (01 – ${maxDay}).`, heureError:null, dateWarning:null };

  const currentYear = new Date().getFullYear();
  if (y < currentYear || y > currentYear + 5)
    return { dateError:`L'année doit être comprise entre ${currentYear} et ${currentYear+5}.`, heureError:null, dateWarning:null };

  const today = new Date(); today.setHours(0,0,0,0);
  const chosen = new Date(y,m-1,d);
  if (chosen < today)
    return { dateError:"La date de l'entretien ne peut pas être dans le passé.", heureError:null, dateWarning:null };

  const dow = chosen.getDay();
  if (dow === 0 || dow === 6)
    dateWarning = "Attention : cette date tombe un " + (dow===6?"samedi":"dimanche") + ".";

  if (heureStr) {
    const HH_RE = /^([01]\d|2[0-3]):([0-5]\d)$/;
    if (!HH_RE.test(heureStr)) {
      heureError = "Format d'heure invalide (HH:MM, ex: 09:30).";
    } else {
      if (chosen.getTime() === today.getTime()) {
        const [hh,mm] = heureStr.split(":").map(Number);
        const now = new Date();
        if (hh < now.getHours() || (hh===now.getHours() && mm<=now.getMinutes()))
          heureError = "L'heure est déjà passée pour aujourd'hui.";
      }
    }
  }
  return { dateError, heureError, dateWarning };
};

/* ─── Validation email ───────────────────────────────────────────────────── */
const validateEmail = (email) => {
  if (!email || email.trim() === "") return null; // champ optionnel
  const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!EMAIL_RE.test(email.trim()))
    return "Adresse email invalide (ex: candidat@email.com).";
  return null;
};

/* ─── Icônes & styles ────────────────────────────────────────────────────── */
const Ico = ({d,size=16,color="currentColor"}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
    stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"
    style={{flexShrink:0}}>
    <path d={d}/>
  </svg>
);

const I = {
  left:   "M15 19l-7-7 7-7",
  right:  "M9 5l7 7-7 7",
  plus:   "M12 4v16m8-8H4",
  x:      "M6 18L18 6M6 6l12 12",
  clock:  "M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z",
  user:   "M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z",
  cal:    "M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z",
  edit:   "M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z",
  trash:  "M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16",
  list:   "M4 6h16M4 10h16M4 14h16M4 18h16",
  search: "M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z",
  warn:   "M12 9v2m0 4h.01M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z",
  mail:   "M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z",
};

const btn = (extra={}) => ({
  border:"none", cursor:"pointer", fontFamily:"inherit",
  display:"inline-flex", alignItems:"center", gap:6,
  transition:"all .15s", ...extra,
});

const inputBase = {
  width:"100%", boxSizing:"border-box", padding:"10px 12px", fontSize:13,
  border:`1px solid ${C.border}`, borderRadius:10, outline:"none",
  fontFamily:"inherit", color:C.text, background:C.surface,
};

const lbl = {
  display:"block", fontSize:11, fontWeight:700, color:C.textMid,
  textTransform:"uppercase", letterSpacing:"0.06em", marginBottom:6,
};

/* ─── Spinner ────────────────────────────────────────────────────────────── */
const Spinner = () => (
  <div style={{display:"flex",justifyContent:"center",alignItems:"center",padding:60}}>
    <div style={{width:32,height:32,border:`3px solid ${C.border}`,borderTopColor:C.accent,
                 borderRadius:"50%",animation:"spin .7s linear infinite"}}/>
    <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
  </div>
);

/* ─── ErrorBanner ────────────────────────────────────────────────────────── */
const ErrorBanner = ({ message, onRetry }) => (
  <div style={{background:C.roseBg,border:`1px solid ${C.roseBorder}`,borderRadius:12,
               padding:"14px 18px",display:"flex",justifyContent:"space-between",
               alignItems:"center",marginBottom:16}}>
    <span style={{fontSize:13,color:C.roseText}}>{message}</span>
    {onRetry && (
      <button onClick={onRetry}
        style={btn({fontSize:12,color:C.rose,fontWeight:600,padding:"5px 12px",
                    borderRadius:8,background:C.roseBg,border:`1px solid ${C.roseBorder}`})}>
        Réessayer
      </button>
    )}
  </div>
);

/* ─── FieldError / FieldWarning ──────────────────────────────────────────── */
const FieldError = ({ msg }) => !msg ? null : (
  <div style={{display:"flex",alignItems:"center",gap:5,marginTop:5,padding:"6px 10px",
               borderRadius:8,background:C.roseBg,border:`1px solid ${C.roseBorder}`}}>
    <Ico d={I.x} size={12} color={C.rose}/>
    <span style={{fontSize:11,fontWeight:600,color:C.roseText}}>{msg}</span>
  </div>
);

const FieldWarning = ({ msg }) => !msg ? null : (
  <div style={{display:"flex",alignItems:"center",gap:5,marginTop:5,padding:"6px 10px",
               borderRadius:8,background:C.amberBg,border:`1px solid ${C.amberBorder}`}}>
    <Ico d={I.warn} size={12} color={C.amber}/>
    <span style={{fontSize:11,fontWeight:600,color:C.amberText}}>{msg}</span>
  </div>
);

/* ─── EntretienCard ──────────────────────────────────────────────────────── */
const EntretienCard = memo(({ e, onEdit, onDelete }) => {
  const [hov, setHov] = useState(false);
  const s  = STATUT[e.statut] || STATUT["en attente"];
  const t2 = TYPE[e.type]     || TYPE.Technique;
  const { t } = useI18n();
  return (
    <div onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)}
      style={{position:"relative",borderRadius:14,border:`1px solid ${s.border}`,
              background:C.surface,overflow:"hidden",
              boxShadow:hov?"0 4px 20px rgba(0,0,0,.08)":"0 1px 4px rgba(0,0,0,.04)",
              transition:"box-shadow .2s"}}>
      <div style={{position:"absolute",left:0,top:0,bottom:0,width:4,background:s.dot}}/>
      <div style={{padding:"14px 14px 14px 18px"}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",gap:8,marginBottom:10}}>
          <div style={{minWidth:0}}>
            <div style={{fontWeight:700,fontSize:14,color:C.text,whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"}}>{e.candidat}</div>
            <div style={{fontSize:12,color:C.textSub,marginTop:2}}>{e.poste}</div>
          </div>
          <span style={{flexShrink:0,fontSize:11,fontWeight:600,padding:"3px 9px",borderRadius:20,background:s.bg,color:s.text}}>
            {t(`entretien.${e.statut.replace("é","e")}`)}
          </span>
        </div>
        <div style={{display:"flex",flexDirection:"column",gap:5}}>
          <div style={{display:"flex",alignItems:"center",gap:6,fontSize:12,color:C.textMid}}>
            <Ico d={I.clock} size={13} color={C.textSub}/>{e.heure} · {e.duree} min
          </div>
          <div style={{display:"flex",alignItems:"center",gap:6,fontSize:12,color:C.textMid,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>
            <Ico d={I.user} size={13} color={C.textSub}/>{e.interviewer}
          </div>
          {/* Affichage de l'email si disponible */}
          {e.emailCandidat && (
            <div style={{display:"flex",alignItems:"center",gap:6,fontSize:11,color:C.textSub,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>
              <Ico d={I.mail} size={12} color={C.textSub}/>{e.emailCandidat}
            </div>
          )}
        </div>
        <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginTop:10,paddingTop:10,borderTop:`1px solid ${C.borderL}`}}>
          <span style={{fontSize:11,fontWeight:600,padding:"2px 8px",borderRadius:20,background:t2.bg,color:t2.text}}>
            {t(`entretien.type${e.type}`)}
          </span>
          <div style={{display:"flex",gap:4,opacity:hov?1:0,transition:"opacity .2s"}}>
            <button onClick={()=>onEdit(e)} style={btn({padding:5,borderRadius:8,background:C.skyBg})}>
              <Ico d={I.edit} size={13} color={C.accent}/>
            </button>
            <button onClick={()=>onDelete(e.id, e.candidat)} style={btn({padding:5,borderRadius:8,background:C.roseBg})}>
              <Ico d={I.trash} size={13} color={C.rose}/>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
});

/* ─── EntretienForm ──────────────────────────────────────────────────────── */
const EntretienForm = memo(({ initial, onSave, onClose }) => {
  const isEdit = !!initial?.id;

  const [f, setF] = useState(
    initial || {
      candidat:       "",
      poste:          "",
      emailCandidat:  "",   // ← champ email candidat
      date:           "",
      heure:          "",
      statut:         "en attente",
      duree:          60,
      type:           "Technique",
      interviewer:    "",
    }
  );

  const [saving,  setSaving]  = useState(false);
  const [touched, setTouched] = useState({ date:false, heure:false, emailCandidat:false });
  const { t } = useI18n();

  const set = (k, v) => {
    setF(p => ({...p, [k]: v}));
    setTouched(p => ({...p, [k]: true}));
  };

  // Validation date / heure
  const { dateError, heureError, dateWarning } = useMemo(
    () => validateDateTime(f.date, f.heure),
    [f.date, f.heure]
  );

  // Validation email (optionnel)
  const emailError = useMemo(() => validateEmail(f.emailCandidat), [f.emailCandidat]);

  const blockSave = isEdit
    ? !!(dateError && dateError !== "La date de l'entretien ne peut pas être dans le passé.") || !!heureError || !!emailError
    : !!(dateError || heureError || emailError);

  const handleSave = async () => {
    setTouched({ date:true, heure:true, emailCandidat:true });
    if (blockSave) return;
    setSaving(true);
    try { await onSave({...f, duree: parseInt(f.duree)}); }
    finally { setSaving(false); }
  };

  const todayISO = new Date().toISOString().split("T")[0];

  return (
    <div
      style={{position:"fixed",inset:0,background:"rgba(15,23,42,.55)",backdropFilter:"blur(4px)",
              display:"flex",alignItems:"center",justifyContent:"center",zIndex:1000,padding:16}}
      onClick={e => e.target === e.currentTarget && onClose()}
    >
      <div style={{background:C.surface,borderRadius:20,width:"100%",maxWidth:480,
                   boxShadow:"0 25px 60px rgba(0,0,0,.18)",maxHeight:"90vh",overflowY:"auto"}}>

        {/* En-tête */}
        <div style={{padding:"20px 24px",borderBottom:`1px solid ${C.borderL}`,
                     display:"flex",justifyContent:"space-between",alignItems:"flex-start"}}>
          <div>
            <div style={{fontWeight:700,fontSize:17,color:C.text}}>
              {isEdit ? t("entretien.modifierTitre") : t("entretien.nouveauTitre")}
            </div>
            <div style={{fontSize:12,color:C.textSub,marginTop:2}}>
              {isEdit ? t("entretien.mettreAJourDesc") : t("entretien.planifierNouvelDesc")}
            </div>
          </div>
          <button onClick={onClose} style={btn({padding:6,borderRadius:8,background:C.borderL})}>
            <Ico d={I.x} size={14} color={C.textMid}/>
          </button>
        </div>

        <div style={{padding:24,display:"flex",flexDirection:"column",gap:14}}>

          {/* ── Candidat */}
          <div>
            <label style={lbl}>{t("entretien.candidat")}</label>
            <input style={inputBase} value={f.candidat}
              onChange={e=>set("candidat",e.target.value)}
              placeholder={t("entretien.nomComplet")}/>
          </div>

          {/* ── Poste */}
          <div>
            <label style={lbl}>{t("entretien.poste")}</label>
            <input style={inputBase} value={f.poste}
              onChange={e=>set("poste",e.target.value)}
              placeholder={t("entretien.intitulePoste")}/>
          </div>

          {/* ── Email candidat ← NOUVEAU CHAMP */}
          <div>
            <label style={lbl}>
              <span style={{display:"inline-flex",alignItems:"center",gap:5}}>
                <Ico d={I.mail} size={11} color={C.textMid}/>
                Email du candidat
                <span style={{fontWeight:400,color:C.textSub,textTransform:"none",letterSpacing:0,marginLeft:4}}>
                  (facultatif – pour la convocation automatique)
                </span>
              </span>
            </label>
            <input
              style={{
                ...inputBase,
                borderColor: touched.emailCandidat && emailError ? C.rose : C.border,
                background:  touched.emailCandidat && emailError ? C.roseBg : C.surface,
              }}
              type="email"
              value={f.emailCandidat || ""}
              onChange={e => set("emailCandidat", e.target.value)}
              onBlur={() => setTouched(p => ({...p, emailCandidat:true}))}
              placeholder="candidat@email.com"
            />
            {touched.emailCandidat && <FieldError msg={emailError}/>}
            {/* Info bulle si email renseigné et valide */}
            {f.emailCandidat && !emailError && (
              <div style={{display:"flex",alignItems:"center",gap:5,marginTop:5,padding:"6px 10px",
                           borderRadius:8,background:C.greenBg,border:`1px solid ${C.greenBorder}`}}>
                <Ico d={I.mail} size={12} color={C.green}/>
                <span style={{fontSize:11,fontWeight:600,color:C.greenText}}>
                  Un email de convocation sera envoyé automatiquement à cette adresse.
                </span>
              </div>
            )}
          </div>

          {/* ── Date + Heure */}
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>

            {/* Date */}
            <div>
              <label style={lbl}>{t("entretien.date")}</label>
              <input
                style={{
                  ...inputBase,
                  borderColor: touched.date && dateError ? C.rose : touched.date && dateWarning ? C.amber : C.border,
                  background:  touched.date && dateError ? C.roseBg : touched.date && dateWarning ? C.amberBg : C.surface,
                }}
                type="date"
                value={f.date}
                min={isEdit ? undefined : todayISO}
                onChange={e => set("date", e.target.value)}
                onBlur={() => setTouched(p => ({...p, date:true}))}
              />
              {touched.date && <FieldError msg={dateError}/>}
              {touched.date && !dateError && <FieldWarning msg={dateWarning}/>}
            </div>

            {/* Heure */}
            <div>
              <label style={lbl}>{t("entretien.heure")}</label>
              <input
                style={{
                  ...inputBase,
                  borderColor: touched.heure && heureError ? C.rose : C.border,
                  background:  touched.heure && heureError ? C.roseBg : C.surface,
                }}
                type="time"
                value={f.heure}
                onChange={e => set("heure", e.target.value)}
                onBlur={() => setTouched(p => ({...p, heure:true}))}
              />
              {touched.heure && <FieldError msg={heureError}/>}
            </div>
          </div>

          {/* ── Durée + Type */}
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
            <div>
              <label style={lbl}>{t("entretien.duree")}</label>
              <input style={inputBase} type="number" value={f.duree}
                onChange={e=>set("duree",e.target.value)}/>
            </div>
            <div>
              <label style={lbl}>{t("entretien.type")}</label>
              <select style={inputBase} value={f.type} onChange={e=>set("type",e.target.value)}>
                <option value="Technique">{t("entretien.typeTechnique")}</option>
                <option value="RH">{t("entretien.typeRH")}</option>
                <option value="Métier">{t("entretien.typeMetier")}</option>
              </select>
            </div>
          </div>

          {/* ── Interviewer */}
          <div>
            <label style={lbl}>{t("entretien.interviewer")}</label>
            <input style={inputBase} value={f.interviewer}
              onChange={e=>set("interviewer",e.target.value)}
              placeholder={t("entretien.nomInterviewer")}/>
          </div>

          {/* ── Statut (édition uniquement) */}
          {isEdit && (
            <div>
              <label style={lbl}>{t("entretien.statut")}</label>
              <select style={inputBase} value={f.statut} onChange={e=>set("statut",e.target.value)}>
                <option value="confirmé">{t("entretien.confirme")}</option>
                <option value="en attente">{t("entretien.enAttente")}</option>
                <option value="annulé">{t("entretien.annule")}</option>
              </select>
            </div>
          )}

          {/* ── Résumé d'erreurs global */}
          {(touched.date || touched.heure || touched.emailCandidat) && blockSave && (
            <div style={{display:"flex",alignItems:"center",gap:8,padding:"10px 14px",
                         borderRadius:10,background:C.roseBg,border:`1px solid ${C.roseBorder}`}}>
              <Ico d={I.warn} size={14} color={C.rose}/>
              <span style={{fontSize:12,fontWeight:600,color:C.roseText}}>
                Corrigez les erreurs ci-dessus avant de continuer.
              </span>
            </div>
          )}

          {/* ── Actions */}
          <div style={{display:"flex",gap:10,marginTop:4}}>
            <button onClick={onClose}
              style={btn({flex:1,justifyContent:"center",padding:"10px",borderRadius:10,
                          border:`1px solid ${C.border}`,background:C.surface,
                          color:C.textMid,fontSize:13,fontWeight:600})}>
              {t("entretien.annuler")}
            </button>
            <button
              onClick={handleSave}
              disabled={saving}
              title={blockSave ? "Veuillez corriger les erreurs" : undefined}
              style={btn({
                flex:1, justifyContent:"center", padding:"10px", borderRadius:10,
                background: blockSave ? C.border : C.accent,
                color: blockSave ? C.textMid : "#fff",
                fontSize:13, fontWeight:600,
                opacity: saving ? 0.7 : 1,
                cursor: blockSave ? "not-allowed" : "pointer",
              })}>
              {saving ? "..." : isEdit ? t("entretien.enregistrer") : t("entretien.creerEntretien")}
            </button>
          </div>

        </div>
      </div>
    </div>
  );
});

/* ─── DeleteConfirm ──────────────────────────────────────────────────────── */
const DeleteConfirm = memo(({ candidat, onConfirm, onCancel }) => {
  const { t } = useI18n();
  return (
    <div style={{position:"fixed",inset:0,background:"rgba(15,23,42,.55)",backdropFilter:"blur(4px)",
                 display:"flex",alignItems:"center",justifyContent:"center",zIndex:1000,padding:16}}>
      <div style={{background:C.surface,borderRadius:20,width:"100%",maxWidth:360,padding:32,
                   textAlign:"center",boxShadow:"0 25px 60px rgba(0,0,0,.18)"}}>
        <div style={{width:52,height:52,borderRadius:"50%",background:C.roseBg,display:"flex",
                     alignItems:"center",justifyContent:"center",margin:"0 auto 16px"}}>
          <Ico d={I.trash} size={22} color={C.rose}/>
        </div>
        <div style={{fontWeight:700,fontSize:16,color:C.text,marginBottom:8}}>{t("entretien.supprimer")}</div>
        <div style={{fontSize:13,color:C.textMid,marginBottom:24}}>
          {t("entretien.supprimerDesc").replace("{candidat}",candidat)}
        </div>
        <div style={{display:"flex",gap:10}}>
          <button onClick={onCancel}
            style={btn({flex:1,justifyContent:"center",padding:"10px",borderRadius:10,
                        border:`1px solid ${C.border}`,background:C.surface,
                        color:C.textMid,fontSize:13,fontWeight:600})}>
            {t("common.annuler")}
          </button>
          <button onClick={onConfirm}
            style={btn({flex:1,justifyContent:"center",padding:"10px",borderRadius:10,
                        background:C.rose,color:"#fff",fontSize:13,fontWeight:600})}>
            {t("common.supprimer")}
          </button>
        </div>
      </div>
    </div>
  );
});

/* ─── CalendarView ───────────────────────────────────────────────────────── */
const CalendarView = memo(({ year, month, entretiens, selectedDate, onSelectDate, onPrev, onNext }) => {
  const days   = daysInMonth(year, month);
  const offset = startOffset(year, month);
  const dayMap = useMemo(()=>{
    const m={};
    entretiens.forEach(e=>{ if(e.date){ (m[e.date]=m[e.date]||[]).push(e); } });
    return m;
  },[entretiens]);

  return (
    <div style={{background:C.surface,borderRadius:18,border:`1px solid ${C.border}`,
                 overflow:"hidden",boxShadow:"0 1px 6px rgba(0,0,0,.05)"}}>
      <div style={{padding:"16px 20px",borderBottom:`1px solid ${C.borderL}`,
                   display:"flex",alignItems:"center",gap:10}}>
        <button onClick={onPrev} style={btn({padding:7,borderRadius:8,background:C.bg})}>
          <Ico d={I.left} size={14} color={C.textMid}/>
        </button>
        <div style={{fontWeight:700,fontSize:15,color:C.text,width:180,textAlign:"center"}}>
          {MONTHS[month]} {year}
        </div>
        <button onClick={onNext} style={btn({padding:7,borderRadius:8,background:C.bg})}>
          <Ico d={I.right} size={14} color={C.textMid}/>
        </button>
      </div>

      <div style={{display:"grid",gridTemplateColumns:"repeat(7,1fr)",borderBottom:`1px solid ${C.borderL}`}}>
        {WDAYS.map((d,i)=>(
          <div key={d} style={{padding:"10px 0",textAlign:"center",fontSize:11,fontWeight:700,
                               color:i>=5?C.textSub:C.textMid,textTransform:"uppercase",
                               letterSpacing:"0.05em"}}>{d}</div>
        ))}
      </div>

      <div style={{display:"grid",gridTemplateColumns:"repeat(7,1fr)"}}>
        {Array.from({length:offset}).map((_,i)=>(
          <div key={`e${i}`} style={{minHeight:96,background:"#FAFBFC",
                                     borderRight:`1px solid ${C.borderL}`,
                                     borderBottom:`1px solid ${C.borderL}`}}/>
        ))}
        {Array.from({length:days}).map((_,i)=>{
          const day=i+1, ds=toStr(year,month,day);
          const items=(dayMap[ds]||[]).filter(e=>e.statut!=="annulé");
          const isSel=selectedDate===ds, isTod=todayCheck(year,month,day), isWEnd=((offset+i)%7)>=5;
          return (
            <div key={day} onClick={()=>onSelectDate(ds)}
              style={{minHeight:96,cursor:"pointer",padding:6,
                      background:isSel?"#EFF6FF":isWEnd?"#FAFBFC":C.surface,
                      borderRight:`1px solid ${C.borderL}`,borderBottom:`1px solid ${C.borderL}`,
                      boxShadow:isSel?"inset 0 0 0 2px #0EA5E9":undefined,
                      transition:"background .12s"}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:4}}>
                <span style={{fontSize:12,fontWeight:600,width:24,height:24,display:"flex",
                              alignItems:"center",justifyContent:"center",borderRadius:"50%",
                              background:isTod?C.accent:"transparent",
                              color:isTod?"#fff":isSel?C.accent:isWEnd?C.textSub:C.text}}>{day}</span>
                {items.length>0&&<span style={{fontSize:10,fontWeight:700,padding:"1px 5px",
                                               borderRadius:6,background:C.accentBg,color:C.accent}}>{items.length}</span>}
              </div>
              <div style={{display:"flex",flexDirection:"column",gap:2}}>
                {items.slice(0,2).map(e=>{
                  const s=STATUT[e.statut]||STATUT["en attente"];
                  return (
                    <div key={e.id} style={{fontSize:10,fontWeight:500,padding:"2px 5px",
                                           borderRadius:4,background:s.bg,color:s.text,
                                           overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>
                      {e.heure} · {e.candidat?.split(" ")[0]}
                    </div>
                  );
                })}
                {items.length>2&&<div style={{fontSize:10,color:C.textSub,paddingLeft:2}}>+{items.length-2} autres</div>}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
});

/* ─── SidePanel ──────────────────────────────────────────────────────────── */
const SidePanel = memo(({ date, entretiens, onEdit, onDelete, onAdd, onClose }) => {
  const items = entretiens.filter(e=>e.date===date);
  const { t } = useI18n();
  return (
    <div style={{background:C.surface,borderRadius:18,border:`1px solid ${C.border}`,
                 overflow:"hidden",boxShadow:"0 1px 6px rgba(0,0,0,.05)"}}>
      <div style={{padding:"16px 18px",borderBottom:`1px solid ${C.borderL}`,
                   display:"flex",justifyContent:"space-between",alignItems:"flex-start"}}>
        <div>
          <div style={{fontSize:10,fontWeight:700,color:C.textSub,textTransform:"uppercase",
                       letterSpacing:"0.07em",marginBottom:3}}>{t("entretien.selection")}</div>
          <div style={{fontWeight:700,fontSize:13,color:C.text,textTransform:"capitalize"}}>
            {fmtDate(date)}
          </div>
        </div>
        <button onClick={onClose} style={btn({padding:5,borderRadius:8,background:C.bg})}>
          <Ico d={I.x} size={13} color={C.textMid}/>
        </button>
      </div>
      <div style={{padding:14,display:"flex",flexDirection:"column",gap:10}}>
        {items.length===0 ? (
          <div style={{textAlign:"center",padding:"32px 0"}}>
            <div style={{width:44,height:44,borderRadius:"50%",background:C.bg,display:"flex",
                         alignItems:"center",justifyContent:"center",margin:"0 auto 10px"}}>
              <Ico d={I.cal} size={20} color={C.textSub}/>
            </div>
            <div style={{fontSize:13,color:C.textSub,marginBottom:10}}>{t("entretien.aucun")}</div>
            <button onClick={onAdd}
              style={btn({fontSize:12,color:C.accent,fontWeight:600,padding:"6px 14px",borderRadius:8,background:C.accentBg})}>
              + {t("entretien.planifierBtn")}
            </button>
          </div>
        ) : (
          <>
            {items.map(e=><EntretienCard key={e.id} e={e} onEdit={onEdit} onDelete={onDelete}/>)}
            <button onClick={onAdd}
              style={btn({width:"100%",justifyContent:"center",padding:"9px",borderRadius:10,
                          border:`1.5px dashed ${C.border}`,background:"transparent",
                          fontSize:12,color:C.accent,fontWeight:600})}>
              + {t("entretien.ajouterCeJour")}
            </button>
          </>
        )}
      </div>
    </div>
  );
});

/* ─── ListView ───────────────────────────────────────────────────────────── */
const ListView = memo(({ entretiens, onEdit, onDelete, search }) => {
  const { t } = useI18n();
  const grouped = useMemo(()=>{
    const q = search.toLowerCase();
    const filtered = entretiens
      .filter(e => e.date && e.heure)
      .filter(e=>!q||e.candidat?.toLowerCase().includes(q)||e.poste?.toLowerCase().includes(q)||e.interviewer?.toLowerCase().includes(q))
      .sort((a,b)=>(a.date||"").localeCompare(b.date||"")||(a.heure||"").localeCompare(b.heure||""));
    const map={};
    filtered.forEach(e=>{ (map[e.date]=map[e.date]||[]).push(e); });
    return Object.entries(map).sort(([a],[b])=>a.localeCompare(b));
  },[entretiens,search]);

  if(!grouped.length) return (
    <div style={{background:C.surface,borderRadius:18,border:`1px solid ${C.border}`,
                 padding:60,textAlign:"center",boxShadow:"0 1px 6px rgba(0,0,0,.05)"}}>
      <Ico d={I.search} size={32} color={C.textSub}/>
      <div style={{marginTop:12,fontSize:14,color:C.textSub}}>{t("entretien.aucunTrouve")}</div>
    </div>
  );

  return (
    <div style={{display:"flex",flexDirection:"column",gap:24}}>
      {grouped.map(([date,items])=>(
        <div key={date}>
          <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:12}}>
            <div style={{flex:1,height:1,background:C.border}}/>
            <span style={{fontSize:11,fontWeight:700,color:C.textSub,textTransform:"uppercase",
                          letterSpacing:"0.07em",whiteSpace:"nowrap"}}>{fmtDate(date)}</span>
            <div style={{flex:1,height:1,background:C.border}}/>
          </div>
          <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(260px,1fr))",gap:12}}>
            {items.map(e=><EntretienCard key={e.id} e={e} onEdit={onEdit} onDelete={onDelete}/>)}
          </div>
        </div>
      ))}
    </div>
  );
});

/* ═══════════════════════════════════════════════════════════════════════════
   PAGE PRINCIPALE
═══════════════════════════════════════════════════════════════════════════ */
export default function EntretienCalendarPage() {
  const { addNotif } = useApp();
  const { t }        = useI18n();

  const [year,  setYear]  = useState(() => new Date().getFullYear());
  const [month, setMonth] = useState(() => new Date().getMonth());
  const [selectedDate, setSel]      = useState(null);
  const [view,         setView]     = useState("calendar");
  const [search,       setSearch]   = useState("");
  const [showForm,     setShowForm] = useState(false);
  const [editTarget,   setEdit]     = useState(null);
  const [deleteTarget, setDel]      = useState(null);

  const { entretiens, loading, error, fetchAll, fetchByMonth, create, update, remove } = useEntretiens();

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) return;
    if (view === "calendar") fetchByMonth(year, month + 1);
    else fetchAll(search);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [year, month, view]);

  useEffect(() => {
    if (view !== "list") return;
    const token = localStorage.getItem("token");
    if (!token) return;
    const timer = setTimeout(() => fetchAll(search), 350);
    return () => clearTimeout(timer);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search, view]);

  const prevMonth = useCallback(() => {
    if (month===0){ setYear(y=>y-1); setMonth(11); } else setMonth(m=>m-1);
  }, [month]);

  const nextMonth = useCallback(() => {
    if (month===11){ setYear(y=>y+1); setMonth(0); } else setMonth(m=>m+1);
  }, [month]);

  const handleSave = useCallback(async (data) => {
    try {
      if (data.id) {
        await update(data.id, data);
        addNotif({
          type:"entretien",
          titre: t("entretien.notificationModifieTitre"),
          message: t("entretien.notificationModifieMessage")
            .replace("{candidat}", data.candidat)
            .replace("{poste}",    data.poste)
            .replace("{date}",     data.date)
            .replace("{heure}",    data.heure),
          action:{label:t("entretien.voirCalendrier"),href:"#"},
        });
      } else {
        await create(data);
        // Notification de création + info email si adresse fournie
        const emailInfo = data.emailCandidat
          ? ` Un email de convocation a été envoyé à ${data.emailCandidat}.`
          : "";
        addNotif({
          type:"entretien",
          titre: t("entretien.notificationCreeTitre"),
          message: t("entretien.notificationCreeMessage")
            .replace("{candidat}",    data.candidat)
            .replace("{poste}",       data.poste)
            .replace("{date}",        data.date)
            .replace("{heure}",       data.heure)
            .replace("{interviewer}", data.interviewer) + emailInfo,
          action:{label:t("entretien.voirCalendrier"),href:"#"},
        });
      }
      setShowForm(false);
      setEdit(null);
      if (view==="calendar") fetchByMonth(year, month+1); else fetchAll(search);
    } catch(e) {
      alert("Erreur : " + e.message);
    }
  }, [create, update, addNotif, t, view, year, month, search, fetchByMonth, fetchAll]);

  const handleEdit   = useCallback(e=>{ setEdit(e); setShowForm(true); },[]);
  const handleDelete = useCallback((id,candidat)=>{ setDel(entretiens.find(e=>e.id===id)||{id,candidat}); },[entretiens]);

  const confirmDel = useCallback(async()=>{
    if(!deleteTarget) return;
    try {
      await remove(deleteTarget.id);
      addNotif({
        type:"entretien",
        titre: t("entretien.notificationSupprimeTitre"),
        message: t("entretien.notificationSupprimeMessage").replace("{candidat}", deleteTarget.candidat),
      });
      setDel(null);
      if(view==="calendar") fetchByMonth(year,month+1); else fetchAll(search);
    } catch(e){ alert("Erreur : "+e.message); }
  },[deleteTarget,remove,addNotif,t,view,year,month,search,fetchByMonth,fetchAll]);

  const stats = useMemo(()=>({
    total:     entretiens.length,
    confirmed: entretiens.filter(e=>e.statut==="confirmé").length,
    pending:   entretiens.filter(e=>e.statut==="en attente").length,
    cancelled: entretiens.filter(e=>e.statut==="annulé").length,
  }),[entretiens]);

  const tabBtn = (active) => btn({
    padding:"7px 14px", borderRadius:9, fontSize:12, fontWeight:600,
    background:active?C.accent:C.surface, color:active?"#fff":C.textMid,
    border:active?"none":`1px solid ${C.border}`,
    boxShadow:active?"0 2px 8px rgba(14,165,233,.25)":undefined,
  });

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
        *{box-sizing:border-box;margin:0;padding:0;}
        body{font-family:'Plus Jakarta Sans',system-ui,sans-serif;}
        button:hover{filter:brightness(0.95);}
        input:focus,select:focus{outline:2px solid #0EA5E9;outline-offset:-1px;}
      `}</style>

      <div style={{minHeight:"100vh",background:C.bg,
                   fontFamily:"'Plus Jakarta Sans',system-ui,sans-serif",color:C.text}}>
        <div style={{maxWidth:1200,margin:"0 auto",padding:"32px 24px"}}>

          {/* ── En-tête page */}
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",
                       flexWrap:"wrap",gap:16,marginBottom:28}}>
            <div>
              <h1 style={{fontSize:26,fontWeight:800,color:C.text,letterSpacing:"-0.5px",lineHeight:1.2}}>
                {t("entretien.titre")}
              </h1>
              <p style={{fontSize:13,color:C.textSub,marginTop:4}}>
                {t("entretien.subtitle")}
              </p>
            </div>
            <button onClick={()=>{setEdit(null);setShowForm(true);}}
              style={btn({padding:"11px 20px",borderRadius:12,background:C.accent,color:"#fff",
                          fontSize:13,fontWeight:700,boxShadow:"0 4px 14px rgba(14,165,233,.35)"})}>
              <Ico d={I.plus} size={15} color="#fff"/> {t("entretien.nouveauxEntretiens")}
            </button>
          </div>

          {error && (
            <ErrorBanner message={error}
              onRetry={()=>view==="calendar"?fetchByMonth(year,month+1):fetchAll(search)}/>
          )}

          {/* ── Stats (vue liste) */}
          {view === "list" && (
            <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:12,marginBottom:20}}>
              {[
                {label:t("entretien.total"),     val:stats.total,     bg:C.surface, valColor:C.text},
                {label:t("entretien.confirmes"), val:stats.confirmed, bg:C.greenBg, valColor:C.greenText},
                {label:t("entretien.enAttente"), val:stats.pending,   bg:C.amberBg, valColor:C.amberText},
                {label:t("entretien.annules"),   val:stats.cancelled, bg:C.roseBg,  valColor:C.roseText},
              ].map(s=>(
                <div key={s.label}
                  style={{background:s.bg,border:`1px solid ${C.border}`,borderRadius:14,
                           padding:"14px 18px",boxShadow:"0 1px 4px rgba(0,0,0,.04)"}}>
                  <div style={{fontSize:11,color:C.textSub,marginBottom:4,fontWeight:500}}>{s.label}</div>
                  <div style={{fontSize:28,fontWeight:800,color:s.valColor,lineHeight:1}}>{s.val}</div>
                </div>
              ))}
            </div>
          )}

          {/* ── Barre recherche + switch vue */}
          <div style={{display:"flex",gap:12,flexWrap:"wrap",marginBottom:20,alignItems:"center"}}>
            <div style={{position:"relative",flex:1,maxWidth:340}}>
              <div style={{position:"absolute",left:11,top:"50%",transform:"translateY(-50%)",pointerEvents:"none"}}>
                <Ico d={I.search} size={14} color={C.textSub}/>
              </div>
              <input value={search} onChange={e=>setSearch(e.target.value)}
                placeholder={t("entretien.rechercher")}
                style={{...inputBase,paddingLeft:34,borderRadius:12,fontSize:13}}/>
            </div>
            <div style={{display:"flex",gap:5,background:C.surface,border:`1px solid ${C.border}`,
                         borderRadius:12,padding:4}}>
              <button onClick={()=>setView("calendar")} style={tabBtn(view==="calendar")}>
                <Ico d={I.cal} size={13} color={view==="calendar"?"#fff":C.textMid}/> {t("entretien.calendrier")}
              </button>
              <button onClick={()=>setView("list")} style={tabBtn(view==="list")}>
                <Ico d={I.list} size={13} color={view==="list"?"#fff":C.textMid}/> {t("entretien.liste")}
              </button>
            </div>
          </div>

          {/* ── Contenu principal */}
          {loading ? <Spinner/> : view==="calendar" ? (
            <div style={{display:"grid",gridTemplateColumns:"1fr 330px",gap:20,alignItems:"start"}}>
              <CalendarView year={year} month={month} entretiens={entretiens}
                selectedDate={selectedDate} onSelectDate={setSel}
                onPrev={prevMonth} onNext={nextMonth}/>
              {selectedDate ? (
                <SidePanel date={selectedDate} entretiens={entretiens}
                  onEdit={handleEdit} onDelete={handleDelete}
                  onAdd={()=>{setEdit(null);setShowForm(true);}}
                  onClose={()=>setSel(null)}/>
              ) : (
                <div style={{background:C.surface,borderRadius:18,border:`1px solid ${C.border}`,
                             padding:40,textAlign:"center",boxShadow:"0 1px 6px rgba(0,0,0,.05)"}}>
                  <div style={{width:52,height:52,borderRadius:"50%",background:C.bg,display:"flex",
                               alignItems:"center",justifyContent:"center",margin:"0 auto 14px"}}>
                    <Ico d={I.cal} size={22} color={C.textSub}/>
                  </div>
                  <div style={{fontWeight:700,fontSize:14,color:C.text,marginBottom:6}}>
                    {t("entretien.selectionnerDate")}
                  </div>
                  <div style={{fontSize:12,color:C.textSub,lineHeight:1.6}}>
                    {t("entretien.selectionnerDateDesc")}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <ListView entretiens={entretiens} onEdit={handleEdit}
              onDelete={handleDelete} search={search}/>
          )}

        </div>
      </div>

      {showForm     && <EntretienForm initial={editTarget} onSave={handleSave}
                          onClose={()=>{setShowForm(false);setEdit(null);}}/>}
      {deleteTarget && <DeleteConfirm candidat={deleteTarget.candidat}
                          onConfirm={confirmDel} onCancel={()=>setDel(null)}/>}
    </>
  );
}