import { useState, useEffect, useRef } from "react";
import PageHeader from "../components/pageheader.jsx";
import { useApp } from "../context/appcontext.jsx";
import { useI18n } from "../i18n/i18nContext.jsx";

const API_BASE = "http://localhost:8080";

// ── Correspondance statuts backend → frontend ──────────────────────────────────
function backendToFrontend(statut) {
  return {
    "EN_ATTENTE":        "Nouveau",
    "ENTRETIEN":         "Entretien RH",
    "TEST_TECHNIQUE":    "Test technique",
    "ENTRETIEN_FINAL":   "Entretien final",
    "ACCEPTE":           "Retenu",
    "REFUSE":            "Refusé",
  }[statut] || "Nouveau";
}

function frontendToBackend(statut) {
  return {
    "Nouveau":          "EN_ATTENTE",
    "Entretien RH":     "ENTRETIEN",
    "Test technique":   "TEST_TECHNIQUE",
    "Entretien final":  "ENTRETIEN_FINAL",
    "Retenu":           "ACCEPTE",
    "Refusé":           "REFUSE",
  }[statut] || "EN_ATTENTE";
}

const STATUS_CFG = {
  "Nouveau":         { bg:"#E6F1FB", color:"#185FA5", border:"#B5D4F4",   dot:"#378ADD",  label:"Nouveau"         },
  "Entretien RH":    { bg:"#FEF9EC", color:"#92400E", border:"#92400E44", dot:"#F59E0B",  label:"Entretien RH"    },
  "Test technique":  { bg:"#F5F0FF", color:"#6D28D9", border:"#6D28D944", dot:"#8B5CF6",  label:"Test technique"  },
  "Entretien final": { bg:"#FFF7ED", color:"#C2410C", border:"#C2410C44", dot:"#F97316",  label:"Entretien final" },
  "Retenu":          { bg:"#ECFDF5", color:"#065F46", border:"#10B98155", dot:"#10B981",  label:"Retenu"          },
  "Refusé":          { bg:"#FEF2F2", color:"#991B1B", border:"#EF444455", dot:"#EF4444",  label:"Refusé"          },
};

const PIPELINE_STEPS = [
  { statut:"Nouveau",         icon:"📥", label:"Nouveaux"        },
  { statut:"Entretien RH",    icon:"🗣️", label:"Entretien RH"    },
  { statut:"Test technique",  icon:"🧪", label:"Test technique"  },
  { statut:"Entretien final", icon:"🎯", label:"Entretien final" },
  { statut:"Retenu",          icon:"✅", label:"Retenus"         },
  { statut:"Refusé",          icon:"❌", label:"Refusés"         },
];

const PIPELINE_BAR        = ["Nouveau","Entretien RH","Test technique","Entretien final"];
const PIPELINE_BAR_LABELS = ["Nouveau","RH","Test","Final"];
const AVATAR_COLORS       = ["#6366f1","#f59e0b","#10b981","#ef4444","#8b5cf6","#0891b2","#f43f5e","#059669"];

function getAvatarBg(nom) {
  let h = 0;
  for (let i = 0; i < nom.length; i++) h = nom.charCodeAt(i) + ((h << 5) - h);
  return AVATAR_COLORS[Math.abs(h) % AVATAR_COLORS.length];
}
function getInitials(nom) {
  return (nom || "").split(" ").map(w => w[0]).join("").slice(0, 2).toUpperCase();
}
function getToken() {
  return localStorage.getItem("token") || sessionStorage.getItem("token") || "";
}
function authHeaders() {
  return { "Content-Type":"application/json", Authorization:"Bearer " + getToken() };
}

// ─── Icônes SVG inline ────────────────────────────────────────────────────────
const Icons = {
  check:    <svg width="13" height="13" viewBox="0 0 16 16" fill="none"><path d="M3 8.5L6.5 12L13 5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  x:        <svg width="13" height="13" viewBox="0 0 16 16" fill="none"><path d="M4 4L12 12M12 4L4 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/></svg>,
  trash:    <svg width="13" height="13" viewBox="0 0 16 16" fill="none"><path d="M3 5h10M6 5V3h4v2M7 8v4M9 8v4M4 5l.8 8h6.4L12 5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  reset:    <svg width="13" height="13" viewBox="0 0 16 16" fill="none"><path d="M3 8a5 5 0 105-5H5M5 3L3 5l2 2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  map:      <svg width="12" height="12" viewBox="0 0 16 16" fill="none"><path d="M8 2a4 4 0 100 8A4 4 0 008 2zM8 14s-5-3-5-6a5 5 0 0110 0c0 3-5 6-5 6z" stroke="currentColor" strokeWidth="1.4"/></svg>,
  calendar: <svg width="12" height="12" viewBox="0 0 16 16" fill="none"><rect x="2" y="3" width="12" height="11" rx="2" stroke="currentColor" strokeWidth="1.4"/><path d="M5 2v2M11 2v2M2 7h12" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/></svg>,
  mobile:   <svg width="12" height="12" viewBox="0 0 16 16" fill="none"><rect x="4" y="1" width="8" height="14" rx="2" stroke="currentColor" strokeWidth="1.4"/><circle cx="8" cy="12.5" r=".8" fill="currentColor"/></svg>,
  refresh:  <svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M3 8a5 5 0 105-5H5M5 3L3 5l2 2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  file:     <svg width="13" height="13" viewBox="0 0 16 16" fill="none"><rect x="3" y="1" width="10" height="14" rx="2" stroke="currentColor" strokeWidth="1.4"/><path d="M6 5h4M6 8h4M6 11h2" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/></svg>,
  eye:      <svg width="13" height="13" viewBox="0 0 16 16" fill="none"><path d="M1 8s2.5-5 7-5 7 5 7 5-2.5 5-7 5S1 8 1 8z" stroke="currentColor" strokeWidth="1.4"/><circle cx="8" cy="8" r="2" stroke="currentColor" strokeWidth="1.4"/></svg>,
  download: <svg width="13" height="13" viewBox="0 0 16 16" fill="none"><path d="M8 2v8M5 7l3 3 3-3M3 13h10" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  chevron:  <svg width="11" height="11" viewBox="0 0 16 16" fill="none"><path d="M4 6l4 4 4-4" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  close:    <svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M4 4L12 12M12 4L4 12" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/></svg>,
  lock:     <svg width="12" height="12" viewBox="0 0 16 16" fill="none"><rect x="3" y="7" width="10" height="8" rx="2" stroke="currentColor" strokeWidth="1.4"/><path d="M5 7V5a3 3 0 016 0v2" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/></svg>,
};

// ─── Spinner ──────────────────────────────────────────────────────────────────
function Spinner({ size = 20, color = "#6D28D9", trackColor = "#E9D5FF" }) {
  return (
    <div style={{
      width: size, height: size,
      border: `2.5px solid ${trackColor}`,
      borderTopColor: color,
      borderRadius: "50%",
      animation: "cvSpin 0.8s linear infinite",
      flexShrink: 0,
    }} />
  );
}

// ─── Modale visionneuse CV ────────────────────────────────────────────────────
function CVModal({ candidatureId, nom, onClose }) {
  const [pdfUrl,    setPdfUrl]    = useState(null);
  const [loading,   setLoading]   = useState(true);
  const [error,     setError]     = useState(null);
  const [dlLoading, setDlLoading] = useState(false);

  useEffect(() => {
    setLoading(true);
    setError(null);
    fetch(`${API_BASE}/api/candidatures/${candidatureId}/cv`, {
      headers: { Authorization: "Bearer " + getToken() },
    })
      .then(r => {
        if (r.status === 404) throw new Error("Aucun CV disponible pour ce candidat.");
        if (!r.ok) throw new Error("Erreur serveur " + r.status);
        return r.blob();
      })
      .then(blob => {
        setPdfUrl(window.URL.createObjectURL(blob));
        setLoading(false);
      })
      .catch(err => {
        setError(err.message);
        setLoading(false);
      });
  }, [candidatureId]);

  useEffect(() => {
    return () => { if (pdfUrl) window.URL.revokeObjectURL(pdfUrl); };
  }, [pdfUrl]);

  useEffect(() => {
    const h = e => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [onClose]);

  async function handleDownload() {
    if (!pdfUrl || dlLoading) return;
    setDlLoading(true);
    const a = document.createElement("a");
    a.href = pdfUrl;
    a.download = `CV_${nom.replace(/\s+/g, "_")}.pdf`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => setDlLoading(false), 800);
  }

  return (
    <div
      onClick={e => { if (e.target === e.currentTarget) onClose(); }}
      style={{
        position:"fixed", inset:0, zIndex:1000,
        background:"rgba(15,23,42,0.6)",
        display:"flex", alignItems:"center", justifyContent:"center",
        padding:24,
        animation:"cvFadeIn .18s ease",
      }}
    >
      <div style={{
        background:"#fff", borderRadius:18,
        boxShadow:"0 32px 96px rgba(0,0,0,0.28)",
        width:"100%", maxWidth:800,
        display:"flex", flexDirection:"column",
        maxHeight:"90vh", overflow:"hidden",
        animation:"cvSlideUp .2s ease",
      }}>
        <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", padding:"16px 22px", borderBottom:"1px solid #F1F5F9", flexShrink:0 }}>
          <div style={{ display:"flex", alignItems:"center", gap:12 }}>
            <div style={{ width:38, height:38, borderRadius:10, background:"#F5F0FF", color:"#6D28D9", display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0 }}>
              {Icons.file}
            </div>
            <div>
              <div style={{ fontSize:15, fontWeight:700, color:"#0F172A", lineHeight:1.2 }}>CV — {nom}</div>
              <div style={{ fontSize:11, color:"#94A3B8", marginTop:2 }}>Curriculum vitae importé via l'application mobile</div>
            </div>
          </div>
          <div style={{ display:"flex", alignItems:"center", gap:8 }}>
            <button
              onClick={handleDownload}
              disabled={!pdfUrl || dlLoading}
              style={{ display:"inline-flex", alignItems:"center", gap:7, padding:"8px 16px", borderRadius:9, border:"1px solid #C0DD97", background:"#EAF3DE", color:"#3B6D11", fontSize:12, fontWeight:700, cursor: (!pdfUrl || dlLoading) ? "not-allowed" : "pointer", opacity: !pdfUrl ? 0.45 : 1, fontFamily:"inherit", transition:"all .15s" }}
              onMouseEnter={e => { if (pdfUrl && !dlLoading) e.currentTarget.style.background = "#C0DD97"; }}
              onMouseLeave={e => { e.currentTarget.style.background = "#EAF3DE"; }}
            >
              {dlLoading ? <Spinner size={13} color="#3B6D11" trackColor="#C0DD97" /> : Icons.download}
              {dlLoading ? "Téléchargement..." : "Télécharger le PDF"}
            </button>
            <button
              onClick={onClose}
              title="Fermer (Échap)"
              style={{ width:34, height:34, borderRadius:9, border:"1px solid #E2E8F0", background:"#F8FAFC", color:"#64748B", display:"flex", alignItems:"center", justifyContent:"center", cursor:"pointer", flexShrink:0 }}
              onMouseEnter={e => { e.currentTarget.style.background = "#FEF2F2"; e.currentTarget.style.color = "#A32D2D"; e.currentTarget.style.borderColor = "#F7C1C1"; }}
              onMouseLeave={e => { e.currentTarget.style.background = "#F8FAFC"; e.currentTarget.style.color = "#64748B"; e.currentTarget.style.borderColor = "#E2E8F0"; }}
            >
              {Icons.close}
            </button>
          </div>
        </div>

        <div style={{ flex:1, overflow:"auto", background:"#F8FAFC", minHeight:460 }}>
          {loading && (
            <div style={{ display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", height:400, gap:14, color:"#94A3B8" }}>
              <Spinner size={36} color="#6D28D9" trackColor="#E9D5FF" />
              <span style={{ fontSize:13 }}>Chargement du CV...</span>
            </div>
          )}
          {!loading && error && (
            <div style={{ display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", height:400, gap:10 }}>
              <div style={{ fontSize:40 }}>📄</div>
              <div style={{ fontSize:15, fontWeight:700, color:"#0F172A" }}>CV non disponible</div>
              <div style={{ fontSize:13, color:"#94A3B8", maxWidth:280, textAlign:"center" }}>{error}</div>
            </div>
          )}
          {!loading && !error && pdfUrl && (
            <iframe
              src={`${pdfUrl}#toolbar=0&navpanes=0&scrollbar=1`}
              title={`CV de ${nom}`}
              style={{ width:"100%", height:580, border:"none", display:"block" }}
            />
          )}
        </div>
      </div>
      <style>{`
        @keyframes cvFadeIn   { from{opacity:0} to{opacity:1} }
        @keyframes cvSlideUp  { from{opacity:0;transform:translateY(16px)} to{opacity:1;transform:none} }
        @keyframes cvSpin     { from{transform:rotate(0deg)} to{transform:rotate(360deg)} }
      `}</style>
    </div>
  );
}

// ─── Bouton CV avec menu déroulant ────────────────────────────────────────────
function CVDropdown({ candidatureId, nom }) {
  const [open,      setOpen]      = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [dlLoading, setDlLoading] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    const h = e => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);

  async function handleDownloadDirect() {
    setOpen(false);
    setDlLoading(true);
    try {
      const res = await fetch(`${API_BASE}/api/candidatures/${candidatureId}/cv`, {
        headers: { Authorization: "Bearer " + getToken() },
      });
      if (res.status === 404) throw new Error("Aucun CV disponible pour ce candidat.");
      if (!res.ok) throw new Error("Erreur serveur " + res.status);
      const blob = await res.blob();
      const url  = window.URL.createObjectURL(blob);
      const a    = document.createElement("a");
      a.href     = url;
      const disp = res.headers.get("Content-Disposition");
      a.download = disp?.match(/filename="?([^";\n]+)"?/)?.[1] || `CV_${nom.replace(/\s+/g, "_")}.pdf`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(url);
    } catch (err) {
      alert("⚠️ " + err.message);
    } finally {
      setDlLoading(false);
    }
  }

  return (
    <>
      {showModal && (
        <CVModal candidatureId={candidatureId} nom={nom} onClose={() => setShowModal(false)} />
      )}
      <div ref={ref} style={{ position:"relative", display:"inline-flex" }}>
        <button
          onClick={() => !dlLoading && setOpen(o => !o)}
          disabled={dlLoading}
          style={{ display:"inline-flex", alignItems:"center", gap:5, padding:"6px 12px", borderRadius:8, border:"1px solid #CECBF6", background: open ? "#CECBF6" : "#EEEDFE", color:"#3C3489", fontSize:12, fontWeight:600, cursor: dlLoading ? "not-allowed" : "pointer", opacity: dlLoading ? 0.65 : 1, fontFamily:"inherit", transition:"all .15s", userSelect:"none" }}
          onMouseEnter={e => { if (!open && !dlLoading) e.currentTarget.style.background = "#CECBF6"; }}
          onMouseLeave={e => { if (!open) e.currentTarget.style.background = "#EEEDFE"; }}
        >
          {dlLoading ? <Spinner size={12} color="#3C3489" trackColor="#CECBF6" /> : Icons.file}
          CV
          <span style={{ marginLeft:1, transform: open ? "rotate(180deg)" : "none", transition:"transform .2s", display:"inline-flex" }}>
            {Icons.chevron}
          </span>
        </button>

        {open && (
          <div style={{ position:"absolute", bottom:"calc(100% + 8px)", left:0, background:"#fff", border:"1px solid #E2E8F0", borderRadius:12, boxShadow:"0 12px 36px rgba(0,0,0,0.14)", minWidth:200, zIndex:200, overflow:"hidden", animation:"cvFadeMenu .15s ease" }}>
            <div style={{ padding:"8px 14px 6px", fontSize:10, fontWeight:700, color:"#94A3B8", letterSpacing:"0.06em", textTransform:"uppercase" }}>
              Options CV
            </div>
            <MenuItem
              icon={Icons.eye}
              iconBg="#E6F1FB"
              iconColor="#185FA5"
              label="Voir le CV"
              sub="Ouvrir dans la visionneuse"
              onClick={() => { setOpen(false); setShowModal(true); }}
              borderBottom
            />
            <MenuItem
              icon={Icons.download}
              iconBg="#EAF3DE"
              iconColor="#3B6D11"
              label="Télécharger"
              sub="Enregistrer en PDF"
              onClick={handleDownloadDirect}
            />
          </div>
        )}
        <style>{`
          @keyframes cvFadeMenu { from{opacity:0;transform:translateY(6px)} to{opacity:1;transform:none} }
          @keyframes cvSpin     { from{transform:rotate(0deg)} to{transform:rotate(360deg)} }
        `}</style>
      </div>
    </>
  );
}

function MenuItem({ icon, iconBg, iconColor, label, sub, onClick, borderBottom }) {
  const [hovered, setHovered] = useState(false);
  return (
    <button
      onClick={onClick}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{ display:"flex", alignItems:"center", gap:10, width:"100%", padding:"10px 14px", background: hovered ? "#F8FAFC" : "transparent", border:"none", borderBottom: borderBottom ? "1px solid #F1F5F9" : "none", cursor:"pointer", textAlign:"left", fontFamily:"inherit", transition:"background .1s" }}
    >
      <span style={{ width:30, height:30, borderRadius:8, background:iconBg, color:iconColor, display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0 }}>
        {icon}
      </span>
      <div>
        <div style={{ fontSize:12, fontWeight:700, color:"#0F172A", lineHeight:1.2 }}>{label}</div>
        <div style={{ fontSize:10, color:"#94A3B8", marginTop:2 }}>{sub}</div>
      </div>
    </button>
  );
}

// ─── Barre de progression pipeline ────────────────────────────────────────────
function PipelineBar({ statut }) {
  const idx = PIPELINE_BAR.indexOf(statut);
  return (
    <div style={{ marginTop:6 }}>
      <div style={{ display:"flex", gap:2, borderRadius:6, overflow:"hidden" }}>
        {PIPELINE_BAR.map((_, i) => (
          <div
            key={i}
            style={{
              flex:1, height:4,
              background: idx > i ? "#378ADD" : idx === i ? "rgba(55,138,221,0.35)" : "#F1F5F9",
              borderRight: i < 3 ? "1px solid #fff" : "none",
              transition:"background .3s",
            }}
          />
        ))}
      </div>
      <div style={{ display:"flex", marginTop:4 }}>
        {PIPELINE_BAR_LABELS.map((label, i) => (
          <div
            key={label}
            style={{ flex:1, fontSize:9, textAlign:"center", color: idx === i ? "#185FA5" : "#CBD5E1", fontWeight: idx === i ? 700 : 400 }}
          >
            {label}
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Bouton action ─────────────────────────────────────────────────────────────
const VARIANTS = {
  retain: { bg:"#EAF3DE", hbg:"#C0DD97", color:"#3B6D11", border:"#C0DD97" },
  reject: { bg:"#FCEBEB", hbg:"#F7C1C1", color:"#A32D2D", border:"#F7C1C1" },
  reset:  { bg:"#E6F1FB", hbg:"#B5D4F4", color:"#185FA5", border:"#B5D4F4" },
  delete: { bg:"transparent", hbg:"#FCEBEB", color:"#94A3B8", border:"#E2E8F0" },
};

function ActionBtn({ variant, icon, label, title, onClick, disabled }) {
  const [hovered, setHovered] = useState(false);
  const v = VARIANTS[variant] || VARIANTS.reset;
  const isDel = variant === "delete";
  return (
    <button
      onClick={onClick}
      title={title || label}
      disabled={disabled}
      onMouseEnter={() => !disabled && setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{ display:"inline-flex", alignItems:"center", gap:5, padding: isDel ? "6px 8px" : "6px 12px", borderRadius:8, border:`1px solid ${hovered && isDel ? "#F7C1C1" : v.border}`, background: hovered ? v.hbg : v.bg, color: hovered && isDel ? "#A32D2D" : v.color, fontSize:12, fontWeight:600, cursor: disabled ? "not-allowed" : "pointer", opacity: disabled ? 0.35 : 1, whiteSpace:"nowrap", fontFamily:"inherit", transition:"all .15s" }}
    >
      {icon && Icons[icon]}{label}
    </button>
  );
}

// ─── Avatar ────────────────────────────────────────────────────────────────────
function Avatar({ nom }) {
  const initials = (nom || "").split(" ").map(w => w[0]).join("").slice(0, 2).toUpperCase();
  return (
    <div style={{ width:46, height:46, borderRadius:"50%", background:"#E6F1FB", color:"#185FA5", display:"flex", alignItems:"center", justifyContent:"center", fontWeight:600, fontSize:15, flexShrink:0 }}>
      {initials}
    </div>
  );
}

// ─── Carte candidat ───────────────────────────────────────────────────────────
function CandidatCard({ c, canAct, onReject, onRetain, onDelete, onReset, onStatutChange }) {
  const sc         = STATUS_CFG[c.statut] || STATUS_CFG["Nouveau"];
  const isRetenu   = c.statut === "Retenu";
  const isRefuse   = c.statut === "Refusé";
  const isTermine  = isRetenu || isRefuse;
  const inPipeline = PIPELINE_BAR.includes(c.statut);

  return (
    <div
      style={{ borderRadius:14, border:`1px solid ${isRefuse ? "#FEE2E2" : isRetenu ? "#BBF7D0" : canAct ? "#E2E8F0" : "#F1F5F9"}`, background: isRefuse ? "#FEF9F9" : isRetenu ? "#F4FDF8" : canAct ? "#fff" : "#FAFAFA", overflow:"hidden", display:"flex", flexDirection:"column", transition:"box-shadow .2s, transform .2s", boxShadow:"0 1px 4px rgba(0,0,0,0.04)" }}
      onMouseEnter={e => { e.currentTarget.style.boxShadow="0 8px 28px rgba(0,0,0,0.09)"; e.currentTarget.style.transform="translateY(-2px)"; }}
      onMouseLeave={e => { e.currentTarget.style.boxShadow="0 1px 4px rgba(0,0,0,0.04)"; e.currentTarget.style.transform="none"; }}
    >
      {/* En-tête */}
      <div style={{ padding:"14px 18px 12px", borderBottom:"1px solid #F1F5F9", display:"flex", justifyContent:"space-between", alignItems:"flex-start", gap:8 }}>
        <div style={{ display:"flex", alignItems:"center", gap:10, flex:1, minWidth:0 }}>
          <Avatar nom={c.nom}/>
          <div style={{ minWidth:0 }}>
            <div style={{ fontSize:14, fontWeight:700, color:"#0F172A", lineHeight:1.2, whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" }}>{c.nom}</div>
            <div style={{ fontSize:12, color:"#94A3B8", marginTop:2, whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" }}>{c.poste}</div>
          </div>
        </div>
        <div style={{ display:"flex", flexDirection:"column", alignItems:"flex-end", gap:5 }}>
          <span style={{ fontSize:11, fontWeight:700, padding:"4px 10px", borderRadius:20, flexShrink:0, background:sc.bg, color:sc.color, border:`1px solid ${sc.border}`, display:"flex", alignItems:"center", gap:5 }}>
            <span style={{ width:6, height:6, borderRadius:"50%", background:sc.dot, display:"inline-block" }}/>
            {sc.label}
          </span>
          {/* Badge lecture seule si pas propriétaire */}
          {!canAct && (
            <span style={{ fontSize:10, padding:"2px 8px", borderRadius:20, background:"#F1F5F9", color:"#64748B", fontWeight:600, border:"1px solid #E2E8F0", display:"flex", alignItems:"center", gap:4 }}>
              {Icons.lock} Lecture seule
            </span>
          )}
        </div>
      </div>

      {/* Corps */}
      <div style={{ padding:"12px 18px", flex:1, display:"flex", flexDirection:"column", gap:8 }}>
        <div style={{ display:"flex", flexWrap:"wrap", gap:6 }}>
          {c.site && (
            <span style={{ display:"inline-flex", alignItems:"center", gap:4, background:"#F1F5F9", color:"#475569", padding:"3px 9px", borderRadius:20, fontSize:11, fontWeight:600 }}>
              {Icons.map} {c.site}
            </span>
          )}
          <span style={{ display:"inline-flex", alignItems:"center", gap:4, background:"#E6F1FB", color:"#185FA5", padding:"3px 9px", borderRadius:20, fontSize:11, fontWeight:700 }}>
            {Icons.mobile} Via App
          </span>
          <span style={{ display:"inline-flex", alignItems:"center", gap:4, background: c.candidatEmail ? "#ECFDF5" : "#FEF2F2", color: c.candidatEmail ? "#065F46" : "#991B1B", padding:"3px 9px", borderRadius:20, fontSize:11, fontWeight:700 }}>
            ✉ {c.candidatEmail || "—"}
          </span>
        </div>

        <div style={{ display:"flex", alignItems:"center", gap:5, fontSize:11, color:"#94A3B8" }}>
          {Icons.calendar} Postulé le {c.date}
        </div>

        {/* Select de statut — désactivé si lecture seule */}
        <select
          value={c.statut}
          onChange={e => canAct && onStatutChange(c.id, e.target.value)}
          disabled={!canAct}
          style={{ marginTop:4, padding:"6px 10px", borderRadius:8, border:"1px solid #E2E8F0", fontSize:12, fontFamily:"inherit", cursor: canAct ? "pointer" : "not-allowed", background: canAct ? "#fff" : "#F8FAFC", color:"#0F172A", opacity: canAct ? 1 : 0.6 }}
        >
          {PIPELINE_STEPS.map(s => (
            <option key={s.statut} value={s.statut}>{s.icon} {s.label}</option>
          ))}
        </select>

        {inPipeline && <PipelineBar statut={c.statut}/>}
      </div>

      {/* Pied de carte */}
      <div style={{ padding:"10px 18px", borderTop:"1px solid #F1F5F9", background: isRetenu ? "#F0FDF4" : isRefuse ? "#FEF2F2" : canAct ? "#F8FAFC" : "#F5F5F5", display:"flex", gap:6, flexWrap:"wrap", alignItems:"center" }}>
        {canAct && !isTermine && (
          <>
            <ActionBtn variant="retain" icon="check" label="Retenir" onClick={() => onRetain(c.id)}/>
            <ActionBtn variant="reject" icon="x"     label="Refuser" onClick={() => onReject(c.id)}/>
          </>
        )}
        {canAct && isTermine && (
          <ActionBtn variant="reset" icon="reset" label="Réinitialiser" onClick={() => onReset(c.id)}/>
        )}
        {!canAct && (
          <span style={{ fontSize:11, color:"#94A3B8", fontStyle:"italic" }}>Actions non disponibles</span>
        )}

        {/* CV toujours visible en lecture */}
        <CVDropdown candidatureId={c.id} nom={c.nom}/>

        {canAct && (
          <div style={{ marginLeft:"auto" }}>
            <ActionBtn variant="delete" icon="trash" title="Supprimer" onClick={() => onDelete(c.id)}/>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Bouton pagination ─────────────────────────────────────────────────────────
function PagBtn({ children, onClick, disabled }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      style={{ width:30, height:30, borderRadius:7, border:"1px solid #E2E8F0", background: disabled ? "#F8FAFC" : "#fff", color: disabled ? "#CBD5E1" : "#0F172A", cursor: disabled ? "default" : "pointer", fontSize:13, fontWeight:600, display:"flex", alignItems:"center", justifyContent:"center" }}
    >
      {children}
    </button>
  );
}

// ─── Page principale ───────────────────────────────────────────────────────────
export default function CandidatsPage() {
  const { addNotif, offers, currentUserId, currentUser } = useApp();
  const { t } = useI18n();

  const isAdmin = currentUser?.role?.toUpperCase() === "ADMIN";

  const [candidats,    setCandidats]    = useState([]);
  const [loading,      setLoading]      = useState(true);
  const [error,        setError]        = useState(null);
  const [filterStatut, setFilterStatut] = useState("Tous");
  const [search,       setSearch]       = useState("");
  const [currentPage,  setCurrentPage]  = useState(1);
  const perPage = 9;

  // IDs des offres appartenant au recruteur connecté
  const myOfferIds = (offers || [])
    .filter(o => String(o.createdBy) === String(currentUserId))
    .map(o => String(o.id));

  function fetchCandidatures() {
    setLoading(true);
    setError(null);
    fetch(`${API_BASE}/api/candidatures`, { headers: authHeaders() })
      .then(r => {
        if (!r.ok) throw new Error("Erreur " + r.status);
        return r.json();
      })
      .then(data => {
        setCandidats(data.map(c => ({
          id:            c.id,
          candidatId:    c.candidatId,
          nom:           c.candidatNom    || "—",
          poste:         c.offreTitre     || "—",
          site:          c.site           || c.departement || "",
          date:          (c.dateCandidature || "").substring(0, 10),
          statut:        backendToFrontend(c.statut),
          candidatEmail: c.candidatEmail  || "",
          offreId:       c.offreId        || null,
        })));
        setLoading(false);
      })
      .catch(err => {
        setError("Impossible de charger les candidatures : " + err.message);
        setLoading(false);
      });
  }

  useEffect(() => { fetchCandidatures(); }, []);

  // Détermine si le recruteur connecté peut agir sur une candidature donnée
  function canActOn(c) {
    if (isAdmin) return true;
    return myOfferIds.includes(String(c.offreId));
  }

  function updateStatutAPI(id, newStatutFrontend) {
    setCandidats(prev => prev.map(c => c.id === id ? { ...c, statut: newStatutFrontend } : c));
    const backendStatut = frontendToBackend(newStatutFrontend);
    fetch(`${API_BASE}/api/candidatures/${id}/statut`, {
      method: "PUT",
      headers: authHeaders(),
      body: JSON.stringify({ statut: backendStatut }),
    }).catch(() => fetchCandidatures());
  }

  function getCandidatById(id) { return candidats.find(c => c.id === id) || {}; }

  function deleteCandidat(id) {
    const c = getCandidatById(id);
    if (!canActOn(c)) return;
    setCandidats(prev => prev.filter(x => x.id !== id));
    addNotif({
      type:"candidature",
      titre:"Candidature supprimée",
      message:`La candidature de ${c.nom} a été supprimée.`,
      avatar: getInitials(c.nom),
      avatarBg: getAvatarBg(c.nom || ""),
    });
  }

  function handleRetain(id) {
    const c = getCandidatById(id);
    if (!canActOn(c)) return;
    updateStatutAPI(id, "Retenu");
    addNotif({ type:"validation", titre:"Candidat retenu", message:`${c.nom} a été retenu.`, avatar: getInitials(c.nom), avatarBg:"#10b981" });
  }

  function handleReject(id) {
    const c = getCandidatById(id);
    if (!canActOn(c)) return;
    updateStatutAPI(id, "Refusé");
    addNotif({ type:"candidature", titre:"Candidat refusé", message:`${c.nom} a été refusé.`, avatar: getInitials(c.nom), avatarBg:"#ef4444" });
  }

  function handleReset(id) {
    const c = getCandidatById(id);
    if (!canActOn(c)) return;
    updateStatutAPI(id, "Nouveau");
    addNotif({ type:"candidature", titre:"Réinitialisé", message:`${c.nom} remis en "Nouveau".`, avatar: getInitials(c.nom), avatarBg:"#6366f1" });
  }

  // Compteurs basés sur toutes les candidatures visibles
  const counts = PIPELINE_STEPS.reduce((acc, s) => {
    acc[s.statut] = candidats.filter(c => c.statut === s.statut).length;
    return acc;
  }, {});

  const filtered = candidats.filter(c => {
    const matchStatus = filterStatut === "Tous" || c.statut === filterStatut;
    const q = search.toLowerCase();
    const matchSearch = !q
      || c.nom?.toLowerCase().includes(q)
      || c.poste?.toLowerCase().includes(q)
      || c.site?.toLowerCase().includes(q)
      || c.candidatEmail?.toLowerCase().includes(q);
    return matchStatus && matchSearch;
  });

  const totalPages = Math.max(1, Math.ceil(filtered.length / perPage));
  const paginated  = filtered.slice((currentPage - 1) * perPage, currentPage * perPage);

  function goPage(p) { setCurrentPage(Math.max(1, Math.min(p, totalPages))); }
  function handleFilter(s) { setFilterStatut(s); setCurrentPage(1); }

  const nouveauxCount = counts["Nouveau"] ?? 0;

  // Nombre de candidatures sur lesquelles le recruteur peut agir
  const myActionableCount = candidats.filter(c => canActOn(c)).length;

  return (
    <div>
      <PageHeader
        title="Gestion des candidatures"
        subtitle="Candidatures reçues via l'application mobile"
      />

      {/* Bandeau info recruteur */}
      {!isAdmin && (
        <div style={{ marginBottom:16, padding:"10px 16px", borderRadius:10, background:"#F5F3FF", border:"1px solid #C7D2FE", fontSize:12, color:"#4338CA", display:"flex", alignItems:"center", gap:8 }}>
          👤 <span>Vous pouvez modifier, archiver et supprimer uniquement les candidatures liées à <strong>vos offres</strong> ({myActionableCount} candidature{myActionableCount > 1 ? "s" : ""}).</span>
        </div>
      )}

      <div style={{ background:"#fff", borderRadius:14, border:"2px solid var(--blue)", boxShadow:"var(--shadow-sm)", overflow:"hidden" }}>

        {/* Barre d'outils */}
        <div style={{ padding:"16px 24px", borderBottom:"1px solid #F1F5F9", display:"flex", alignItems:"center", justifyContent:"space-between", gap:16, flexWrap:"wrap" }}>
          <div style={{ display:"flex", alignItems:"center", gap:12 }}>
            <h3 style={{ fontSize:15, fontWeight:700, color:"var(--blue)", margin:0 }}>Liste des candidatures</h3>
            <button
              onClick={fetchCandidatures}
              title="Rafraîchir"
              style={{ display:"flex", alignItems:"center", gap:4, padding:"5px 10px", borderRadius:8, border:"1px solid #E2E8F0", background:"#fff", color:"#94A3B8", fontSize:12, cursor:"pointer", fontFamily:"inherit" }}
            >
              {Icons.refresh} Actualiser
            </button>
          </div>
          <div style={{ display:"flex", gap:10, alignItems:"center", flexWrap:"wrap" }}>
            <input
              value={search}
              onChange={e => { setSearch(e.target.value); setCurrentPage(1); }}
              placeholder="Rechercher..."
              style={{ width:200, padding:"7px 12px", borderRadius:9, border:"1.5px solid #E2E8F0", fontSize:13, fontFamily:"inherit", outline:"none" }}
            />
            {["Tous", ...PIPELINE_STEPS.map(s => s.statut)].map(s => {
              const cfg = STATUS_CFG[s];
              const isActive = filterStatut === s;
              return (
                <button
                  key={s}
                  onClick={() => handleFilter(s)}
                  style={{ padding:"6px 14px", borderRadius:20, fontSize:12, fontWeight:600, cursor:"pointer", border:"1.5px solid", position:"relative", borderColor: isActive ? "var(--blue)" : "#E2E8F0", background: isActive ? "var(--blue)" : "transparent", color: isActive ? "#fff" : "#64748B", transition:"all .15s", fontFamily:"inherit" }}
                >
                  {s !== "Tous" && cfg?.dot && !isActive && (
                    <span style={{ display:"inline-block", width:6, height:6, borderRadius:"50%", background:cfg.dot, marginRight:4, verticalAlign:"middle" }}/>
                  )}
                  {s === "Tous" ? "Tous" : s}
                  {s === "Nouveau" && nouveauxCount > 0 && (
                    <span style={{ position:"absolute", top:-6, right:-6, background:"#3B82F6", color:"#fff", borderRadius:"50%", width:16, height:16, fontSize:10, fontWeight:700, display:"flex", alignItems:"center", justifyContent:"center" }}>
                      {nouveauxCount}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* État chargement */}
        {loading && (
          <div style={{ textAlign:"center", padding:"48px 24px", color:"#94A3B8", fontSize:14 }}>
            ⏳ Chargement des candidatures...
          </div>
        )}

        {/* État erreur */}
        {!loading && error && (
          <div style={{ textAlign:"center", padding:"48px 24px" }}>
            <div style={{ color:"#ef4444", fontSize:14, marginBottom:12 }}>⚠️ {error}</div>
            <button
              onClick={fetchCandidatures}
              style={{ padding:"8px 20px", borderRadius:8, border:"none", background:"var(--blue)", color:"#fff", fontSize:13, cursor:"pointer", fontFamily:"inherit" }}
            >
              Réessayer
            </button>
          </div>
        )}

        {/* Grille de cartes */}
        {!loading && !error && (
          <>
            {paginated.length === 0 ? (
              <div style={{ textAlign:"center", padding:"48px 24px", color:"#94A3B8", fontSize:14 }}>
                {candidats.length === 0
                  ? "Aucune candidature reçue pour l'instant."
                  : "Aucun résultat pour cette recherche."}
              </div>
            ) : (
              <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill, minmax(300px, 1fr))", gap:16, padding:"20px" }}>
                {paginated.map(c => (
                  <CandidatCard
                    key={c.id}
                    c={c}
                    canAct={canActOn(c)}
                    onReject={id  => handleReject(id)}
                    onRetain={id  => handleRetain(id)}
                    onReset={id   => handleReset(id)}
                    onDelete={id  => deleteCandidat(id)}
                    onStatutChange={(id, s) => updateStatutAPI(id, s)}
                  />
                ))}
              </div>
            )}

            {/* Pagination */}
            <div style={{ padding:"12px 24px", borderTop:"1px solid #F1F5F9", display:"flex", alignItems:"center", justifyContent:"space-between", flexWrap:"wrap", gap:12 }}>
              <span style={{ fontSize:13, color:"#94A3B8" }}>
                {filtered.length === 0
                  ? "0"
                  : `${Math.min((currentPage-1)*perPage+1, filtered.length)}–${Math.min(currentPage*perPage, filtered.length)}`
                } sur {filtered.length} candidature{filtered.length > 1 ? "s" : ""}
              </span>
              <div style={{ display:"flex", alignItems:"center", gap:6 }}>
                <PagBtn onClick={() => goPage(1)}              disabled={currentPage===1}>|&lt;</PagBtn>
                <PagBtn onClick={() => goPage(currentPage-1)}  disabled={currentPage===1}>&lt;</PagBtn>
                <span style={{ fontSize:13, fontWeight:600, color:"#0F172A", padding:"0 8px" }}>
                  Page {currentPage} / {totalPages}
                </span>
                <PagBtn onClick={() => goPage(currentPage+1)}  disabled={currentPage===totalPages}>&gt;</PagBtn>
                <PagBtn onClick={() => goPage(totalPages)}     disabled={currentPage===totalPages}>&gt;|</PagBtn>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}