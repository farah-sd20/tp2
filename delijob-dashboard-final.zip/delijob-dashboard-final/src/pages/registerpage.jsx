import { useState, useRef } from "react";
import Navbar          from "../components/navbar.jsx";
import Button          from "../components/button.jsx";
import Alert           from "../components/alert.jsx";
import FormField       from "../components/formfield.jsx";
import { useApp }      from "../context/appcontext.jsx";
import { useI18n }     from "../i18n/i18nContext.jsx";
import { DEPARTMENTS } from "../data/mock.js";

function PasswordStrength({ value, t }) {
  const rules = [
    { ok: value.length >= 8,          label: "8 min" },
    { ok: /[A-Z]/.test(value),        label: "A-Z" },
    { ok: /[0-9]/.test(value),        label: "0-9" },
    { ok: /[^A-Za-z0-9]/.test(value), label: "!@#" },
  ];
  const score  = rules.filter(r => r.ok).length;
  const colors = ["#E24B4A", "#EF9F27", "#1D9E75", "#1D9E75"];
  const labels = ["Très faible", "Moyen", "Fort", "Très fort"];
  if (!value) return null;
  return (
    <div style={{ marginTop: 8 }}>
      <div style={{ display: "flex", gap: 4, marginBottom: 5 }}>
        {[0,1,2,3].map(i => (
          <div key={i} style={{ flex: 1, height: 4, borderRadius: 2, background: i < score ? colors[score-1] : "var(--border)", transition: "background 0.25s" }} />
        ))}
      </div>
      <p style={{ fontSize: 11, fontWeight: 600, color: colors[score-1], margin: "0 0 5px" }}>{labels[score-1]}</p>
      {rules.map((r, i) => (
        <p key={i} style={{ fontSize: 11, margin: "2px 0", color: r.ok ? "#1D9E75" : "var(--muted)", display: "flex", alignItems: "center", gap: 5 }}>
          <span style={{ display: "inline-block", width: 7, height: 7, borderRadius: "50%", background: r.ok ? "#1D9E75" : "var(--border)", flexShrink: 0 }} />
          {r.label}
        </p>
      ))}
    </div>
  );
}

function EyeIcon({ visible }) {
  return visible ? (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>
    </svg>
  ) : (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/>
      <line x1="1" y1="1" x2="23" y2="23"/>
    </svg>
  );
}

function PasswordInput({ value, onChange, placeholder = "••••••••", disabled }) {
  const [show, setShow] = useState(false);
  return (
    <div style={{ position: "relative" }}>
      <input type={show ? "text" : "password"} value={value} onChange={onChange}
        placeholder={placeholder} disabled={disabled}
        style={{ paddingRight: 36, width: "100%", boxSizing: "border-box" }} />
      <button type="button" onClick={() => setShow(v => !v)} tabIndex={-1}
        style={{ position: "absolute", right: 10, top: "50%", transform: "translateY(-50%)", background: "none", border: "none", cursor: "pointer", padding: 0, color: "var(--muted)", display: "flex", alignItems: "center" }}>
        <EyeIcon visible={show} />
      </button>
    </div>
  );
}

function PhotoUpload({ value, onChange, disabled, t }) {
  const inputRef = useRef(null);

  function handleFile(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) return;
    if (file.size > 5 * 1024 * 1024) { alert(t("register.photoDesc")); return; }
    onChange(file);
  }

  function handleRemove(e) {
    e.stopPropagation();
    onChange(null);
    if (inputRef.current) inputRef.current.value = "";
  }

  const preview = value ? URL.createObjectURL(value) : null;

  return (
    <div style={{ display: "flex", alignItems: "center", gap: 16, marginBottom: 20 }}>
      <div onClick={() => !disabled && inputRef.current?.click()}
        style={{ width: 72, height: 72, borderRadius: "50%", border: `2px dashed ${preview ? "var(--blue)" : "var(--border)"}`, background: preview ? "transparent" : "var(--warm)", display: "flex", alignItems: "center", justifyContent: "center", cursor: disabled ? "default" : "pointer", overflow: "hidden", flexShrink: 0 }}>
        {preview ? (
          <img src={preview} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
        ) : (
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="var(--muted)" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
            <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/>
            <circle cx="12" cy="13" r="4"/>
          </svg>
        )}
      </div>
      <div>
        <p style={{ fontSize: 13, fontWeight: 600, color: "var(--dark)", margin: "0 0 3px" }}>
          {t("register.photoOptionnelle")}
          <span style={{ fontWeight: 400, color: "var(--muted)", marginLeft: 6 }}>{t("register.optionnel")}</span>
        </p>
        <p style={{ fontSize: 11, color: "var(--muted)", margin: "0 0 8px", lineHeight: 1.4 }}>{t("register.photoDesc")}</p>
        <div style={{ display: "flex", gap: 8 }}>
          <button type="button" onClick={() => !disabled && inputRef.current?.click()} disabled={disabled}
            style={{ fontSize: 11, fontWeight: 600, padding: "4px 10px", borderRadius: 6, border: "1px solid var(--border)", background: "var(--white)", color: "var(--dark)", cursor: disabled ? "default" : "pointer" }}>
            {preview ? t("register.changer") : t("register.choisir")}
          </button>
          {preview && (
            <button type="button" onClick={handleRemove} disabled={disabled}
              style={{ fontSize: 11, fontWeight: 600, padding: "4px 10px", borderRadius: 6, border: "1px solid #fcc", background: "#fff5f5", color: "#E24B4A", cursor: disabled ? "default" : "pointer" }}>
              {t("register.supprimerPhoto")}
            </button>
          )}
        </div>
      </div>
      <input ref={inputRef} type="file" accept="image/*" onChange={handleFile} style={{ display: "none" }} disabled={disabled} />
    </div>
  );
}

const EMPTY = { prenom: "", nom: "", email: "", dept: "", pass: "", pass2: "" };
const API_BASE = "http://localhost:8080";

export default function RegisterPage() {
  const { navigate } = useApp();
  const { t } = useI18n();
  const [form,    setForm]    = useState(EMPTY);
  const [photo,   setPhoto]   = useState(null);
  const [alert,   setAlert]   = useState(null);
  const [loading, setLoading] = useState(false);

  function set(key, val) { setForm(f => ({ ...f, [key]: val })); }

  function validate() {
    const { prenom, nom, email, dept, pass, pass2 } = form;
    if (!prenom || !nom || !email || !dept || !pass || !pass2) return "Tous les champs sont requis.";
    if (!/\S+@\S+\.\S+/.test(email)) return "Email invalide.";
    if (pass.length < 8) return "8 caractères minimum.";
    if (!/[A-Z]/.test(pass)) return "Majuscule requise.";
    if (!/[0-9]/.test(pass)) return "Chiffre requis.";
    if (!/[^A-Za-z0-9]/.test(pass)) return "Caractère spécial requis.";
    if (pass !== pass2) return t("register.neCorrespondentPas");
    return null;
  }

  async function submit() {
    const error = validate();
    if (error) { setAlert({ type: "error", message: error }); return; }
    setAlert(null); setLoading(true);
    try {
      const body = new FormData();
      body.append("prenom",      form.prenom);
      body.append("nom",         form.nom);
      body.append("email",       form.email);
      body.append("departement", form.dept);
      body.append("password",    form.pass);
      if (photo) body.append("photo", photo);

      const res = await fetch(`${API_BASE}/api/auth/register`, { method: "POST", body });
      let data = {};
      try { data = await res.json(); } catch {}
      if (!res.ok) {
        const msg = (Array.isArray(data.errors) && data.errors[0]?.defaultMessage) || data.error || data.message || `Erreur (${res.status}).`;
        setAlert({ type: "error", message: msg }); return;
      }
      setAlert({ type: "success", message: data.message || t("register.subtitle") });
      setForm(EMPTY); setPhoto(null);
      setTimeout(() => navigate("login"), 2500);
    } catch {
      setAlert({ type: "error", message: "Impossible de contacter le serveur." });
    } finally {
      setLoading(false);
    }
  }

  const passMatch = form.pass2.length > 0 ? form.pass === form.pass2 : null;

  return (
    <div onKeyDown={e => e.key === "Enter" && !loading && submit()}
      style={{ minHeight: "100vh", display: "flex", flexDirection: "column", background: "var(--warm)" }}>
      <Navbar showActions={false} />
      <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", padding: "40px 20px" }}>
        <div className="fade-up" style={{ background: "var(--white)", borderRadius: 22, padding: "40px 44px", width: "100%", maxWidth: 500, boxShadow: "var(--shadow-lg)", border: "1px solid var(--border)" }}>

          <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 6 }}>
            <div style={{ width: 4, height: 30, background: "var(--blue)", borderRadius: 2 }} />
            <h2 style={{ fontFamily: "var(--font-serif)", fontSize: 25, fontWeight: 800, color: "var(--dark)" }}>
              {t("register.titre")}
            </h2>
          </div>
          <p style={{ fontSize: 13, color: "var(--muted)", paddingLeft: 16, marginBottom: 24, lineHeight: 1.5 }}>
            {t("register.subtitle")}
          </p>

          <Alert {...(alert || {})} />
          <PhotoUpload value={photo} onChange={setPhoto} disabled={loading} t={t} />

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
            <FormField label={t("register.prenom")}>
              <input value={form.prenom} onChange={e => set("prenom", e.target.value)} placeholder="Mohamed" disabled={loading} />
            </FormField>
            <FormField label={t("register.nom")}>
              <input value={form.nom} onChange={e => set("nom", e.target.value)} placeholder="Ben Ali" disabled={loading} />
            </FormField>
          </div>

          <FormField label={t("register.email")}>
            <input type="email" value={form.email} onChange={e => set("email", e.target.value)}
              placeholder="m.benali@delice-danone.com.tn" disabled={loading} />
          </FormField>

          <FormField label={t("register.departement")}>
            <select value={form.dept} onChange={e => set("dept", e.target.value)} disabled={loading}>
              <option value="">—</option>
              {DEPARTMENTS.map(d => <option key={d}>{d}</option>)}
            </select>
          </FormField>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
            <FormField label={t("register.motDePasse")}>
              <PasswordInput value={form.pass} onChange={e => set("pass", e.target.value)} disabled={loading} />
              <PasswordStrength value={form.pass} t={t} />
            </FormField>
            <FormField label={t("register.confirmer")}>
              <PasswordInput value={form.pass2} onChange={e => set("pass2", e.target.value)} disabled={loading} />
              {passMatch !== null && (
                <p style={{ fontSize: 11, marginTop: 6, color: passMatch ? "#1D9E75" : "#E24B4A", display: "flex", alignItems: "center", gap: 5 }}>
                  <span style={{ display: "inline-block", width: 7, height: 7, borderRadius: "50%", background: passMatch ? "#1D9E75" : "#E24B4A", flexShrink: 0 }} />
                  {passMatch ? t("register.correspondent") : t("register.neCorrespondentPas")}
                </p>
              )}
            </FormField>
          </div>

          <Button variant="primary" fullWidth size="xl" onClick={submit} disabled={loading} style={{ marginTop: 8 }}>
            {loading ? t("register.envoiEnCours") : t("register.envoyer")}
          </Button>

          <p style={{ textAlign: "center", fontSize: 13, color: "var(--muted)", marginTop: 18 }}>
            {t("register.dejaCompte")}{" "}
            <span onClick={() => navigate("login")} style={{ color: "var(--blue)", fontWeight: 600, cursor: "pointer" }}>
              {t("register.seConnecter")}
            </span>
          </p>
        </div>
      </div>
    </div>
  );
}