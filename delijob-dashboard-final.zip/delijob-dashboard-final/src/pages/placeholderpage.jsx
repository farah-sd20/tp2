import PageHeader from "../components/pageheader.jsx";

export default function PlaceholderPage({ title, subtitle, icon }) {
  return (
    <div>
      <PageHeader title={title} subtitle={subtitle} />
      <div style={{
        background:"var(--white)", borderRadius:14,
        border:"1px solid var(--border)",
        padding:"80px 40px",
        textAlign:"center",
        boxShadow:"var(--shadow-sm)",
      }}>
        <div style={{ fontSize:56, marginBottom:16 }}>{icon}</div>
        <div style={{ fontFamily:"var(--font-serif)", fontSize:20, fontWeight:700, color:"var(--dark)", marginBottom:8 }}>
          {title}
        </div>
        <div style={{ fontSize:14, color:"var(--muted)" }}>
          Cette section est en cours de développement.
        </div>
      </div>
    </div>
  );
}
