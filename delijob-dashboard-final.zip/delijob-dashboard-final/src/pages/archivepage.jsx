import { useState } from "react";
import { useApp } from "../context/appcontext.jsx";
import PageHeader from "../components/pageheader.jsx";
import { useI18n } from "../i18n/i18nContext.jsx";

// ─── Icons ────────────────────────────────────────────────────────────────────
const Icons = {
  briefcase: (
    <svg width="15" height="15" viewBox="0 0 16 16" fill="none">
      <rect x="1" y="5" width="14" height="9" rx="2" stroke="currentColor" strokeWidth="1.5"/>
      <path d="M5 5V4a3 3 0 016 0v1" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
      <line x1="1" y1="9" x2="15" y2="9" stroke="currentColor" strokeWidth="1.5"/>
    </svg>
  ),
  interview: (
    <svg width="15" height="15" viewBox="0 0 16 16" fill="none">
      <circle cx="6" cy="5" r="3" stroke="currentColor" strokeWidth="1.5"/>
      <path d="M1 14c0-3 2.2-5 5-5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
      <path d="M10 10l1.5 1.5L14 8.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
      <circle cx="12" cy="11" r="3.5" stroke="currentColor" strokeWidth="1.2"/>
    </svg>
  ),
  clock: (
    <svg width="13" height="13" viewBox="0 0 16 16" fill="none">
      <circle cx="8" cy="8" r="6" stroke="currentColor" strokeWidth="1.5"/>
      <path d="M8 5v3.5l2.5 1.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
    </svg>
  ),
  user: (
    <svg width="13" height="13" viewBox="0 0 16 16" fill="none">
      <circle cx="8" cy="5" r="3" stroke="currentColor" strokeWidth="1.5"/>
      <path d="M2 14c0-3 2.7-5 6-5s6 2 6 5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
    </svg>
  ),
  tag: (
    <svg width="12" height="12" viewBox="0 0 16 16" fill="none">
      <path d="M2 2h5l7 7-5 5-7-7V2z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round"/>
      <circle cx="5.5" cy="5.5" r="1" fill="currentColor"/>
    </svg>
  ),
  check: (
    <svg width="13" height="13" viewBox="0 0 16 16" fill="none">
      <path d="M3 8.5L6.5 12L13 5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  x: (
    <svg width="13" height="13" viewBox="0 0 16 16" fill="none">
      <path d="M4 4L12 12M12 4L4 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
    </svg>
  ),
  calendar: (
    <svg width="13" height="13" viewBox="0 0 16 16" fill="none">
      <rect x="1" y="3" width="14" height="12" rx="2" stroke="currentColor" strokeWidth="1.5"/>
      <path d="M1 7h14M5 1v4M11 1v4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
    </svg>
  ),
  search: (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="none">
      <circle cx="7" cy="7" r="5" stroke="currentColor" strokeWidth="1.5"/>
      <path d="M11 11l3 3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
    </svg>
  ),
  archive: (
    <svg width="15" height="15" viewBox="0 0 16 16" fill="none">
      <rect x="1" y="3" width="14" height="3" rx="1" stroke="currentColor" strokeWidth="1.5"/>
      <path d="M2 6v7a1 1 0 001 1h10a1 1 0 001-1V6" stroke="currentColor" strokeWidth="1.5"/>
      <path d="M6 10h4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
    </svg>
  ),
  empty: (
    <svg width="40" height="40" viewBox="0 0 48 48" fill="none">
      <rect x="6" y="10" width="36" height="28" rx="4" stroke="currentColor" strokeWidth="2" opacity="0.3"/>
      <path d="M6 18h36" stroke="currentColor" strokeWidth="2" opacity="0.3"/>
      <path d="M18 30h12M18 34h8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" opacity="0.3"/>
    </svg>
  ),
};

// ─── Status configs ───────────────────────────────────────────────────────────
const OFFER_STATUS = {
  "Fermé":    { bg:"#FDF0EE", color:"#C0392B", label:"Clôturée" },
  "En pause": { bg:"#FEF9EC", color:"#9A7D0A", label:"En pause" },
};

const INTERVIEW_STATUS = {
  "Réalisé":  { bg:"#EBF7EF", color:"#16a34a", icon: Icons.check, label:"Réalisé"  },
  "Annulé":   { bg:"#FDF0EE", color:"#C0392B", icon: Icons.x,     label:"Annulé"   },
  "No-show":  { bg:"#FEF9EC", color:"#9A7D0A", icon: Icons.x,     label:"No-show"  },
  "Refusé":   { bg:"#FDF0EE", color:"#C0392B", icon: Icons.x,     label:"Refusé"   },
};

// ─── Helpers ──────────────────────────────────────────────────────────────────
function fmtDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString("fr-FR", {
    day:"2-digit", month:"short", year:"numeric",
  });
}
function fmtDateTime(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleString("fr-FR", {
    day:"2-digit", month:"short", year:"numeric",
    hour:"2-digit", minute:"2-digit",
  });
}

// ─── Stat strip ───────────────────────────────────────────────────────────────
function StatStrip({ items }) {
  return (
    <div style={{ display:"flex", gap:12, flexWrap:"wrap", marginBottom:24 }}>
      {items.map(({ label, value, bg, color, icon }) => (
        <div key={label} style={{
          flex:1, minWidth:120, borderRadius:12, padding:"13px 18px",
          background:bg, border:`1.5px solid ${color}33`,
          display:"flex", flexDirection:"column", gap:3,
        }}>
          <div style={{ fontSize:17 }}>{icon}</div>
          <div style={{ fontSize:20, fontWeight:800, color }}>{value}</div>
          <div style={{ fontSize:11, fontWeight:600, color, opacity:0.75, textTransform:"uppercase", letterSpacing:"0.5px" }}>{label}</div>
        </div>
      ))}
    </div>
  );
}

// ─── Section header ───────────────────────────────────────────────────────────
function SectionHeader({ icon, title, count, search, onSearch, placeholder }) {
  const { t } = useI18n();
  return (
    <div style={{
      padding:"14px 20px", borderBottom:"1px solid var(--border)",
      display:"flex", alignItems:"center", justifyContent:"space-between",
      gap:12, flexWrap:"wrap",
    }}>
      <div style={{ display:"flex", alignItems:"center", gap:10 }}>
        <span style={{
          width:32, height:32, borderRadius:9,
          background:"#EEF2FF", color:"#4F46E5",
          display:"flex", alignItems:"center", justifyContent:"center",
        }}>{icon}</span>
        <div>
          <div style={{ fontSize:14, fontWeight:700, color:"var(--dark)" }}>{title}</div>
          <div style={{ fontSize:11, color:"var(--muted)" }}>{count} {t("archive.elements")}{count !== 1 ? "s" : ""}</div>
        </div>
      </div>
      <div style={{ position:"relative" }}>
        <span style={{ position:"absolute", left:10, top:"50%", transform:"translateY(-50%)", color:"var(--muted)", pointerEvents:"none" }}>
          {Icons.search}
        </span>
        <input
          value={search}
          onChange={e => onSearch(e.target.value)}
          placeholder={placeholder}
          style={{
            paddingLeft:32, paddingRight:12, paddingTop:7, paddingBottom:7,
            width:200, borderRadius:9, border:"1.5px solid var(--border)",
            fontSize:13, fontFamily:"var(--font-sans)", outline:"none",
          }}
        />
      </div>
    </div>
  );
}

// ─── Archived Offer Card ──────────────────────────────────────────────────────
function ArchivedOfferCard({ o }) {
  const sc = OFFER_STATUS[o.statut] || OFFER_STATUS["Fermé"];
  const { t } = useI18n();
  return (
    <div style={{
      borderRadius:13, border:"1.5px solid var(--border)",
      background:"var(--white)", overflow:"hidden",
      boxShadow:"0 1px 8px rgba(0,0,0,0.04)",
      transition:"box-shadow .2s, transform .2s",
      opacity: 0.88,
    }}
      onMouseEnter={e => { e.currentTarget.style.boxShadow="0 4px 16px rgba(0,0,0,0.09)"; e.currentTarget.style.opacity="1"; e.currentTarget.style.transform="translateY(-1px)"; }}
      onMouseLeave={e => { e.currentTarget.style.boxShadow="0 1px 8px rgba(0,0,0,0.04)"; e.currentTarget.style.opacity="0.88"; e.currentTarget.style.transform="none"; }}
    >
      {/* Top stripe */}
      <div style={{ height:3, background:`linear-gradient(90deg, ${sc.color}66, ${sc.color}22)` }}/>

      <div style={{ padding:"14px 16px" }}>
        {/* Header row */}
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", gap:8, marginBottom:10 }}>
          <div>
            <div style={{ fontSize:10, fontWeight:700, color:"var(--blue)", textTransform:"uppercase", letterSpacing:"0.5px", marginBottom:3 }}>
              {o.code}
            </div>
            <div style={{ fontSize:14, fontWeight:700, color:"var(--dark)", lineHeight:1.3 }}>{o.titre}</div>
            <div style={{ fontSize:11, color:"var(--muted)", marginTop:2 }}>{o.dept}</div>
          </div>
          <span style={{
            fontSize:10, fontWeight:700, padding:"3px 9px", borderRadius:20,
            background:sc.bg, color:sc.color, flexShrink:0,
            display:"flex", alignItems:"center", gap:4, border:`1px solid ${sc.color}33`,
          }}>
            <span style={{ width:5, height:5, borderRadius:"50%", background:sc.color }}/>
            {t(`archive.offerStatus${sc.label.replace(/\s/g, '')}`)}
          </span>
        </div>

        {/* Tags */}
        <div style={{ display:"flex", gap:6, flexWrap:"wrap", marginBottom:12 }}>
          <span style={{
            display:"inline-flex", alignItems:"center", gap:4,
            background:"var(--blue-light)", color:"var(--blue)",
            padding:"2px 9px", borderRadius:20, fontWeight:600, fontSize:10,
          }}>
            {Icons.tag}{o.type}
          </span>
          <span style={{
            display:"inline-flex", alignItems:"center", gap:4,
            background:"#F1F5F9", color:"#475569",
            padding:"2px 9px", borderRadius:20, fontWeight:600, fontSize:10,
          }}>
            {o.niveau}
          </span>
        </div>

        {/* Footer meta */}
        <div style={{
          display:"flex", justifyContent:"space-between", alignItems:"center",
          paddingTop:10, borderTop:"1px solid var(--border)",
        }}>
          <div style={{ display:"flex", alignItems:"center", gap:5, fontSize:11, color:"var(--muted)" }}>
            {Icons.user}
            <span><strong style={{ color:"var(--dark)" }}>{o.candidats ?? 0}</strong> {t("archive.candidats")}</span>
          </div>
          <div style={{ display:"flex", alignItems:"center", gap:4, fontSize:10, color:"var(--muted)" }}>
            {Icons.clock}
            {fmtDate(o.createdAt)}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Interview Card ───────────────────────────────────────────────────────────
function InterviewCard({ iv }) {
  const { t } = useI18n();
  const sc = INTERVIEW_STATUS[iv.statut] || { bg:"#F1F5F9", color:"#475569", icon: null, label: iv.statut };

  return (
    <div style={{
      borderRadius:13, border:"1.5px solid var(--border)",
      background:"var(--white)", overflow:"hidden",
      boxShadow:"0 1px 8px rgba(0,0,0,0.04)",
      transition:"box-shadow .2s, transform .2s",
      opacity:0.88,
    }}
      onMouseEnter={e => { e.currentTarget.style.boxShadow="0 4px 16px rgba(0,0,0,0.09)"; e.currentTarget.style.opacity="1"; e.currentTarget.style.transform="translateY(-1px)"; }}
      onMouseLeave={e => { e.currentTarget.style.boxShadow="0 1px 8px rgba(0,0,0,0.04)"; e.currentTarget.style.opacity="0.88"; e.currentTarget.style.transform="none"; }}
    >
      <div style={{ height:3, background:`linear-gradient(90deg, ${sc.color}66, ${sc.color}22)` }}/>

      <div style={{ padding:"14px 16px" }}>
        {/* Header */}
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", gap:8, marginBottom:10 }}>
          <div style={{ flex:1, minWidth:0 }}>
            <div style={{ fontSize:14, fontWeight:700, color:"var(--dark)", marginBottom:2 }}>
              {iv.candidatNom || "Candidat inconnu"}
            </div>
            <div style={{ fontSize:11, color:"var(--muted)" }}>
              {iv.poste || iv.offreTitre || "Poste non précisé"}
            </div>
          </div>
          <span style={{
            fontSize:10, fontWeight:700, padding:"3px 9px", borderRadius:20,
            background:sc.bg, color:sc.color, flexShrink:0,
            display:"flex", alignItems:"center", gap:4, border:`1px solid ${sc.color}33`,
          }}>
            {sc.icon}
            {t(`archive.interviewStatus${sc.label.replace(/\s/g, '')}`)}
          </span>
        </div>

        {/* Type badge */}
        {iv.type && (
          <div style={{ marginBottom:10 }}>
            <span style={{
              display:"inline-flex", alignItems:"center", gap:4,
              background:"#F1F5F9", color:"#475569",
              padding:"2px 9px", borderRadius:20, fontWeight:600, fontSize:10,
            }}>
              {iv.type}
            </span>
          </div>
        )}

        {/* Note / commentaire */}
        {iv.note && (
          <div style={{
            fontSize:11, color:"var(--muted)", lineHeight:1.5, marginBottom:10,
            padding:"8px 10px", background:"#F8FAFF", borderRadius:8,
            borderLeft:"2px solid #C7D2FE",
            display:"-webkit-box", WebkitLineClamp:2, WebkitBoxOrient:"vertical", overflow:"hidden",
          }}>
            {iv.note}
          </div>
        )}

        {/* Footer */}
        <div style={{
          display:"flex", justifyContent:"space-between", alignItems:"center",
          paddingTop:10, borderTop:"1px solid var(--border)",
        }}>
          <div style={{ display:"flex", alignItems:"center", gap:4, fontSize:10, color:"var(--muted)" }}>
            {Icons.calendar}
            {fmtDateTime(iv.date || iv.scheduledAt)}
          </div>
          {iv.duree && (
            <div style={{ display:"flex", alignItems:"center", gap:4, fontSize:10, color:"var(--muted)" }}>
              {Icons.clock}
              {iv.duree} min
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── Empty State ──────────────────────────────────────────────────────────────
function EmptyState({ message }) {
  return (
    <div style={{
      textAlign:"center", padding:"48px 24px",
      color:"var(--muted)", fontSize:13,
      display:"flex", flexDirection:"column", alignItems:"center", gap:12,
    }}>
      <span style={{ color:"var(--border)" }}>{Icons.empty}</span>
      {message}
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════════
// MAIN PAGE
// ════════════════════════════════════════════════════════════════════════════
export default function ArchivePage() {
  const { offers = [], interviews = [], currentUserId } = useApp();
  const { t } = useI18n();

  const [offerSearch, setOfferSearch] = useState("");
  const [interviewSearch, setInterviewSearch] = useState("");
  const [activeTab, setActiveTab] = useState("offres"); // "offres" | "entretiens"

  // ── Archived offers: clôturées ou en pause, appartenant au recruteur ──────
  const archivedOffers = offers.filter(o =>
    o.createdBy === currentUserId &&
    (o.statut === "Fermé" || o.statut === "En pause")
  );

  const filteredOffers = archivedOffers.filter(o => {
    const q = offerSearch.toLowerCase();
    return !q
      || o.titre?.toLowerCase().includes(q)
      || o.code?.toLowerCase().includes(q)
      || o.dept?.toLowerCase().includes(q);
  });

  // ── Past interviews: réalisés, annulés, no-show, refusés, par ce recruteur ─
  const PAST_STATUSES = ["Réalisé", "Annulé", "No-show", "Refusé"];
  const pastInterviews = (interviews || []).filter(iv =>
    iv.recruteurId === currentUserId &&
    PAST_STATUSES.includes(iv.statut)
  );

  const filteredInterviews = pastInterviews.filter(iv => {
    const q = interviewSearch.toLowerCase();
    return !q
      || iv.candidatNom?.toLowerCase().includes(q)
      || iv.poste?.toLowerCase().includes(q)
      || iv.offreTitre?.toLowerCase().includes(q)
      || iv.type?.toLowerCase().includes(q);
  });

  // ── Stats ──────────────────────────────────────────────────────────────────
  const offerStats = [
    { label: t("archive.cloturees"), value: archivedOffers.filter(o => o.statut === "Fermé").length, bg: "#FDF0EE", color: "#C0392B", icon: "🔴" },
    { label: t("archive.enPause"), value: archivedOffers.filter(o => o.statut === "En pause").length, bg: "#FEF9EC", color: "#9A7D0A", icon: "⏸" },
    { label: t("archive.candidatsRecus"), value: archivedOffers.reduce((s, o) => s + (o.candidats ?? 0), 0), bg: "#EEF2FF", color: "#4F46E5", icon: "👤" },
  ];

  const interviewStats = [
    { label: t("archive.realises"), value: pastInterviews.filter(i => i.statut === "Réalisé").length, bg: "#EBF7EF", color: "#16a34a", icon: "✅" },
    { label: t("archive.annules"), value: pastInterviews.filter(i => i.statut === "Annulé").length, bg: "#FDF0EE", color: "#C0392B", icon: "❌" },
    { label: t("archive.noShow"), value: pastInterviews.filter(i => i.statut === "No-show").length, bg: "#FEF9EC", color: "#9A7D0A", icon: "⚠️" },
    { label: t("archive.refuses"), value: pastInterviews.filter(i => i.statut === "Refusé").length, bg: "#FDF0EE", color: "#C0392B", icon: "🚫" },
  ];

  return (
    <div>
      <PageHeader
        title={t("archive.titre")}
        subtitle={t("archive.subtitle")}
      />

      {/* ── Tab switcher ── */}
      <div style={{
        display: "flex", gap: 6, marginBottom: 24,
        padding: "4px", background: "#F1F5F9", borderRadius: 12, width: "fit-content",
      }}>
        {[
          { key: "offres", icon: Icons.briefcase, label: t("archive.offresArchivees"), count: archivedOffers.length },
          { key: "entretiens", icon: Icons.interview, label: t("archive.entretiensPasses"), count: pastInterviews.length },
        ].map(tab => (
          <button key={tab.key} onClick={() => setActiveTab(tab.key)} style={{
            display: "flex", alignItems: "center", gap: 8,
            padding: "9px 18px", borderRadius: 9, border: "none",
            cursor: "pointer", fontSize: 13, fontWeight: 600,
            transition: "all .15s",
            background: activeTab === tab.key ? "var(--white)" : "transparent",
            color: activeTab === tab.key ? "var(--dark)" : "var(--muted)",
            boxShadow: activeTab === tab.key ? "0 1px 6px rgba(0,0,0,0.08)" : "none",
          }}>
            <span style={{ color: activeTab === tab.key ? "#4F46E5" : "var(--muted)" }}>{tab.icon}</span>
            {tab.label}
            <span style={{
              background: activeTab === tab.key ? "#EEF2FF" : "#E2E8F0",
              color: activeTab === tab.key ? "#4F46E5" : "#64748B",
              borderRadius: 20, padding: "1px 8px", fontSize: 11, fontWeight: 700,
            }}>{tab.count}</span>
          </button>
        ))}
      </div>

      {/* ════ OFFRES TAB ════ */}
      {activeTab === "offres" && (
        <div>
          <StatStrip items={offerStats} />

          <div style={{
            background: "var(--white)", borderRadius: 14,
            border: "1.5px solid var(--border)",
            boxShadow: "var(--shadow-sm)", overflow: "hidden",
          }}>
            <SectionHeader
              icon={Icons.archive}
              title={t("archive.offresCloturees")}
              count={filteredOffers.length}
              search={offerSearch}
              onSearch={setOfferSearch}
              placeholder={t("archive.rechercherOffre")}
            />

            {filteredOffers.length === 0 ? (
              <EmptyState
                message={
                  offerSearch
                    ? t("archive.aucuneOffreRecherche")
                    : t("archive.aucuneOffre")
                }
              />
            ) : (
              <div style={{
                display: "grid",
                gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))",
                gap: 14, padding: "20px",
              }}>
                {filteredOffers.map(o => <ArchivedOfferCard key={o.id} o={o} />)}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ════ ENTRETIENS TAB ════ */}
      {activeTab === "entretiens" && (
        <div>
          <StatStrip items={interviewStats} />

          <div style={{
            background: "var(--white)", borderRadius: 14,
            border: "1.5px solid var(--border)",
            boxShadow: "var(--shadow-sm)", overflow: "hidden",
          }}>
            <SectionHeader
              icon={Icons.interview}
              title={t("archive.entretiensPasse")}
              count={filteredInterviews.length}
              search={interviewSearch}
              onSearch={setInterviewSearch}
              placeholder={t("archive.rechercherEntretien")}
            />

            {filteredInterviews.length === 0 ? (
              <EmptyState
                message={
                  interviewSearch
                    ? t("archive.aucunEntretienRecherche")
                    : t("archive.aucunEntretien")
                }
              />
            ) : (
              <div style={{
                display: "grid",
                gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))",
                gap: 14, padding: "20px",
              }}>
                {filteredInterviews.map(iv => <InterviewCard key={iv.id} iv={iv} />)}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}