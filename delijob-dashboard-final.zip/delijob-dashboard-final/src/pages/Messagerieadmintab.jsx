import { useState, useEffect, useRef, useCallback } from "react";
import { useApp } from "../context/appcontext.jsx";
import { useI18n } from "../i18n/i18nContext.jsx";

const API_BASE = "http://localhost:8080";

const AVATAR_COLORS = ["#003DA5","#7C3AED","#0891B2","#059669","#DC2626","#D97706","#0F766E","#9338EA"];

function authHeaders() {
  const token = localStorage.getItem("token");
  if (token) {
    try {
      const base64Url = token.split('.')[1];
      const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
      const payload = JSON.parse(atob(base64));
      if (payload.role !== 'ADMIN') { localStorage.clear(); window.location.href = '/login'; return {}; }
    } catch(e) { localStorage.clear(); window.location.href = '/login'; return {}; }
  }
  return { "Content-Type": "application/json", ...(token ? { "Authorization": `Bearer ${token}` } : {}) };
}

function formatTime(date) {
  return new Date(date).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });
}

function formatDate(date) {
  const today = new Date();
  const d = new Date(date);
  if (d.toDateString() === today.toDateString()) return "Aujourd'hui";
  const yesterday = new Date(today);
  yesterday.setDate(yesterday.getDate() - 1);
  if (d.toDateString() === yesterday.toDateString()) return "Hier";
  return d.toLocaleDateString("fr-FR", { day: "numeric", month: "long" });
}

function groupByDate(messages) {
  const groups = [];
  let lastDate = null;
  for (const msg of messages) {
    const d = formatDate(msg.createdAt || msg.time);
    if (d !== lastDate) {
      groups.push({ type: "date", label: d, key: "d-" + d + Math.random() });
      lastDate = d;
    }
    groups.push({ type: "msg", ...msg });
  }
  return groups;
}

function Avatar({ initials, size = 38, bg = "#003DA5" }) {
  return (
    <div style={{
      width: size, height: size, borderRadius: "50%",
      background: `linear-gradient(135deg, ${bg} 0%, #1a56db 100%)`,
      display: "flex", alignItems: "center", justifyContent: "center",
      fontWeight: 700, fontSize: size * 0.35, color: "white",
      flexShrink: 0, boxShadow: `0 2px 8px ${bg}44`,
    }}>{initials}</div>
  );
}

// ─── Message action menu ──────────────────────────────────────────────────────
function MessageActions({ onEdit, onDelete }) {
  const [open, setOpen] = useState(false);
  const menuRef = useRef(null);

  useEffect(() => {
    if (!open) return;
    function handleClick(e) {
      if (menuRef.current && !menuRef.current.contains(e.target)) setOpen(false);
    }
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, [open]);

  return (
    <div ref={menuRef} style={{ position: "relative" }}>
      <button
        onClick={() => setOpen(o => !o)}
        title="Options"
        style={{
          background: open ? "#E8EEFF" : "rgba(255,255,255,0.85)",
          border: "1px solid #E2E8F0", borderRadius: 8,
          cursor: "pointer", width: 26, height: 26,
          display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: 15, color: "#64748B", transition: "all .15s", flexShrink: 0,
        }}
        onMouseEnter={e => { if (!open) { e.currentTarget.style.background = "#F0F4FF"; e.currentTarget.style.borderColor = "#003DA5"; } }}
        onMouseLeave={e => { if (!open) { e.currentTarget.style.background = "rgba(255,255,255,0.85)"; e.currentTarget.style.borderColor = "#E2E8F0"; } }}
      >···</button>
      {open && (
        <div style={{
          position: "absolute", bottom: "calc(100% + 6px)", right: 0,
          background: "white", border: "1px solid #E8EEFF",
          borderRadius: 10, boxShadow: "0 8px 24px rgba(0,61,165,0.12)",
          minWidth: 130, zIndex: 100, overflow: "hidden",
          animation: "fadeUp .12s ease",
        }}>
          <button
            onClick={() => { setOpen(false); onEdit(); }}
            style={{ width: "100%", padding: "9px 14px", border: "none", background: "none", textAlign: "left", fontSize: 13, color: "#0F172A", cursor: "pointer", display: "flex", alignItems: "center", gap: 8, fontFamily: "var(--font-sans)" }}
            onMouseEnter={e => e.currentTarget.style.background = "#F0F4FF"}
            onMouseLeave={e => e.currentTarget.style.background = "none"}
          >✏️ Modifier</button>
          <div style={{ height: 1, background: "#F1F5F9" }} />
          <button
            onClick={() => { setOpen(false); onDelete(); }}
            style={{ width: "100%", padding: "9px 14px", border: "none", background: "none", textAlign: "left", fontSize: 13, color: "#DC2626", cursor: "pointer", display: "flex", alignItems: "center", gap: 8, fontFamily: "var(--font-sans)" }}
            onMouseEnter={e => e.currentTarget.style.background = "#FEF2F2"}
            onMouseLeave={e => e.currentTarget.style.background = "none"}
          >🗑️ Supprimer</button>
        </div>
      )}
    </div>
  );
}

// ─── Delete confirm popover ───────────────────────────────────────────────────
function DeleteConfirm({ onConfirm, onCancel }) {
  return (
    <div style={{
      position: "absolute", bottom: "calc(100% + 8px)", right: 0,
      background: "white", border: "1px solid #FEE2E2",
      borderRadius: 10, boxShadow: "0 8px 24px rgba(220,38,38,0.10)",
      padding: "10px 14px", zIndex: 100, minWidth: 200,
      animation: "fadeUp .12s ease",
    }}>
      <p style={{ margin: "0 0 8px", fontSize: 12, color: "#64748B", lineHeight: 1.5 }}>Supprimer ce message ?</p>
      <div style={{ display: "flex", gap: 6 }}>
        <button onClick={onConfirm} style={{ flex: 1, padding: "5px 0", borderRadius: 7, border: "none", background: "#DC2626", color: "white", fontSize: 12, fontWeight: 700, cursor: "pointer" }}>Supprimer</button>
        <button onClick={onCancel} style={{ flex: 1, padding: "5px 0", borderRadius: 7, border: "1px solid #E2E8F0", background: "white", fontSize: 12, color: "#64748B", cursor: "pointer" }}>Annuler</button>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// CONVERSATION PANEL
// ─────────────────────────────────────────────────────────────────────────────
function ConversationPanel({ recruiter, index, onClose }) {
  const [messages,  setMessages]  = useState([]);
  const [inputText, setInputText] = useState("");
  const [sending,   setSending]   = useState(false);
  const [loading,   setLoading]   = useState(true);
  const [error,     setError]     = useState(null);

  // ─── Edit / delete state ────────────────────────────────────────────────
  const [editingId,   setEditingId]   = useState(null);
  const [editText,    setEditText]    = useState("");
  const [deletingId,  setDeletingId]  = useState(null);
  const [hoveredId,   setHoveredId]   = useState(null);

  const { t } = useI18n();
  const messagesEndRef = useRef(null);
  const inputRef       = useRef(null);
  const editInputRef   = useRef(null);
  const pollRef        = useRef(null);
  const lastCountRef   = useRef(0);

  const avatarBg = AVATAR_COLORS[index % AVATAR_COLORS.length];
  const initials = ((recruiter.prenom?.[0]||"?")+(recruiter.nom?.[0]||"?")).toUpperCase();

  const fetchMessages = useCallback(async (silent = false) => {
    const token = localStorage.getItem("token");
    if (!token) { window.location.href = '/login'; return; }
    if (!silent) setLoading(true);
    try {
      const res = await fetch(`${API_BASE}/api/admin/messages/${recruiter.id}`, { headers: authHeaders() });
      if (res.status === 401 || res.status === 403) { localStorage.clear(); window.location.href = '/login'; return; }
      if (!res.ok) throw new Error(`Erreur ${res.status}`);
      const data = await res.json();
      const msgs = Array.isArray(data) ? data : (data.messages || []);

      setMessages(prev => {
        const failedTemps = prev.filter(m => m._failed === true && String(m.id ?? "").startsWith("tmp-"));
        let combined = [...msgs];
        failedTemps.forEach(fm => { if (!combined.some(m => m.id === fm.id)) combined.push(fm); });
        combined.sort((a, b) => new Date(a.createdAt || a.time) - new Date(b.createdAt || b.time));
        if (combined.length > lastCountRef.current && !silent) {
          setTimeout(() => messagesEndRef.current?.scrollIntoView({ behavior: "smooth" }), 80);
        }
        lastCountRef.current = combined.length;
        return combined;
      });
      setError(null);
    } catch (e) {
      if (!silent) setError(t("messagerie.erreurChargement"));
    } finally {
      if (!silent) setLoading(false);
    }
  }, [recruiter.id, t]);

  useEffect(() => {
    fetchMessages(false);
    inputRef.current?.focus();
    pollRef.current = setInterval(() => fetchMessages(true), 3000);
    return () => { if (pollRef.current) clearInterval(pollRef.current); };
  }, [fetchMessages]);

  useEffect(() => { messagesEndRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  useEffect(() => { if (editingId && editInputRef.current) editInputRef.current.focus(); }, [editingId]);

  // ─── Send ─────────────────────────────────────────────────────────────────
  async function sendMessage() {
    if (!inputText.trim() || sending) return;
    const token = localStorage.getItem("token");
    if (!token) { window.location.href = '/login'; return; }
    const text = inputText.trim();
    setInputText("");
    setSending(true);
    const tempId = "tmp-" + Date.now();
    const tempMsg = { id: tempId, senderRole: "ADMIN", content: text, createdAt: new Date().toISOString(), _pending: true };
    setMessages(prev => [...prev, tempMsg]);
    setTimeout(() => messagesEndRef.current?.scrollIntoView({ behavior: "smooth" }), 50);
    try {
      const res = await fetch(`${API_BASE}/api/admin/messages/${recruiter.id}`, {
        method: "POST", headers: authHeaders(), body: JSON.stringify({ content: text }),
      });
      if (res.status === 401 || res.status === 403) { localStorage.clear(); window.location.href = '/login'; return; }
      if (!res.ok) throw new Error(`Erreur ${res.status}`);
      await new Promise(r => setTimeout(r, 500));
      await fetchMessages(false);
    } catch (e) {
      setMessages(prev => prev.map(m => m.id === tempId ? { ...m, _failed: true, _pending: false } : m));
    } finally { setSending(false); }
  }

  function handleKeyDown(e) {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); }
  }

  // ─── Edit ─────────────────────────────────────────────────────────────────
  function startEdit(msg) {
    setEditingId(msg.id);
    setEditText(msg.content);
    setDeletingId(null);
  }

  async function submitEdit(msgId) {
    const newContent = editText.trim();
    if (!newContent) return;
    const prev = messages.find(m => m.id === msgId)?.content;
    if (newContent === prev) { cancelEdit(); return; }
    setMessages(ms => ms.map(m => m.id === msgId ? { ...m, content: newContent, _edited: true } : m));
    setEditingId(null);
    try {
      const res = await fetch(`${API_BASE}/api/admin/messages/${msgId}`, {
        method: "PUT", headers: authHeaders(), body: JSON.stringify({ content: newContent }),
      });
      if (!res.ok) throw new Error();
      setTimeout(() => fetchMessages(true), 400);
    } catch {
      setMessages(ms => ms.map(m => m.id === msgId ? { ...m, content: prev, _edited: false } : m));
      setError("Erreur lors de la modification.");
    }
  }

  function cancelEdit() { setEditingId(null); setEditText(""); }

  function handleEditKeyDown(e, msgId) {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); submitEdit(msgId); }
    if (e.key === "Escape") cancelEdit();
  }

  // ─── Delete ───────────────────────────────────────────────────────────────
  async function confirmDelete(msgId) {
    setDeletingId(null);
    const backup = messages.find(m => m.id === msgId);
    setMessages(ms => ms.filter(m => m.id !== msgId));
    try {
      const res = await fetch(`${API_BASE}/api/admin/messages/${msgId}`, {
        method: "DELETE", headers: authHeaders(),
      });
      if (!res.ok) throw new Error();
    } catch {
      if (backup) setMessages(ms => [...ms, backup].sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt)));
      setError("Erreur lors de la suppression.");
    }
  }

  const grouped = groupByDate(messages);

  return (
    <div style={{ flex: 1, display: "flex", flexDirection: "column", minWidth: 0 }}>
      {/* Header */}
      <div style={{ padding: "14px 24px", borderBottom: "1px solid #EEF2FF", display: "flex", alignItems: "center", gap: 14, background: "white" }}>
        <div style={{ position: "relative" }}>
          <Avatar initials={initials} size={42} bg={avatarBg} />
          <span style={{ position: "absolute", bottom: 2, right: 2, width: 11, height: 11, borderRadius: "50%", background: "#22C55E", border: "2px solid white" }}/>
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 14, fontWeight: 700, color: "#0F172A" }}>{recruiter.prenom} {recruiter.nom}</div>
          <div style={{ fontSize: 11, color: "#22C55E", fontWeight: 600, marginTop: 1 }}>● {t("messagerie.enLigne")} · {recruiter.departement}</div>
        </div>
        <button onClick={onClose} style={{ padding: "6px 14px", borderRadius: 8, border: "1px solid #E2E8F0", background: "white", fontSize: 12, color: "#64748B", cursor: "pointer" }}>
          ✕ {t("messagerie.fermer")}
        </button>
      </div>

      {/* Messages */}
      <div style={{ flex: 1, overflowY: "auto", padding: "20px 24px 12px", background: "#FAFBFF", display: "flex", flexDirection: "column", gap: 2 }}>
        {loading && messages.length === 0 ? (
          <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", color: "#94A3B8", flexDirection: "column", gap: 8 }}>
            <div style={{ fontSize: 28 }}>⏳</div><div style={{ fontSize: 13 }}>{t("common.chargement")}…</div>
          </div>
        ) : error && messages.length === 0 ? (
          <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column", gap: 10 }}>
            <div style={{ fontSize: 13, color: "#991B1B" }}>{error}</div>
            <button onClick={() => fetchMessages(false)} style={{ padding: "6px 16px", borderRadius: 8, border: "1px solid #FECACA", background: "white", color: "#991B1B", fontSize: 12, cursor: "pointer" }}>{t("common.reeessayer")}</button>
          </div>
        ) : messages.length === 0 ? (
          <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 8, color: "#94A3B8" }}>
            <div style={{ fontSize: 36 }}>👋</div>
            <div style={{ fontSize: 13, fontWeight: 600, color: "#64748B" }}>{t("messagerie.demarrerConversation")}</div>
            <div style={{ fontSize: 12 }}>{t("messagerie.envoyerMessageA")} {recruiter.prenom}</div>
          </div>
        ) : grouped.map((item, idx) => {
          if (item.type === "date") return (
            <div key={item.key} style={{ display: "flex", alignItems: "center", gap: 12, margin: "14px 0 8px" }}>
              <div style={{ flex: 1, height: 1, background: "#E2E8F0" }}/>
              <span style={{ fontSize: 11, color: "#94A3B8", fontWeight: 600, padding: "2px 12px", background: "#F1F5F9", borderRadius: 100 }}>{item.label}</span>
              <div style={{ flex: 1, height: 1, background: "#E2E8F0" }}/>
            </div>
          );

          const isAdminMsg = item.senderRole === "ADMIN";
          const isPending = item._pending;
          const isFailed  = item._failed;
          const isEditing = editingId === item.id;
          const isConfirmingDelete = deletingId === item.id;
          const isHovered = hoveredId === item.id;
          // Admin can edit/delete their own non-temp, non-failed messages
          const canModify = isAdminMsg && !isPending && !isFailed && !String(item.id ?? "").startsWith("tmp-");

          return (
            <div
              key={item.id || idx}
              style={{ display: "flex", justifyContent: isAdminMsg ? "flex-end" : "flex-start", marginBottom: 4, alignItems: "flex-end", gap: 8 }}
              onMouseEnter={() => setHoveredId(item.id)}
              onMouseLeave={() => { if (!isConfirmingDelete) setHoveredId(null); }}
            >
              {!isAdminMsg && <Avatar initials={initials} size={28} bg={avatarBg} />}

              <div style={{ maxWidth: "65%", display: "flex", flexDirection: "column", alignItems: isAdminMsg ? "flex-end" : "flex-start" }}>
                {!isAdminMsg && <span style={{ fontSize: 10, color: "#94A3B8", fontWeight: 600, marginBottom: 3, paddingLeft: 4 }}>{recruiter.prenom}</span>}

                <div style={{ display: "flex", alignItems: "flex-end", gap: 6, flexDirection: isAdminMsg ? "row-reverse" : "row" }}>
                  {/* Bubble or edit textarea */}
                  <div style={{ position: "relative" }}>
                    {isEditing ? (
                      <div style={{ display: "flex", flexDirection: "column", gap: 6, minWidth: 220 }}>
                        <textarea
                          ref={editInputRef}
                          value={editText}
                          onChange={e => setEditText(e.target.value)}
                          onKeyDown={e => handleEditKeyDown(e, item.id)}
                          rows={2}
                          style={{
                            padding: "9px 12px", borderRadius: 12, border: "2px solid #003DA5",
                            fontSize: 13, lineHeight: 1.55, fontFamily: "var(--font-sans)",
                            outline: "none", resize: "none", maxHeight: 120, overflowY: "auto",
                            background: "white", color: "#0F172A", boxShadow: "0 0 0 4px rgba(0,61,165,0.08)",
                          }}
                          onInput={e => { e.target.style.height = "auto"; e.target.style.height = Math.min(e.target.scrollHeight, 120) + "px"; }}
                        />
                        <div style={{ display: "flex", gap: 6, justifyContent: "flex-end" }}>
                          <button onClick={cancelEdit} style={{ padding: "4px 12px", borderRadius: 7, border: "1px solid #E2E8F0", background: "white", fontSize: 11, color: "#64748B", cursor: "pointer", fontWeight: 600 }}>Annuler</button>
                          <button onClick={() => submitEdit(item.id)} style={{ padding: "4px 12px", borderRadius: 7, border: "none", background: "linear-gradient(135deg,#003DA5,#1a56db)", fontSize: 11, color: "white", cursor: "pointer", fontWeight: 700 }}>Enregistrer ↵</button>
                        </div>
                      </div>
                    ) : (
                      <div style={{
                        padding: "10px 14px",
                        borderRadius: isAdminMsg ? "16px 16px 4px 16px" : "16px 16px 16px 4px",
                        background: isAdminMsg
                          ? (isFailed ? "#FEF2F2" : isPending ? "linear-gradient(135deg,#4B70C0,#6B88D4)" : "linear-gradient(135deg,#003DA5,#1a56db)")
                          : "white",
                        color: isAdminMsg ? (isFailed ? "#991B1B" : "white") : "#0F172A",
                        fontSize: 13, lineHeight: 1.55,
                        boxShadow: isAdminMsg ? "0 2px 10px rgba(0,61,165,0.25)" : "0 1px 4px rgba(0,0,0,0.08)",
                        border: isAdminMsg ? "none" : "1px solid #E8EEFF",
                        opacity: isPending ? 0.8 : 1,
                      }}>
                        {item.content}
                        {item._edited && !isPending && (
                          <span style={{ fontSize: 10, opacity: 0.65, marginLeft: 6, fontStyle: "italic" }}>modifié</span>
                        )}
                      </div>
                    )}

                    {/* Delete confirm popover */}
                    {isConfirmingDelete && (
                      <DeleteConfirm
                        onConfirm={() => confirmDelete(item.id)}
                        onCancel={() => { setDeletingId(null); setHoveredId(null); }}
                      />
                    )}
                  </div>

                  {/* Action menu — visible on hover for admin's own messages */}
                  {canModify && !isEditing && (isHovered || isConfirmingDelete) && (
                    <MessageActions
                      onEdit={() => startEdit(item)}
                      onDelete={() => setDeletingId(item.id)}
                    />
                  )}
                </div>

                <div style={{ fontSize: 10, color: "#94A3B8", marginTop: 3, display: "flex", alignItems: "center", gap: 5, paddingLeft: isAdminMsg ? 0 : 4, paddingRight: isAdminMsg ? 4 : 0 }}>
                  <span>{formatTime(item.createdAt || new Date())}</span>
                  {isAdminMsg && !isFailed && <span style={{ color: isPending ? "#94A3B8" : "#22C55E" }}>{isPending ? "⏳" : "✓✓"}</span>}
                  {isFailed && (
                    <button onClick={() => {
                      setMessages(prev => prev.filter(m => m.id !== item.id));
                      setInputText(item.content);
                      setTimeout(() => inputRef.current?.focus(), 100);
                    }} style={{ background: "none", border: "none", color: "#EF4444", fontSize: 10, cursor: "pointer", fontWeight: 600, padding: 0 }}>
                      ↺ {t("messagerie.reesayer")}
                    </button>
                  )}
                </div>
              </div>

              {isAdminMsg && <Avatar initials="A" size={28} bg="#003DA5" />}
            </div>
          );
        })}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div style={{ padding: "12px 20px", borderTop: "1px solid #EEF2FF", background: "white", display: "flex", gap: 10, alignItems: "flex-end" }}>
        <textarea
          ref={inputRef}
          value={inputText}
          onChange={e => setInputText(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={`${t("messagerie.messageA")} ${recruiter.prenom}… (${t("messagerie.entreeEnvoyer")})`}
          rows={1}
          style={{ flex: 1, padding: "10px 14px", borderRadius: 12, border: "1.5px solid #E2E8F0", fontSize: 13, fontFamily: "var(--font-sans)", outline: "none", resize: "none", lineHeight: 1.5, maxHeight: 100, overflowY: "auto" }}
          onInput={e => { e.target.style.height = "auto"; e.target.style.height = Math.min(e.target.scrollHeight, 100) + "px"; }}
          onFocus={e => e.target.style.borderColor = "#003DA5"}
          onBlur={e => e.target.style.borderColor = "#E2E8F0"}
        />
        <button
          onClick={sendMessage}
          disabled={!inputText.trim() || sending}
          style={{
            padding: "10px 20px", borderRadius: 12,
            background: inputText.trim() && !sending ? "linear-gradient(135deg,#003DA5,#1a56db)" : "#E2E8F0",
            color: inputText.trim() && !sending ? "white" : "#94A3B8",
            border: "none", fontSize: 13, fontWeight: 700,
            cursor: inputText.trim() && !sending ? "pointer" : "not-allowed",
            transition: "all .15s", flexShrink: 0,
            boxShadow: inputText.trim() && !sending ? "0 4px 14px rgba(0,61,165,0.3)" : "none",
          }}
        >{sending ? "…" : `${t("messagerie.envoyer")} ➤`}</button>
      </div>

      <style>{`
        @keyframes fadeUp {
          from { opacity: 0; transform: translateY(6px); }
          to   { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// MESSAGERIE TAB
// ─────────────────────────────────────────────────────────────────────────────
export function MessagerieTab({ users }) {
  const { addNotif } = useApp();
  const { t } = useI18n();

  const recruiters = (users || []).filter(r => r.status === "APPROVED" || r.status === "ACTIVE");
  const [selectedId,  setSelectedId]  = useState(null);
  const [search,      setSearch]      = useState("");
  const [unreadMap,   setUnreadMap]   = useState({});
  const prevUnreadRef = useRef({});
  const pollRef = useRef(null);

  const fetchUnreads = useCallback(async () => {
    const token = localStorage.getItem("token");
    if (!token) return;
    try {
      const res = await fetch(`${API_BASE}/api/admin/messages/unread`, { headers: authHeaders() });
      if (res.status === 401 || res.status === 403) { localStorage.clear(); window.location.href = '/login'; return; }
      if (!res.ok) return;
      const data = await res.json();
      if (data && typeof data === "object") {
        Object.entries(data).forEach(([rid, count]) => {
          const prev = prevUnreadRef.current[rid] || 0;
          const curr = count || 0;
          if (curr > prev && String(rid) !== String(selectedId)) {
            const recruiter = recruiters.find(r => String(r.id) === String(rid));
            if (recruiter && addNotif) {
              addNotif({
                type: "messagerie",
                titre: t("messagerie.nouveauMessage"),
                message: `${recruiter.prenom} ${recruiter.nom} (${recruiter.departement}) ${t("messagerie.vousAEnvoyeMessage")}`,
                avatar: ((recruiter.prenom?.[0]||"?")+(recruiter.nom?.[0]||"?")).toUpperCase(),
              });
            }
          }
        });
        prevUnreadRef.current = data;
        setUnreadMap(data);
      }
    } catch (e) { /* silencieux */ }
  }, [addNotif, recruiters, selectedId, t]);

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (token) {
      try {
        const base64Url = token.split('.')[1];
        const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
        const payload = JSON.parse(atob(base64));
        if (payload.role !== 'ADMIN') { localStorage.clear(); window.location.href = '/login'; }
      } catch(e) { localStorage.clear(); window.location.href = '/login'; }
    } else { window.location.href = '/login'; }
    fetchUnreads();
    pollRef.current = setInterval(fetchUnreads, 4000);
    return () => { if (pollRef.current) clearInterval(pollRef.current); };
  }, [fetchUnreads]);

  useEffect(() => {
    if (selectedId) setUnreadMap(prev => ({ ...prev, [selectedId]: 0 }));
  }, [selectedId]);

  const filtered = recruiters.filter(r =>
    (r.prenom + " " + r.nom + " " + r.departement).toLowerCase().includes(search.toLowerCase())
  );

  const totalUnread = Object.values(unreadMap).reduce((s, n) => s + (n || 0), 0);
  const selectedRecruiter = recruiters.find(r => r.id === selectedId);
  const selectedIdx = recruiters.findIndex(r => r.id === selectedId);

  return (
    <div style={{ display: "flex", background: "white", borderRadius: 16, border: "1px solid #E8EEFF", boxShadow: "0 2px 12px rgba(0,61,165,0.06)", overflow: "hidden", height: 640 }}>

      {/* Sidebar */}
      <div style={{ width: 300, borderRight: "1px solid #EEF2FF", display: "flex", flexDirection: "column", flexShrink: 0 }}>
        <div style={{ padding: "18px 20px 14px", borderBottom: "1px solid #EEF2FF" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 14 }}>
            <span style={{ fontSize: 15, fontWeight: 700, color: "#0F172A" }}>{t("admin.messagerie")}</span>
            {totalUnread > 0 && (
              <span style={{ background: "#EF4444", color: "white", borderRadius: 100, padding: "1px 8px", fontSize: 11, fontWeight: 700 }}>{totalUnread}</span>
            )}
          </div>
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder={`🔍 ${t("common.rechercher")}…`}
            style={{ width: "100%", padding: "7px 12px", borderRadius: 9, border: "1.5px solid #E2E8F0", fontSize: 12, fontFamily: "var(--font-sans)", outline: "none", boxSizing: "border-box" }}
            onFocus={e => e.target.style.borderColor = "#003DA5"}
            onBlur={e => e.target.style.borderColor = "#E2E8F0"}
          />
        </div>

        <div style={{ flex: 1, overflowY: "auto" }}>
          {filtered.length === 0 ? (
            <div style={{ padding: "40px 20px", textAlign: "center", color: "#94A3B8", fontSize: 13 }}>
              <div style={{ fontSize: 32, marginBottom: 8 }}>💬</div>{t("messagerie.aucunRecruteurActif")}
            </div>
          ) : filtered.map((r, i) => {
            const ini       = ((r.prenom?.[0]||"?")+(r.nom?.[0]||"?")).toUpperCase();
            const bg        = AVATAR_COLORS[i % AVATAR_COLORS.length];
            const unread    = unreadMap[r.id] || 0;
            const isSelected = selectedId === r.id;
            return (
              <div
                key={r.id}
                onClick={() => setSelectedId(r.id)}
                style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 20px", background: isSelected ? "#EEF2FF" : "transparent", borderLeft: isSelected ? "3px solid #003DA5" : "3px solid transparent", cursor: "pointer", transition: "background .15s" }}
                onMouseEnter={e => { if (!isSelected) e.currentTarget.style.background = "#F8FAFF"; }}
                onMouseLeave={e => { if (!isSelected) e.currentTarget.style.background = "transparent"; }}
              >
                <div style={{ position: "relative", flexShrink: 0 }}>
                  <Avatar initials={ini} size={40} bg={bg} />
                  <span style={{ position: "absolute", bottom: 1, right: 1, width: 10, height: 10, borderRadius: "50%", background: "#22C55E", border: "2px solid white" }}/>
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <span style={{ fontSize: 13, fontWeight: isSelected || unread > 0 ? 700 : 600, color: "#0F172A", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", maxWidth: 130 }}>
                      {r.prenom} {r.nom}
                    </span>
                    {unread > 0 && (
                      <span style={{ background: "#EF4444", color: "white", borderRadius: 100, padding: "1px 7px", fontSize: 10, fontWeight: 700, flexShrink: 0 }}>{unread}</span>
                    )}
                  </div>
                  <div style={{ fontSize: 11, color: "#94A3B8", marginTop: 2, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{r.departement}</div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Conversation or empty state */}
      {!selectedId ? (
        <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", color: "#94A3B8", gap: 12 }}>
          <div style={{ fontSize: 52 }}>💬</div>
          <div style={{ fontSize: 15, fontWeight: 600, color: "#64748B" }}>{t("messagerie.selectionnerRecruteur")}</div>
          <div style={{ fontSize: 12 }}>{t("messagerie.choisirConversation")}</div>
        </div>
      ) : (
        <ConversationPanel
          key={selectedId}
          recruiter={selectedRecruiter}
          index={selectedIdx}
          onClose={() => setSelectedId(null)}
        />
      )}
    </div>
  );
}