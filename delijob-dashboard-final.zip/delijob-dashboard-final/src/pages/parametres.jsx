import { useState, useEffect } from "react";
import { useTheme } from "../components/theme-provider.jsx";
import { useI18n } from "../i18n/i18nContext.jsx";

function load() {
  try { return JSON.parse(localStorage.getItem("prefs")) || {}; }
  catch { return {}; }
}

export default function Parametres() {
  const { theme, setTheme } = useTheme();
  const { langue, setLangue, t } = useI18n();
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    const d = document.documentElement;
    d.setAttribute("dir", langue === "ar" ? "rtl" : "ltr");
    d.setAttribute("lang", langue);
  }, [langue]);

  function save() {
    try {
      const prefs = load();
      localStorage.setItem("prefs", JSON.stringify({ ...prefs, langue }));
    } catch {
      localStorage.setItem("prefs", JSON.stringify({ langue }));
    }
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }

  const row = {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "10px 0",
    borderBottom: "1px solid var(--border-color)",
  };

  const s = {
    padding: "6px 10px",
    borderRadius: 6,
    border: "1px solid var(--border-color)",
    fontSize: 13,
    fontFamily: "inherit",
    cursor: "pointer",
    background: "var(--bg-secondary)",
    color: "var(--text-primary)",
  };

  return (
    <div style={{
      maxWidth: 400,
      margin: "40px auto",
      padding: "0 20px",
      fontFamily: "system-ui, sans-serif",
      fontSize: 14,
    }}>
      <h2 style={{ marginBottom: 24, fontWeight: 600, color: "var(--text-primary)" }}>
        {t("parametres.titre")}
      </h2>

      <div style={row}>
        <span style={{ color: "var(--text-primary)" }}>{t("parametres.theme")}</span>
        <select style={s} value={theme} onChange={e => setTheme(e.target.value)}>
          <option value="light">{t("parametres.clair")}</option>
          <option value="dark">{t("parametres.sombre")}</option>
          <option value="system">{t("parametres.systeme")}</option>
        </select>
      </div>

      <div style={{ ...row, borderBottom: "none" }}>
        <span style={{ color: "var(--text-primary)" }}>{t("parametres.langue")}</span>
        <select style={s} value={langue} onChange={e => setLangue(e.target.value)}>
          <option value="fr">Français</option>
          <option value="ar">العربية</option>
          <option value="en">English</option>
        </select>
      </div>

      <button onClick={save} style={{
        marginTop: 24,
        padding: "9px 22px",
        borderRadius: 8,
        border: "none",
        background: "var(--blue)",
        color: "white",
        fontSize: 13,
        fontWeight: 600,
        cursor: "pointer",
        transition: "opacity 0.2s",
      }}>
        {saved ? t("parametres.enregistre") : t("parametres.enregistrer")}
      </button>
    </div>
  );
}